import os
import sqlite3
import json
import re
import requests
from config import SQLITE_DB_PATH, GEMINI_URL
from prompts.analysis_prompts import (
    DATA_MODEL_DESIGN_PROMPT,
    NORMALIZATION_PROMPT,
    DATA_TYPES_PROMPT,
    PERFORMANCE_PROMPT,
    DATA_QUALITY_PROMPT,
    SCALABILITY_PROMPT,
    SECURITY_PROMPT,
    DOCUMENTATION_PROMPT,
    DATA_DICTIONARY_PROMPT,
    CONCEPTUAL_DIAGRAM_PROMPT,
    LOGICAL_DIAGRAM_PROMPT,
    PHYSICAL_DIAGRAM_PROMPT
)

def get_available_databases():
    """Return a list of available SQLite databases in the database directory."""
    if not os.path.exists(SQLITE_DB_PATH):
        os.makedirs(SQLITE_DB_PATH)
    
    databases = []
    for file in os.listdir(SQLITE_DB_PATH):
        if file.endswith('.db') or file.endswith('.sqlite') or file.endswith('.sqlite3'):
            databases.append(file)
    
    return databases

def get_database_tables(db_path):
    """Return a list of tables in the specified database."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get all tables except sqlite_sequence and sqlite_master
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT IN ('sqlite_sequence', 'sqlite_master');")
    tables = [table[0] for table in cursor.fetchall()]
    
    conn.close()
    return tables

def get_table_schema(db_path, table_name):
    """Return the schema of a specific table."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get table columns
    cursor.execute(f"PRAGMA table_info('{table_name}')")
    columns = cursor.fetchall()
    
    # Get foreign keys
    cursor.execute(f"PRAGMA foreign_key_list('{table_name}')")
    foreign_keys = cursor.fetchall()
    
    schema = {
        "columns": [],
        "foreign_keys": []
    }
    
    # Process columns
    for col in columns:
        column_info = {
            "cid": col[0],
            "name": col[1],
            "type": col[2],
            "notnull": col[3],
            "dflt_value": col[4],
            "pk": col[5]
        }
        schema["columns"].append(column_info)
    
    # Process foreign keys
    for fk in foreign_keys:
        fk_info = {
            "id": fk[0],
            "seq": fk[1],
            "table": fk[2],
            "from": fk[3],
            "to": fk[4],
            "on_update": fk[5],
            "on_delete": fk[6],
            "match": fk[7]
        }
        
        # Mark the column as a foreign key in the columns list
        for col in schema["columns"]:
            if col["name"] == fk_info["from"]:
                col["type"] += f" FOREIGN KEY REFERENCES {fk_info['table']}({fk_info['to']})"
                break
        
        schema["foreign_keys"].append(fk_info)
    
    conn.close()
    return schema

def get_database_schema(db_path, tables):
    """Return the schema of multiple tables with their relationships."""
    schema = {}
    for table in tables:
        table_schema = get_table_schema(db_path, table)
        schema[table] = table_schema
    
    # Debug schema
    print(f"Generated schema for tables: {tables}")
    print(f"Schema structure: {list(schema.keys())}")
    for table in tables:
        if table in schema:
            print(f"Table {table} has {len(schema[table]['columns'])} columns and {len(schema[table]['foreign_keys'])} foreign keys")
    
    return schema

def clean_text(text):
    """Clean and format text from Gemini API response."""
    # Remove markdown bold formatting
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
    
    # Remove unnecessary continuation text
    text = re.sub(r'\. \.\. ', '\n', text)
    
    # Strip unwanted spaces
    text = text.strip()
    
    return text

def get_gemini_response(prompt):
    """Get a response from the Gemini API using direct API calls."""
    from config import GEMINI_API_KEY, GEMINI_URL
    
    # Debug: Check if API key is set
    if not GEMINI_API_KEY:
        return "Error: Gemini API key is not set. Please check your environment variables."
    
    print(f"Making API request to Gemini API")
    
    try:
        print("Sending request to Gemini API...")
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        data = {
            "contents": [
                {
                    "role": "user",
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.7,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 4096,
                "responseMimeType": "text/plain"
            }
        }

        # Send POST request
        response = requests.post(GEMINI_URL, headers=headers, json=data)
        
        print(f"Received response with status code: {response.status_code}")
        
        if response.status_code == 200:
            response_data = response.json()
            
            # Extract content from the response
            candidates = response_data.get('candidates', [])
            if candidates:
                content_parts = candidates[0].get('content', {}).get('parts', [])
                if content_parts:
                    # Extract the text and clean it
                    text = content_parts[0].get('text', '').strip()
                    cleaned_text = clean_text(text)
                    print("Response received successfully")
                    return cleaned_text
            
            print("Response received but no valid content found")
            return "No valid content in response. Please check your API key and try again."
        else:
            error_message = f"API Error: {response.status_code}"
            try:
                error_details = response.json()
                print(f"Error details: {error_details}")
                if 'error' in error_details:
                    error_message += f" - {error_details['error']['message']}"
            except Exception as parse_err:
                print(f"Could not parse error details: {str(parse_err)}")
                error_message += f" - {response.text}"
            
            return error_message
            
    except Exception as e:
        print(f"Exception occurred: {str(e)}")
        return f"Error making request: {str(e)}"

def analyze_tables(db_path, selected_tables, analysis_type):
    """Analyze selected tables based on the analysis type."""
    # Get schema for selected tables
    schema = get_database_schema(db_path, selected_tables)
    
    # Prepare prompt based on analysis type
    prompt_template = ""
    if analysis_type == "data_model_design":
        prompt_template = DATA_MODEL_DESIGN_PROMPT
    elif analysis_type == "normalization":
        prompt_template = NORMALIZATION_PROMPT
    elif analysis_type == "data_types":
        prompt_template = DATA_TYPES_PROMPT
    elif analysis_type == "performance":
        prompt_template = PERFORMANCE_PROMPT
    elif analysis_type == "data_quality":
        prompt_template = DATA_QUALITY_PROMPT
    elif analysis_type == "scalability":
        prompt_template = SCALABILITY_PROMPT
    elif analysis_type == "security":
        prompt_template = SECURITY_PROMPT
    elif analysis_type == "documentation":
        prompt_template = DOCUMENTATION_PROMPT
    elif analysis_type == "data_dictionary":
        prompt_template = DATA_DICTIONARY_PROMPT
    else:
        return "Invalid analysis type"
    
    # Format prompt with table and schema information
    prompt = prompt_template.format(
        tables=", ".join(selected_tables),
        schema=json.dumps(schema, indent=2)
    )
    
    # Get response from Gemini API
    return get_gemini_response(prompt)

def generate_diagram(db_path, selected_tables, diagram_type):
    """Generate diagram code for selected tables based on the diagram type."""
    # Get schema for selected tables
    schema = get_database_schema(db_path, selected_tables)
    
    # Print schema for debugging
    print(f"Generating {diagram_type} diagram for tables: {selected_tables}")
    print(f"Schema: {json.dumps(schema, indent=2)}")
    
    # Prepare prompt based on diagram type with explicit instructions
    if diagram_type == "conceptual":
        diagram_type_text = "flowchart"
        prompt_template = """
You are a database modeling expert. Generate a FLOWCHART diagram in mermaid.js syntax for THIS EXACT DATABASE SCHEMA.

Database tables: {tables}
Schema details: {schema}

YOU MUST FOLLOW THESE EXACT FORMATTING REQUIREMENTS:
1. ONLY return the mermaid.js code with NO explanations, comments, or markdown formatting
2. Start the diagram with exactly "flowchart TD" on its own line
3. Each entity should be a node with its actual table name in square brackets: TableName[TableName]
4. Use arrows to show relationships: --> for direct flow, --- for associations
5. Do not use curly braces {} except within node definitions
6. Use the EXACT table names from the schema, not generic placeholders
7. The diagram MUST reflect the actual tables and relationships in the provided schema

IMPORTANT: Do NOT generate a generic example diagram. Use ONLY the real table names provided in the schema.
"""
    elif diagram_type == "logical":
        diagram_type_text = "erDiagram"
        prompt_template = """
You are a database modeling expert. Generate an ER diagram in mermaid.js syntax for THIS EXACT DATABASE SCHEMA.

Database tables: {tables}
Schema details: {schema}

YOU MUST FOLLOW THESE EXACT FORMATTING REQUIREMENTS:
1. ONLY return the mermaid.js code with NO explanations, comments, or markdown formatting
2. Start with exactly "erDiagram" on its own line
3. Define each entity with UPPERCASE table names FROM THE ACTUAL SCHEMA
4. Define attributes inside curly braces with their ACTUAL types and key information from the schema
5. Define relationships with the exact syntax: ENTITY1 ||--o{ ENTITY2 : relationship_label
6. Use cardinality notation: ||--|| (one-to-one), ||--o{ (one-to-many), }o--o{ (many-to-many)
7. Analyze the schema to identify primary/foreign key relationships

IMPORTANT: Do NOT generate a generic example diagram. Use ONLY the real table names and columns provided in the schema.
"""
    elif diagram_type == "physical":
        diagram_type_text = "classDiagram"
        prompt_template = """
You are a database modeling expert. Generate a CLASS diagram in mermaid.js syntax for THIS EXACT DATABASE SCHEMA.

Database tables: {tables}
Schema details: {schema}

YOU MUST FOLLOW THESE EXACT FORMATTING REQUIREMENTS:
1. ONLY return the mermaid.js code with NO explanations, comments, or markdown formatting
2. Start with exactly "classDiagram" on its own line
3. First declare each class with: class table_name
4. Then define each class with attributes using the format:
   class table_name {{
       +data_type column_name
       +data_type column_name
   }}
5. Include ALL columns with their EXACT SQL data types from the schema
6. Mark primary keys with PK and foreign keys with FK after the column name
7. Show relationships between classes using the syntax: Class1 "1" -- "many" Class2 
8. Use proper cardinality notation: "1" for one, "many" or "*" for many

IMPORTANT: Do NOT generate a generic example diagram. Use ONLY the real table names and columns provided in the schema.
"""
    else:
        return "Invalid diagram type"
    
    try:
        # Format prompt with table and schema information
        prompt = prompt_template.format(
            tables=", ".join(selected_tables),
            schema=json.dumps(schema, indent=2)
        )
        
        # Get response from Gemini API
        response = get_gemini_response(prompt)
        
        # Remove any code fences
        response = re.sub(r'```.*?\n', '', response)
        response = re.sub(r'```', '', response)
        
        # Clean the response
        cleaned_response = clean_mermaid_code(response, diagram_type_text)
        
        # Log the final diagram code for debugging
        print(f"Generated diagram code ({diagram_type}):\n{cleaned_response[:100]}...")
        
        if len(cleaned_response.strip()) < 20:
            # If the response is too short, try a simple manual diagram generation based on schema
            print("Response too short, generating simple diagram from schema")
            return generate_simple_diagram_from_schema(schema, selected_tables, diagram_type_text)
            
        return cleaned_response
    except Exception as e:
        print(f"Error generating diagram: {str(e)}")
        # Generate a simple diagram based on the actual schema
        return generate_simple_diagram_from_schema(schema, selected_tables, diagram_type_text)


def generate_simple_diagram_from_schema(schema, table_names, diagram_type):
    """Generate a simple diagram based directly on the database schema."""
    try:
        if diagram_type == "flowchart":
            # Create a simple flowchart
            diagram = "flowchart TD\n"
            
            # Add nodes for each table
            for table in table_names:
                diagram += f"    {table}[{table}]\n"
            
            # Add relationships based on foreign keys
            for table in table_names:
                if isinstance(schema.get(table), dict) and isinstance(schema[table].get('columns'), list):
                    for column_info in schema[table]['columns']:
                        if isinstance(column_info, dict) and 'type' in column_info and 'FOREIGN KEY' in column_info['type'].upper():
                            for ref_table in table_names:
                                if ref_table.lower() in column_info['type'].lower():
                                    diagram += f"    {table} --> {ref_table}\n"
                                    break
            
            return diagram
            
        elif diagram_type == "erDiagram":
            # Create a simple ER diagram
            diagram = "erDiagram\n"
            
            # Add entities with their attributes
            for table in table_names:
                if isinstance(schema.get(table), dict) and isinstance(schema[table].get('columns'), list):
                    diagram += f"    {table.upper()} {{\n"
                    
                    for column_info in schema[table]['columns']:
                        if isinstance(column_info, dict) and 'name' in column_info and 'type' in column_info:
                            col_name = column_info['name']
                            col_type = column_info['type'].split(' ')[0]  # Get base type
                            
                            # Identify keys
                            key_suffix = ""
                            if 'pk' in column_info and column_info['pk'] == 1:
                                key_suffix = " PK"
                            elif 'FOREIGN KEY' in column_info['type'].upper():
                                key_suffix = " FK"
                            
                            diagram += f"        {col_type} {col_name}{key_suffix}\n"
                    
                    diagram += "    }\n"
            
            # Add relationships based on foreign keys
            relationships_added = set()
            for table in table_names:
                if isinstance(schema.get(table), dict) and isinstance(schema[table].get('columns'), list):
                    for column_info in schema[table]['columns']:
                        if isinstance(column_info, dict) and 'type' in column_info and 'FOREIGN KEY' in column_info['type'].upper():
                            for ref_table in table_names:
                                if ref_table.lower() in column_info['type'].lower():
                                    rel_key = f"{ref_table.upper()}-{table.upper()}"
                                    if rel_key not in relationships_added:
                                        diagram += f"    {ref_table.upper()} ||--o{{ {table.upper()} : has\n"
                                        relationships_added.add(rel_key)
                                    break
            
            return diagram
            
        elif diagram_type == "classDiagram":
            # Create a simple class diagram
            diagram = "classDiagram\n"
            
            # First just declare all the classes (without their attributes)
            for table in table_names:
                diagram += f"    class {table}\n"
            
            # Now add class definitions with all attributes
            for table in table_names:
                if isinstance(schema.get(table), dict) and isinstance(schema[table].get('columns'), list):
                    # Always generate class with attributes, even if empty (needed for proper styling)
                    diagram += f"    class {table} {{\n"
                    
                    # Add all column attributes with their types
                    for column_info in schema[table]['columns']:
                        if isinstance(column_info, dict) and 'name' in column_info and 'type' in column_info:
                            col_name = column_info['name']
                            
                            # Get the data type - extract the first word (e.g., INTEGER from INTEGER PRIMARY KEY)
                            # but make sure to include full SQL type without FK references
                            col_type_full = column_info['type']
                            if "FOREIGN KEY" in col_type_full.upper():
                                col_type = col_type_full.split(' FOREIGN KEY')[0]
                            else:
                                col_type = col_type_full.split(' ')[0] 
                            
                            # Identify keys
                            key_suffix = ""
                            if 'pk' in column_info and column_info['pk'] == 1:
                                key_suffix = " PK"
                            elif 'FOREIGN KEY' in column_info['type'].upper():
                                key_suffix = " FK"
                            
                            # Add the attribute with its type in the format: +data_type column_name
                            diagram += f"        +{col_type} {col_name}{key_suffix}\n"
                    
                    # Close the class definition
                    diagram += "    }\n"
            
            # Add relationships after all classes and attributes are defined
            relationships_added = set()
            for table in table_names:
                if isinstance(schema.get(table), dict) and isinstance(schema[table].get('columns'), list):
                    for column_info in schema[table]['columns']:
                        if isinstance(column_info, dict) and 'type' in column_info and 'FOREIGN KEY' in column_info['type'].upper():
                            for ref_table in table_names:
                                if ref_table.lower() in column_info['type'].lower():
                                    rel_key = f"{ref_table}-{table}"
                                    if rel_key not in relationships_added:
                                        diagram += f"    {ref_table} \"1\" -- \"many\" {table}\n"
                                        relationships_added.add(rel_key)
                                    break
            
            return diagram
            
        else:
            return f"{diagram_type}\n    A[No valid diagram type] --> B[Please select a valid type]"
            
    except Exception as e:
        print(f"Error generating simple diagram: {str(e)}")
        return f"{diagram_type}\n    A[Error] --> B[{str(e)}]"


# Function removed - implemented directly in app.py to avoid duplication

def clean_mermaid_code(text, diagram_type):
    """Clean and format mermaid code to ensure proper rendering."""
    # Remove any leading or trailing whitespace
    text = text.strip()
    
    # Fix specific syntax issues for each diagram type
    if diagram_type == "flowchart":
        # Make sure it starts with flowchart TD
        if not text.startswith("flowchart"):
            text = "flowchart TD\n" + text
        
        # Remove any explanatory text before or after the diagram
        lines = text.split('\n')
        cleaned_lines = []
        started = False
        
        for line in lines:
            if line.startswith("flowchart"):
                started = True
                cleaned_lines.append(line)
            elif started and (re.match(r'\s*\w+', line) or re.match(r'\s*\w+\s*-->', line) or re.match(r'\s*\w+\s*---', line)):
                cleaned_lines.append(line)
        
        if cleaned_lines:
            text = "\n".join(cleaned_lines)
        else:
            text = "flowchart TD\n    A[Table1] --> B[Table2]"
            
    elif diagram_type == "erDiagram":
        # Make sure it starts with erDiagram
        if not text.startswith("erDiagram"):
            text = "erDiagram\n" + text
        
        # Remove any explanatory text
        lines = text.split('\n')
        cleaned_lines = []
        started = False
        in_entity = False
        
        for line in lines:
            if line.startswith("erDiagram"):
                started = True
                cleaned_lines.append(line)
            elif started:
                # Check for entity definition start
                if re.match(r'\s*\w+\s*{', line) and not in_entity:
                    in_entity = True
                    cleaned_lines.append(line)
                # Check for entity definition end
                elif re.match(r'\s*}', line) and in_entity:
                    in_entity = False
                    cleaned_lines.append(line)
                # Inside entity definition
                elif in_entity:
                    cleaned_lines.append(line)
                # Relationship lines
                elif re.match(r'\s*\w+\s*\|\|', line) or re.match(r'\s*\w+\s*}o', line):
                    cleaned_lines.append(line)
                # Entity definition without attributes
                elif re.match(r'\s*\w+\s*{', line):
                    cleaned_lines.append(line)
                
        if cleaned_lines:
            text = "\n".join(cleaned_lines)
        else:
            text = "erDiagram\n    ENTITY1 {\n        string id PK\n    }\n    ENTITY2 {\n        string id PK\n    }\n    ENTITY1 ||--o{ ENTITY2 : contains"
            
    elif diagram_type == "classDiagram":
        # Make sure it starts with classDiagram
        if not text.startswith("classDiagram"):
            text = "classDiagram\n" + text
        
        # Remove any explanatory text and fix syntax
        lines = text.split('\n')
        cleaned_lines = []
        class_declarations = set()
        class_definitions = {}
        relationship_lines = []
        started = False
        
        # First pass: collect all parts
        for line in lines:
            if line.startswith("classDiagram"):
                started = True
                cleaned_lines.append(line)
            elif not started:
                continue
            # Class declaration (without attributes)
            elif re.match(r'\s*class\s+\w+\s*$', line):
                match = re.search(r'class\s+(\w+)', line)
                if match:
                    class_name = match.group(1)
                    class_declarations.add(class_name)
            # Class definition (with attributes)
            elif re.match(r'\s*class\s+\w+\s*{', line):
                match = re.search(r'class\s+(\w+)\s*{', line)
                if match:
                    class_name = match.group(1)
                    class_declarations.add(class_name)
                    if class_name not in class_definitions:
                        class_definitions[class_name] = []
                    # Remove the opening bracket from this line
                    remaining = re.sub(r'class\s+\w+\s*{', '', line).strip()
                    if remaining:
                        class_definitions[class_name].append(remaining)
            # Inside a class definition
            elif re.match(r'\s*\+', line) or re.match(r'\s*-', line):
                # Find the class this belongs to
                last_class = None
                for class_name in class_definitions:
                    if class_definitions[class_name]:  # If we've started collecting lines for this class
                        last_class = class_name
                if last_class:
                    class_definitions[last_class].append(line.strip())
            # Class closing bracket
            elif re.match(r'\s*}', line):
                # This is handled in the reconstruction phase
                pass
            # Relationship definition
            elif re.match(r'\s*\w+\s*"', line) or re.match(r'\s*\w+\s*--', line):
                relationship_lines.append(line.strip())
        
        # Now reconstruct the diagram with proper syntax
        # First, just declare all classes without any attributes
        for class_name in sorted(class_declarations):
            cleaned_lines.append(f"    class {class_name}")
        
        # Then add class definitions with their attributes, but don't add empty classes
        for class_name in sorted(class_definitions.keys()):
            if class_definitions[class_name]:  # Only add class definition if it has attributes
                cleaned_lines.append(f"    class {class_name} {{")
                for line in class_definitions[class_name]:
                    cleaned_lines.append(f"        {line}")
                cleaned_lines.append("    }")
            # If the class doesn't have attributes, we've already declared it above
        
        for line in relationship_lines:
            cleaned_lines.append(f"    {line}")
        
        if len(cleaned_lines) <= 1:
            text = "classDiagram\n    class Table1\n    class Table2\n    class Table1 {\n        +int id\n        +string name\n    }\n    class Table2 {\n        +int id\n        +int table1_id\n    }\n    Table1 \"1\" -- \"many\" Table2"
        else:
            text = "\n".join(cleaned_lines)
    
    # Additional global cleanup for all diagram types
    # Remove any markdown code fences
    text = re.sub(r'^```.*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^```$', '', text, flags=re.MULTILINE)
    
    # Remove multiple consecutive blank lines
    text = re.sub(r'\n\s*\n', '\n\n', text)
    
    return text

# Function removed to resolve duplication with the one above

# These functions were removed since they're no longer needed after refactoring
# The mapping sheet functionality is now directly implemented in app.py
