"""
Pendulum.io - Data Modeling and Schema Analysis Tool
Flask application definition and routes
"""

import os
import sqlite3
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file
from werkzeug.utils import secure_filename
import csv
import tempfile
import json
from io import StringIO

# Import configuration
from config import (
    APP_NAME, 
    APP_DESCRIPTION, 
    APP_VERSION, 
    UPLOAD_FOLDER, 
    ALLOWED_EXTENSIONS,
    MAX_CONTENT_LENGTH,
    ANALYSIS_TYPES,
    DIAGRAM_TYPES,
    DOMAIN_OPTIONS
)

# Import modules
from database import (
    get_db_path, 
    get_databases, 
    get_tables_from_db, 
    get_schema_info,
    execute_query, 
    upload_database,
    create_workspace,
    get_workspaces,
    get_workspace_details,
    delete_workspace,
    upload_csv_schema
)
from analysis import (
    analyze_schema,
    generate_diagram,
    generate_mapping_sheet, 
    generate_compliance_assessment,
    generate_query,
    generate_query_hints
)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "pendulum-dev-key")

# Configure file upload
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Check if a file has allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Routes
@app.route('/')
def index():
    workspaces = get_workspaces()
    return render_template('index.html', 
                          app_name=APP_NAME,
                          app_version=APP_VERSION,
                          workspaces=workspaces)

@app.route('/workspace')
def workspace():
    workspaces = get_workspaces()
    return render_template('workspace.html', 
                          workspaces=workspaces,
                          domain_options=DOMAIN_OPTIONS)

@app.route('/workspace/<int:workspace_id>')
def workspace_detail(workspace_id):
    workspace = get_workspace_details(workspace_id)
    if not workspace:
        flash('Workspace not found')
        return redirect(url_for('workspace'))
    
    databases = get_databases(workspace_id)
    return render_template('workspace.html', 
                          workspace=workspace, 
                          databases=databases,
                          domain_options=DOMAIN_OPTIONS)

@app.route('/create_workspace', methods=['POST'])
def handle_create_workspace():
    name = request.form.get('name')
    description = request.form.get('description', '')
    domain = request.form.get('domain', 'Other')
    
    if not name:
        flash('Workspace name is required')
        return redirect(url_for('workspace'))
    
    try:
        workspace_id = create_workspace(name, description, domain)
        flash(f'Workspace "{name}" created successfully')
        return redirect(url_for('workspace_detail', workspace_id=workspace_id))
    except Exception as e:
        logger.error(f"Error creating workspace: {str(e)}")
        flash(f'Error creating workspace: {str(e)}')
        return redirect(url_for('workspace'))

@app.route('/delete_workspace/<int:workspace_id>', methods=['POST'])
def handle_delete_workspace(workspace_id):
    success = delete_workspace(workspace_id)
    if success:
        flash('Workspace deleted successfully')
    else:
        flash('Failed to delete workspace')
    return redirect(url_for('workspace'))

@app.route('/upload_database', methods=['POST'])
def handle_upload_database():
    workspace_id = request.form.get('workspace_id')
    
    if 'database_file' not in request.files:
        flash('No file part')
        return redirect(url_for('workspace_detail', workspace_id=workspace_id))
    
    file = request.files['database_file']
    
    if file.filename == '':
        flash('No selected file')
        return redirect(url_for('workspace_detail', workspace_id=workspace_id))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_extension = filename.rsplit('.', 1)[1].lower()
        
        if file_extension in ['db', 'sqlite', 'sqlite3']:
            # SQLite database file
            db_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(db_path)
            db_name = filename
            upload_database(workspace_id, db_name, db_path)
            flash(f'Database "{db_name}" uploaded successfully')
        
        elif file_extension == 'csv':
            # CSV schema file
            db_name = filename.rsplit('.', 1)[0]
            success = upload_csv_schema(workspace_id, db_name, file)
            if success:
                flash(f'CSV schema "{db_name}" uploaded successfully')
            else:
                flash('Error processing CSV schema file')
        
        elif file_extension == 'txt':
            # Additional schema elements
            db_name = request.form.get('database_name')
            if not db_name:
                flash('Database name is required for schema files')
                return redirect(url_for('workspace_detail', workspace_id=workspace_id))
            
            # Save the text file for later processing
            txt_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(txt_path)
            
            # Register this as a pending schema file
            try:
                from database import APP_DB_PATH
                conn = sqlite3.connect(APP_DB_PATH)
                cursor = conn.cursor()
                
                # Register as a special text-based schema
                cursor.execute("""
                    INSERT INTO databases (workspace_id, name, path, description)
                    VALUES (?, ?, ?, ?)
                """, (workspace_id, f"{db_name}_schema.txt", txt_path, "Text-based schema definition"))
                
                conn.commit()
                conn.close()
                
                flash(f'Text schema file "{filename}" uploaded successfully to database "{db_name}"')
            except Exception as e:
                logger.error(f"Error registering text schema: {str(e)}")
                flash(f'Error registering schema file: {str(e)}')
                return redirect(url_for('workspace_detail', workspace_id=workspace_id))
    else:
        flash(f'File type not allowed. Allowed types: {", ".join(ALLOWED_EXTENSIONS)}')
    
    return redirect(url_for('workspace_detail', workspace_id=workspace_id))

@app.route('/dashboard')
def dashboard():
    databases = get_databases()
    selected_db = request.args.get('database', '')
    
    return render_template('dashboard.html', 
                          databases=databases,
                          database=selected_db,
                          analysis_types=ANALYSIS_TYPES)

@app.route('/get_tables', methods=['POST'])
def get_tables():
    database = request.form.get('database')
    
    if not database:
        return jsonify({'error': 'No database specified'})
    
    try:
        tables = get_tables_from_db(database)
        return jsonify({'tables': tables})
    except Exception as e:
        logger.error(f"Error getting tables: {str(e)}")
        return jsonify({'error': f'Failed to get tables: {str(e)}'})

@app.route('/analyze', methods=['POST'])
def analyze():
    databases = request.form.getlist('database[]')
    tables_by_db = {}
    
    # Handle single database case (for backward compatibility)
    if not databases:
        single_db = request.form.get('database')
        if single_db:
            databases = [single_db]
            tables_by_db[single_db] = request.form.getlist('tables[]')
    else:
        # Build tables by database mapping
        for db in databases:
            db_tables_key = f'tables_{db}[]'
            tables_by_db[db] = request.form.getlist(db_tables_key)
    
    analysis_type = request.form.get('analysis_type', 'general')
    
    # Support multiple analysis types (comma separated)
    analysis_types = [t.strip() for t in analysis_type.split(',')] if ',' in analysis_type else [analysis_type]
    
    if not databases or not any(tables_by_db.values()):
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        # For now, just use the first database for analysis (future: support multi-db analysis)
        database = databases[0]
        tables = tables_by_db[database]
        
        schema_info = get_schema_info(database, tables)
        
        # If only one analysis type, just return the result
        if len(analysis_types) == 1:
            result = analyze_schema(database, tables, schema_info, analysis_types[0])
            return jsonify({'result': result})
        
        # If multiple analysis types, combine the results
        results = []
        for a_type in analysis_types:
            result = analyze_schema(database, tables, schema_info, a_type)
            results.append(f"## {a_type.title()} Analysis\n\n{result}")
        
        combined_result = "\n\n".join(results)
        return jsonify({'result': combined_result})
    except Exception as e:
        logger.error(f"Analysis error: {str(e)}")
        return jsonify({'error': f'Analysis failed: {str(e)}'})

@app.route('/analyze_domain', methods=['POST'])
def handle_analyze_domain():
    from config import GEMINI_API_KEY
    
    # Check if API key is available
    if not GEMINI_API_KEY:
        return jsonify({
            'error': 'No Gemini API key configured in config.py',
            'description': 'Please configure a Gemini API key in config.py to use domain analysis features',
            'diagram_code': 'graph TD\nA[Error] -->|No API Key| B[Configure Gemini API Key in config.py]'
        })
    
    databases = request.form.getlist('database[]')
    tables_by_db = {}
    
    # Build tables by database mapping
    for db in databases:
        db_tables_key = f'tables_{db}[]'
        tables_by_db[db] = request.form.getlist(db_tables_key)
        
        # If wildcard '*' is specified or no tables are specified, get all tables
        if '*' in tables_by_db[db] or not tables_by_db[db]:
            try:
                tables_by_db[db] = get_tables_from_db(db)
            except Exception as e:
                logger.error(f"Error getting tables for {db}: {str(e)}")
                tables_by_db[db] = []
    
    if not databases or not any(tables_by_db.values()):
        return jsonify({
            'error': 'No tables found in selected databases',
            'description': 'Please select databases with tables to analyze',
            'diagram_code': 'graph TD\nA[Error] -->|No Tables Found| B[Select databases with tables]'
        })
    
    try:
        # Get schema info for each database
        schema_info_by_db = {}
        for db in databases:
            if db in tables_by_db and tables_by_db[db]:
                schema_info_by_db[db] = get_schema_info(db, tables_by_db[db])
        
        # Generate domain analysis
        from analysis import analyze_domain
        result = analyze_domain(databases, tables_by_db, schema_info_by_db)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Domain analysis error: {str(e)}")
        return jsonify({'error': f'Domain analysis failed: {str(e)}', 
                        'description': f'Error analyzing domain: {str(e)}',
                        'diagram_code': 'graph TD\nA[Error] -->|Failed to analyze| B[Could not generate diagram]'})

@app.route('/visualization')
def visualization():
    databases = get_databases()
    selected_db = request.args.get('database', '')
    selected_tables = request.args.getlist('tables')
    
    return render_template('visualization.html', 
                          databases=databases,
                          database=selected_db,
                          tables=selected_tables,
                          diagram_types=DIAGRAM_TYPES)

@app.route('/generate_diagram', methods=['POST'])
def handle_generate_diagram():
    database = request.form.get('database')
    tables = request.form.getlist('tables[]')
    diagram_type = request.form.get('diagram_type')
    
    if not database or not tables or not diagram_type:
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        schema_info = get_schema_info(database, tables)
        diagram_code = generate_diagram(database, tables, schema_info, diagram_type)
        return jsonify({'diagram_code': diagram_code})
    except Exception as e:
        logger.error(f"Diagram generation error: {str(e)}")
        return jsonify({'error': f'Failed to generate diagram: {str(e)}'})

@app.route('/mapping_sheet')
def mapping_sheet():
    databases = get_databases()
    selected_db = request.args.get('database', '')
    selected_tables = request.args.getlist('tables')
    
    return render_template('mapping_sheet.html',
                          databases=databases,
                          database=selected_db,
                          tables=selected_tables)

@app.route('/generate_mapping_sheet', methods=['POST'])
def handle_generate_mapping_sheet():
    database = request.form.get('database')
    tables = request.form.getlist('tables[]')
    
    if not database or not tables:
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        schema_info = get_schema_info(database, tables)
        mapping_data = generate_mapping_sheet(database, tables, schema_info)
        return jsonify({'mapping_data': mapping_data})
    except Exception as e:
        logger.error(f"Mapping sheet generation error: {str(e)}")
        return jsonify({'error': f'Failed to generate mapping sheet: {str(e)}'})

@app.route('/compliance')
def compliance():
    databases = get_databases()
    selected_db = request.args.get('database', '')
    selected_tables = request.args.getlist('tables')
    
    # Get compliance history if a database is selected
    compliance_history = []
    if selected_db:
        from database import get_compliance_history
        compliance_history = get_compliance_history(selected_db)
    
    return render_template('compliance.html',
                          databases=databases,
                          database=selected_db,
                          tables=selected_tables,
                          compliance_history=compliance_history)

@app.route('/generate_compliance', methods=['POST'])
def handle_generate_compliance():
    database = request.form.get('database')
    tables = request.form.getlist('tables[]')
    
    if not database or not tables:
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        schema_info = get_schema_info(database, tables)
        compliance_data = generate_compliance_assessment(database, tables, schema_info)
        
        if compliance_data is None:
            return jsonify({'error': 'Failed to generate compliance assessment. Check logs for details.'})
        
        # Get updated compliance history
        from database import get_compliance_history
        compliance_history = get_compliance_history(database)
        
        return jsonify({
            'compliance_data': compliance_data,
            'compliance_history': compliance_history
        })
    except Exception as e:
        logger.error(f"Compliance assessment error: {str(e)}")
        return jsonify({
            'error': f'Failed to generate compliance assessment: {str(e)}',
            'compliance_data': {
                'overall_score': 0,
                'readability_scores': {
                    'flesch_kincaid': 0,
                    'gunning_fog': 0,
                    'summary': 'Error generating readability scores'
                },
                'compliance': {'score': 0, 'strengths': [], 'weaknesses': [], 'recommendations': []},
                'auditability': {'score': 0, 'strengths': [], 'weaknesses': [], 'recommendations': []},
                'security': {'score': 0, 'strengths': [], 'weaknesses': [], 'recommendations': []},
                'traceability': {'score': 0, 'strengths': [], 'weaknesses': [], 'recommendations': []},
                'lineage': {'score': 0, 'strengths': [], 'weaknesses': [], 'recommendations': []},
                'ethics': {'score': 0, 'strengths': [], 'weaknesses': [], 'recommendations': []}
            }
        })

@app.route('/querywiz')
def querywiz():
    databases = get_databases()
    return render_template('querywiz.html', databases=databases)

@app.route('/generate_query_hints', methods=['POST'])
def handle_generate_query_hints():
    database = request.form.get('database')
    
    if not database:
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        # Get all tables for the database
        tables = get_tables_from_db(database)
        schema_info = get_schema_info(database, tables)
        
        # Generate sample questions based on schema
        hints = generate_query_hints(database, schema_info)
        return jsonify({'hints': hints})
    except Exception as e:
        logger.error(f"Query hints generation error: {str(e)}")
        return jsonify({'error': f'Failed to generate query hints: {str(e)}'})

@app.route('/generate_query', methods=['POST'])
def handle_generate_query():
    database = request.form.get('database')
    prompt = request.form.get('prompt')
    
    if not database or not prompt:
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        # Get all tables for the database
        tables = get_tables_from_db(database)
        schema_info = get_schema_info(database, tables)
        query = generate_query(database, prompt, schema_info)
        return jsonify({'query': query})
    except Exception as e:
        logger.error(f"Query generation error: {str(e)}")
        return jsonify({'error': f'Failed to generate query: {str(e)}'})

@app.route('/execute_query', methods=['POST'])
def handle_execute_query():
    database = request.form.get('database')
    query = request.form.get('query')
    
    if not database or not query:
        return jsonify({'error': 'Missing required parameters'})
    
    try:
        results = execute_query(database, query)
        return jsonify(results)
    except Exception as e:
        logger.error(f"Query execution error: {str(e)}")
        return jsonify({'error': f'Failed to execute query: {str(e)}'})

@app.route('/export_csv', methods=['POST'])
def export_csv():
    data = request.json
    if not data:
        return jsonify({'error': 'No data provided'})
    
    # Handle both formats - new format with direct query or old format with results
    if 'query' in data and 'database' in data:
        # New format - execute the query first
        database = data.get('database')
        query = data.get('query')
        filename = data.get('filename', f"{database}_export.csv")
        
        try:
            # Execute the query to get results
            query_result = execute_query(database, query)
            
            # Create CSV in memory
            csv_data = StringIO()
            writer = csv.writer(csv_data)
            
            # Write headers
            writer.writerow(query_result['headers'])
            
            # Write rows
            writer.writerows(query_result['rows'])
            
        except Exception as e:
            logger.error(f"Error exporting CSV: {str(e)}")
            return jsonify({'error': f"Error generating CSV: {str(e)}"}), 500
    
    elif 'results' in data:
        # Old format - results are provided directly
        filename = data.get('filename', 'export.csv')
        results = data.get('results', {})
        
        # Create CSV in memory
        csv_data = StringIO()
        writer = csv.writer(csv_data)
        
        # Write headers if available
        if results and 'headers' in results:
            writer.writerow(results['headers'])
        
        # Write rows
        if results and 'rows' in results:
            writer.writerows(results['rows'])
    
    else:
        return jsonify({'error': 'Invalid data format'}), 400
    
    csv_data.seek(0)
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.csv')
    temp_file.write(csv_data.getvalue().encode())
    temp_file.close()
    
    return send_file(
        temp_file.name,
        as_attachment=True,
        download_name=filename,
        mimetype='text/csv'
    )

# API Key handling removed - now managed via config.py

@app.route('/test_api_connection')
def test_api_connection():
    from config import GEMINI_API_KEY
    
    if not GEMINI_API_KEY:
        return jsonify({
            'success': False,
            'message': 'No API key configured in config.py'
        })
    
    try:
        from utils import get_gemini_response
        
        # Simple test prompt
        test_prompt = "Hello, can you respond with 'API Connection Successful' if you receive this message?"
        
        response = get_gemini_response(test_prompt)
        
        if "API Connection Successful" in response or "API key not configured" not in response:
            return jsonify({
                'success': True,
                'message': 'API connection successful! Gemini API is working properly.'
            })
        else:
            return jsonify({
                'success': False,
                'message': f'API returned an unexpected response: {response}'
            })
    except Exception as e:
        logger.error(f"API connection test error: {str(e)}")
        return jsonify({
            'success': False,
            'message': f'API connection failed: {str(e)}'
        })

# Error handling
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

# Context processor for template variables
@app.context_processor
def utility_processor():
    from config import APP_NAME, APP_VERSION, GEMINI_API_KEY
    return {
        'current_year': datetime.now().year,
        'app_name': APP_NAME,
        'app_version': APP_VERSION,
        'config': {
            'GEMINI_API_KEY': GEMINI_API_KEY
        }
    }

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)