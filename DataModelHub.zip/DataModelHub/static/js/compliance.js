// ADW Workbench - Compliance JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Compliance JS loaded');
    
    const databaseSelect = document.getElementById('database');
    const tablesList = document.getElementById('tablesList');
    const generateComplianceBtn = document.getElementById('generateComplianceBtn');
    const complianceAssessment = document.getElementById('complianceAssessment');
    const emptyState = document.getElementById('emptyState');
    const overallScoreValue = document.getElementById('overallScoreValue');
    const assessedTablesCount = document.getElementById('assessedTablesCount');
    const dimensionsContainer = document.getElementById('dimensionsContainer');
    const exportReportBtn = document.getElementById('exportReportBtn');
    
    // Load tables when a database is selected
    if (databaseSelect) {
        databaseSelect.addEventListener('change', function() {
            const database = this.value;
            if (database) {
                loadTables(database);
            } else {
                tablesList.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-muted">Select a database to show tables</p>
                    </div>
                `;
            }
        });
        
        // Load tables for the pre-selected database (if any)
        if (databaseSelect.value) {
            loadTables(databaseSelect.value);
        }
    }
    
    // Handle generate compliance assessment button click
    if (generateComplianceBtn) {
        generateComplianceBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const database = databaseSelect.value;
            const selectedTables = getSelectedTables();
            
            if (!database) {
                alert('Please select a database');
                return;
            }
            
            if (selectedTables.length === 0) {
                alert('Please select at least one table');
                return;
            }
            
            generateComplianceAssessment();
        });
    }
    
    // Handle export report button click
    if (exportReportBtn) {
        exportReportBtn.addEventListener('click', function() {
            // Get the current date for the filename
            const today = new Date();
            const date = today.toISOString().split('T')[0];
            
            // Get database and selected tables
            const database = databaseSelect.value;
            const selectedTables = getSelectedTables();
            
            // Create report content
            let reportContent = `# CASTLE Compliance Assessment\n\n`;
            reportContent += `**Database:** ${database}\n`;
            reportContent += `**Tables:** ${selectedTables.join(', ')}\n`;
            reportContent += `**Date:** ${today.toLocaleString()}\n\n`;
            
            reportContent += `## Overall Score: ${overallScoreValue.textContent}\n\n`;
            
            // Add readability scores if available
            if (window.currentAssessmentData && window.currentAssessmentData.readability_scores) {
                const readScores = window.currentAssessmentData.readability_scores;
                reportContent += `## Readability Scores\n\n`;
                reportContent += `- Flesch-Kincaid Score: ${readScores.flesch_kincaid ? readScores.flesch_kincaid.toFixed(1) : "N/A"}\n`;
                reportContent += `- Gunning Fog Index: ${readScores.gunning_fog ? readScores.gunning_fog.toFixed(1) : "N/A"}\n`;
                if (readScores.summary) reportContent += `- ${readScores.summary}\n`;
                reportContent += `\n`;
            }
            
            // Get dimensions data
            const dimensions = dimensionsContainer.querySelectorAll('.castle-card');
            
            dimensions.forEach(dimension => {
                const dimensionName = dimension.querySelector('h4').textContent;
                const score = dimension.querySelector('.castle-score').textContent;
                
                reportContent += `## ${dimensionName}\n\n`;
                reportContent += `**Score:** ${score}/5\n\n`;
                
                // Get strengths
                const strengthsTitle = dimension.querySelector('.castle-detail-section:nth-child(2) h5').textContent;
                const strengthsList = dimension.querySelectorAll('.castle-detail-section:nth-child(2) .castle-list li');
                
                reportContent += `### ${strengthsTitle}\n`;
                strengthsList.forEach(item => {
                    reportContent += `- ${item.textContent}\n`;
                });
                reportContent += '\n';
                
                // Get weaknesses
                const weaknessesTitle = dimension.querySelector('.castle-detail-section:nth-child(3) h5').textContent;
                const weaknessesList = dimension.querySelectorAll('.castle-detail-section:nth-child(3) .castle-list li');
                
                reportContent += `### ${weaknessesTitle}\n`;
                weaknessesList.forEach(item => {
                    reportContent += `- ${item.textContent}\n`;
                });
                reportContent += '\n';
                
                // Get recommendations
                const recommendationsTitle = dimension.querySelector('.castle-detail-section:nth-child(4) h5').textContent;
                const recommendationsList = dimension.querySelectorAll('.castle-detail-section:nth-child(4) .castle-list li');
                
                reportContent += `### ${recommendationsTitle}\n`;
                recommendationsList.forEach(item => {
                    reportContent += `- ${item.textContent}\n`;
                });
                reportContent += '\n';
            });
            
            // Create and trigger download
            const blob = new Blob([reportContent], { type: 'text/markdown;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', `${database}_castle_assessment_${date}.md`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    }
    
    // Function to load tables for a database
    function loadTables(database) {
        tablesList.innerHTML = `
            <div class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted mt-2">Loading tables...</p>
            </div>
        `;
        
        const formData = new FormData();
        formData.append('database', database);
        
        fetch('/get_tables', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                tablesList.innerHTML = `
                    <div class="alert alert-danger" role="alert">
                        ${data.error}
                    </div>
                `;
                return;
            }
            
            renderTablesList(data.tables);
        })
        .catch(error => {
            console.error('Error loading tables:', error);
            
            tablesList.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    Failed to load tables. Please try again.
                </div>
            `;
        });
    }
    
    // Function to render the tables list
    function renderTablesList(tables) {
        if (!tables || tables.length === 0) {
            tablesList.innerHTML = `
                <div class="text-center py-3">
                    <p class="text-muted">No tables found in this database</p>
                </div>
            `;
            return;
        }
        
        let tablesHtml = '';
        
        tables.forEach(table => {
            tablesHtml += `
                <div class="form-check">
                    <input class="form-check-input table-checkbox" type="checkbox" value="${table}" id="table-${table}">
                    <label class="form-check-label" for="table-${table}">
                        ${table}
                    </label>
                </div>
            `;
        });
        
        tablesHtml += `
            <div class="mt-3">
                <button type="button" id="selectAllTables" class="btn btn-sm btn-outline-primary me-2">Select All</button>
                <button type="button" id="deselectAllTables" class="btn btn-sm btn-outline-secondary">Deselect All</button>
            </div>
        `;
        
        tablesList.innerHTML = tablesHtml;
        
        // Add event listeners for select/deselect all buttons
        document.getElementById('selectAllTables').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.table-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
        });
        
        document.getElementById('deselectAllTables').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.table-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = false;
            });
        });
    }
    
    // Function to generate compliance assessment
    function generateComplianceAssessment() {
        const database = databaseSelect.value;
        const selectedTables = getSelectedTables();
        
        if (!database || selectedTables.length === 0) {
            return;
        }
        
        // Show loading state
        complianceAssessment.style.display = 'block';
        emptyState.style.display = 'none';
        dimensionsContainer.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Generating compliance assessment...</p>
            </div>
        `;
        
        const formData = new FormData();
        formData.append('database', database);
        selectedTables.forEach(table => {
            formData.append('tables[]', table);
        });
        
        fetch('/generate_compliance', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Store the current assessment data globally for export functionality even if there's an error
            // This ensures we at least have a data structure to work with
            if (data.compliance_data) {
                window.currentAssessmentData = data.compliance_data;
            }
            
            if (data.error) {
                dimensionsContainer.innerHTML = `
                    <div class="alert alert-danger">
                        ${data.error || 'An error occurred while generating the compliance assessment.'}
                    </div>
                `;
                
                // If we have some compliance data despite the error, still render it
                if (data.compliance_data) {
                    renderComplianceAssessment(data.compliance_data);
                }
                return;
            }
            
            // Render compliance data
            renderComplianceAssessment(data.compliance_data);
            
            // Update the compliance history section if available
            if (data.compliance_history && data.compliance_history.length > 0) {
                // Instead of reloading, we could update the history UI here
                const historyContainer = document.getElementById('complianceHistory');
                if (historyContainer) {
                    updateComplianceHistory(data.compliance_history);
                }
            }
        })
        .catch(error => {
            console.error('Error generating compliance assessment:', error);
            dimensionsContainer.innerHTML = `
                <div class="alert alert-danger">
                    Failed to generate compliance assessment. Please try again.
                </div>
            `;
        });
    }
    
    // Function to update the compliance history UI
    function updateComplianceHistory(history) {
        const historyContainer = document.getElementById('complianceHistory');
        if (!historyContainer) return;
        
        if (!history || history.length === 0) {
            historyContainer.innerHTML = `<p class="text-center text-muted">No compliance history available</p>`;
            return;
        }
        
        let historyHtml = `
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-sm">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Tables</th>
                            <th>Overall Score</th>
                            <th>Compliance</th>
                            <th>Auditability</th>
                            <th>Security</th>
                            <th>Traceability</th>
                            <th>Lineage</th>
                            <th>Ethics</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        history.forEach(record => {
            historyHtml += `
                <tr>
                    <td>${record.timestamp}</td>
                    <td>${record.tables}</td>
                    <td class="text-center">${record.overall_score}</td>
                    <td class="text-center">${record.compliance_score || 'N/A'}</td>
                    <td class="text-center">${record.auditability_score || 'N/A'}</td>
                    <td class="text-center">${record.security_score || 'N/A'}</td>
                    <td class="text-center">${record.traceability_score || 'N/A'}</td>
                    <td class="text-center">${record.lineage_score || 'N/A'}</td>
                    <td class="text-center">${record.ethics_score || 'N/A'}</td>
                </tr>
            `;
        });
        
        historyHtml += `
                    </tbody>
                </table>
            </div>
        `;
        
        historyContainer.innerHTML = historyHtml;
    }
    
    // Function to render compliance assessment
    function renderComplianceAssessment(data) {
        if (!data || data.error) {
            dimensionsContainer.innerHTML = `<div class="alert alert-danger">${data.error || 'Failed to generate compliance assessment'}</div>`;
            return;
        }
        
        // Set overall score
        overallScoreValue.textContent = data.overall_score.toFixed(1);
        
        // Set assessed tables count
        assessedTablesCount.textContent = getSelectedTables().length;
        
        // Update score circle color based on overall score with a modern gradient look
        const scoreCircle = document.querySelector('.score-circle');
        if (scoreCircle) {
            if (data.overall_score < 40) {
                // Apply red themed styles for low scores
                scoreCircle.style.background = 'linear-gradient(135deg, #ffffff 0%, #fff5f5 100%)';
                scoreCircle.style.boxShadow = '0 10px 25px rgba(220, 53, 69, 0.1), 0 5px 10px rgba(220, 53, 69, 0.07)';
                scoreCircle.style.border = '3px solid rgba(220, 53, 69, 0.2)';
                overallScoreValue.style.background = 'linear-gradient(135deg, #dc3545 0%, #ff6b6b 100%)';
                overallScoreValue.style.webkitBackgroundClip = 'text';
                overallScoreValue.style.webkitTextFillColor = 'transparent';
                overallScoreValue.style.textShadow = '0 1px 2px rgba(0, 0, 0, 0.05)';
                
                // Also update the overall score section
                const overallScoreSection = document.getElementById('overallScoreSection');
                if (overallScoreSection) {
                    overallScoreSection.style.borderLeft = '6px solid rgba(220, 53, 69, 0.5)';
                    overallScoreSection.style.background = 'linear-gradient(135deg, #fff5f5 0%, #ffffff 100%)';
                }
            } else if (data.overall_score < 70) {
                // Apply yellow themed styles for medium scores
                scoreCircle.style.background = 'linear-gradient(135deg, #ffffff 0%, #fffbf0 100%)';
                scoreCircle.style.boxShadow = '0 10px 25px rgba(255, 193, 7, 0.1), 0 5px 10px rgba(255, 193, 7, 0.07)';
                scoreCircle.style.border = '3px solid rgba(255, 193, 7, 0.2)';
                overallScoreValue.style.background = 'linear-gradient(135deg, #fd7e14 0%, #ffc107 100%)';
                overallScoreValue.style.webkitBackgroundClip = 'text';
                overallScoreValue.style.webkitTextFillColor = 'transparent';
                overallScoreValue.style.textShadow = '0 1px 2px rgba(0, 0, 0, 0.05)';
                
                // Also update the overall score section
                const overallScoreSection = document.getElementById('overallScoreSection');
                if (overallScoreSection) {
                    overallScoreSection.style.borderLeft = '6px solid rgba(255, 193, 7, 0.5)';
                    overallScoreSection.style.background = 'linear-gradient(135deg, #fffbf0 0%, #ffffff 100%)';
                }
            } else {
                // Apply green themed styles for high scores
                scoreCircle.style.background = 'linear-gradient(135deg, #ffffff 0%, #f0fff4 100%)';
                scoreCircle.style.boxShadow = '0 10px 25px rgba(40, 167, 69, 0.1), 0 5px 10px rgba(40, 167, 69, 0.07)';
                scoreCircle.style.border = '3px solid rgba(40, 167, 69, 0.2)';
                overallScoreValue.style.background = 'linear-gradient(135deg, #28a745 0%, #48c774 100%)';
                overallScoreValue.style.webkitBackgroundClip = 'text';
                overallScoreValue.style.webkitTextFillColor = 'transparent';
                overallScoreValue.style.textShadow = '0 1px 2px rgba(0, 0, 0, 0.05)';
                
                // Also update the overall score section
                const overallScoreSection = document.getElementById('overallScoreSection');
                if (overallScoreSection) {
                    overallScoreSection.style.borderLeft = '6px solid rgba(40, 167, 69, 0.5)';
                    overallScoreSection.style.background = 'linear-gradient(135deg, #f0fff4 0%, #ffffff 100%)';
                }
            }
            
            // Add a subtle animation
            scoreCircle.style.animation = 'score-pulse 2s infinite alternate';
        }
        
        // Display readability scores if available
        if (data.readability_scores) {
            let fkScore = data.readability_scores.flesch_kincaid;
            let gfScore = data.readability_scores.gunning_fog;
            let freScore = data.readability_scores.flesch_reading_ease;
            let ariScore = data.readability_scores.automated_readability_index;
            let cliScore = data.readability_scores.coleman_liau_index;
            
            // Determine which scores are available
            const hasOldScores = fkScore || gfScore;
            const hasNewScores = freScore || ariScore || cliScore;
            
            let readabilityHtml = `
                <div class="card mb-4 bg-white border-0 shadow-sm">
                    <div class="card-header bg-white border-bottom border-light">
                        <h4 class="h5 mb-0"><i class="fas fa-font me-2"></i>Schema Readability Assessment</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">`;
                        
            if (hasNewScores) {
                // New API format scores with modern design
                readabilityHtml += `
                    <div class="col-md-4 mb-3">
                        <div class="card border-0 shadow-sm text-center h-100">
                            <div class="card-body">
                                <i class="fas fa-book fa-2x text-primary mb-3"></i>
                                <h5 class="card-title h6">Flesch Reading Ease</h5>
                                <h3 class="text-primary">${freScore ? freScore.toFixed(1) : 'N/A'}</h3>
                                <div class="progress mb-3 bg-light" style="height: 6px;">
                                    <div class="progress-bar bg-info" role="progressbar" 
                                         style="width: ${freScore ? Math.min(100, freScore) : 0}%; border-radius: 3px;" 
                                         aria-valuenow="${freScore || 0}" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                    </div>
                                </div>
                                <p class="text-muted small mb-0">Higher is better. 60-70 is ideal.</p>
                                <p class="text-muted small mb-0">Measures text readability based on sentence and word length.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card border-0 shadow-sm text-center h-100">
                            <div class="card-body">
                                <i class="fas fa-glasses fa-2x text-primary mb-3"></i>
                                <h5 class="card-title h6">Automated Readability Index</h5>
                                <h3 class="text-primary">${ariScore ? ariScore.toFixed(1) : 'N/A'}</h3>
                                <div class="progress mb-3 bg-light" style="height: 6px;">
                                    <div class="progress-bar bg-warning" role="progressbar" 
                                         style="width: ${ariScore ? Math.min(100, ariScore * 8) : 0}%; border-radius: 3px;" 
                                         aria-valuenow="${ariScore || 0}" 
                                         aria-valuemin="0" 
                                         aria-valuemax="12">
                                    </div>
                                </div>
                                <p class="text-muted small mb-0">Lower is better. 8-10 is professional.</p>
                                <p class="text-muted small mb-0">Estimates U.S. grade level needed to understand the text.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card border-0 shadow-sm text-center h-100">
                            <div class="card-body">
                                <i class="fas fa-check-circle fa-2x text-primary mb-3"></i>
                                <h5 class="card-title h6">Coleman-Liau Index</h5>
                                <h3 class="text-primary">${cliScore ? cliScore.toFixed(1) : 'N/A'}</h3>
                                <div class="progress mb-3 bg-light" style="height: 6px;">
                                    <div class="progress-bar bg-success" role="progressbar" 
                                         style="width: ${cliScore ? Math.min(100, cliScore * 10) : 0}%; border-radius: 3px;" 
                                         aria-valuenow="${cliScore || 0}" 
                                         aria-valuemin="0" 
                                         aria-valuemax="10">
                                    </div>
                                </div>
                                <p class="text-muted small mb-0">Lower is better. 5-8 is ideal.</p>
                                <p class="text-muted small mb-0">Based on characters per word and words per sentence.</p>
                            </div>
                        </div>
                    </div>`;
            } else if (hasOldScores) {
                // Original API format scores with modern design
                readabilityHtml += `
                    <div class="col-md-6 mb-3">
                        <div class="card border-0 shadow-sm text-center h-100">
                            <div class="card-body">
                                <i class="fas fa-book fa-2x text-primary mb-3"></i>
                                <h5 class="card-title h6">Flesch-Kincaid Score</h5>
                                <h3 class="text-primary">${fkScore ? fkScore.toFixed(1) : 'N/A'}</h3>
                                <div class="progress mb-3 bg-light" style="height: 6px;">
                                    <div class="progress-bar bg-info" role="progressbar" 
                                         style="width: ${fkScore ? Math.min(100, fkScore) : 0}%; border-radius: 3px;" 
                                         aria-valuenow="${fkScore || 0}" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                    </div>
                                </div>
                                <p class="text-muted small mb-0">Higher is more readable (0-100).</p>
                                <p class="text-muted small mb-0">Grades text based on syllable count and sentence length.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="card border-0 shadow-sm text-center h-100">
                            <div class="card-body">
                                <i class="fas fa-glasses fa-2x text-primary mb-3"></i>
                                <h5 class="card-title h6">Gunning Fog Index</h5>
                                <h3 class="text-primary">${gfScore ? gfScore.toFixed(1) : 'N/A'}</h3>
                                <div class="progress mb-3 bg-light" style="height: 6px;">
                                    <div class="progress-bar bg-warning" role="progressbar" 
                                         style="width: ${gfScore ? Math.min(100, gfScore * 5) : 0}%; border-radius: 3px;" 
                                         aria-valuenow="${gfScore || 0}" 
                                         aria-valuemin="0" 
                                         aria-valuemax="20">
                                    </div>
                                </div>
                                <p class="text-muted small mb-0">Lower is more readable (6-17 is ideal).</p>
                                <p class="text-muted small mb-0">Estimates years of formal education needed to understand text.</p>
                            </div>
                        </div>
                    </div>`;
            } else {
                readabilityHtml += `
                    <div class="col-12">
                        <div class="alert alert-info mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            No readability scores available for this assessment.
                        </div>
                    </div>`;
            }
            
            readabilityHtml += `
                        </div>
                        <div class="alert alert-info mt-3">
                            <i class="fas fa-info-circle me-2"></i>
                            <span><strong>What do these scores mean?</strong> Readability scores measure how easy it is to understand your database schema naming and documentation. 
                            Higher Flesch Reading Ease scores (60-100) indicate more readable text.
                            Lower ARI and Coleman-Liau scores indicate simpler text that's easier to understand.</span>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h5 class="h6 fw-bold">Readability Recommendations</h5>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item border-0 px-0 py-1">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>Use clear, descriptive names for tables and columns
                                    </li>
                                    <li class="list-group-item border-0 px-0 py-1">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>Maintain consistent naming conventions throughout the schema
                                    </li>
                                    <li class="list-group-item border-0 px-0 py-1">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>Add meaningful comments to complex relationships or constraints
                                    </li>
                                    <li class="list-group-item border-0 px-0 py-1">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>Create thorough documentation that explains the purpose of each table
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            dimensionsContainer.innerHTML = readabilityHtml;
        } else {
            dimensionsContainer.innerHTML = '';
        }
        
        // Add dimensions
        // Check if we have the new or old API response format
        if (data.dimensions) {
            // Add a summary row first
            const summaryRow = document.createElement('div');
            summaryRow.className = 'row mb-4 mt-2';
            summaryRow.innerHTML = `
                <div class="col-md-12 mb-3">
                    <div class="card bg-white border-0 shadow-sm">
                        <div class="card-body">
                            <h4 class="card-title h5">CASTLE Framework Assessment Summary</h4>
                            <p>This assessment evaluates your database schema against the industry-standard CASTLE framework, focusing on 
                            6 critical dimensions of database design best practices. Each dimension is rated from 1-5, with 1 indicating areas 
                            requiring urgent attention and 5 representing excellent implementation.</p>
                        </div>
                    </div>
                </div>
            `;
            dimensionsContainer.appendChild(summaryRow);
            
            // New format - ADW standard dimensions
            const dimensionNames = Object.keys(data.dimensions);
            
            // Add recommendations section if available with enhanced design
            if (data.recommendations && data.recommendations.length > 0) {
                const recCard = document.createElement('div');
                recCard.className = 'card mb-4 bg-white border-0 shadow-sm';
                recCard.innerHTML = `
                    <div class="card-header bg-white border-light">
                        <h4 class="h5 mb-0"><i class="fas fa-list-check me-2"></i>Overall Recommendations</h4>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            ${data.recommendations.map(rec => `
                                <li class="list-group-item border-0 px-0 py-2">
                                    <i class="fas fa-arrow-right text-danger me-2"></i>${rec}
                                </li>`).join('')}
                        </ul>
                    </div>
                `;
                dimensionsContainer.appendChild(recCard);
            }
            
            // Create a row for the dimension cards
            const dimensionsRow = document.createElement('div');
            dimensionsRow.className = 'row';
            dimensionsContainer.appendChild(dimensionsRow);
            
            dimensionNames.forEach(dimension => {
                const dimensionData = data.dimensions[dimension];
                if (!dimensionData) return;
                
                // Determine score class
                let scoreClass = '';
                if (dimensionData.score < 30) {
                    scoreClass = 'low';
                } else if (dimensionData.score < 70) {
                    scoreClass = 'medium';
                } else {
                    scoreClass = 'high';
                }
                
                // Dimension icons
                const dimensionIcons = {
                    'completeness': '<i class="fas fa-check-circle fa-2x text-primary mb-3"></i>',
                    'accuracy': '<i class="fas fa-bullseye fa-2x text-primary mb-3"></i>',
                    'structure': '<i class="fas fa-sitemap fa-2x text-primary mb-3"></i>',
                    'transparency': '<i class="fas fa-glasses fa-2x text-primary mb-3"></i>',
                    'literacy': '<i class="fas fa-book-reader fa-2x text-primary mb-3"></i>',
                    'efficiency': '<i class="fas fa-tachometer-alt fa-2x text-primary mb-3"></i>'
                };
                
                // Get badge color
                let badgeColor = scoreClass === 'low' ? 'danger' : (scoreClass === 'medium' ? 'warning' : 'success');
                
                // Calculate normalized score (1-5 scale)
                const normalizedScore = Math.max(1, Math.min(5, Math.round(dimensionData.score / 20)));
                
                // Create a modern dimension card using Bootstrap 5 cards
                const dimensionCard = document.createElement('div');
                dimensionCard.className = 'col-md-6 mb-4';
                dimensionCard.innerHTML = `
                    <div class="card bg-white h-100 border-0 shadow-sm">
                        <div class="card-body">
                            <div class="text-center">
                                ${dimensionIcons[dimension] || '<i class="fas fa-database fa-2x text-primary mb-3"></i>'}
                                <h4 class="mb-1">${dimension.charAt(0).toUpperCase() + dimension.slice(1)}</h4>
                                <div class="mb-3">
                                    <span class="badge bg-${badgeColor} px-3 py-2 rounded-pill">Score: ${normalizedScore}/5</span>
                                </div>
                            </div>
                            
                            <div class="progress mb-4 bg-light" style="height: 8px;">
                                <div class="progress-bar bg-${badgeColor}" 
                                     role="progressbar" 
                                     style="width: ${dimensionData.score}%; border-radius: 4px;" 
                                     aria-valuenow="${dimensionData.score}" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100"></div>
                            </div>
                            
                            <div class="mb-3">
                                <h5 class="h6 fw-bold text-dark mb-2">
                                    <i class="fas fa-lightbulb me-2 text-${badgeColor}"></i>Key Findings
                                </h5>
                                <p class="text-muted mb-0">${getDimensionDescription(dimension)}</p>
                            </div>
                            
                            <div class="mb-3">
                                <h5 class="h6 fw-bold text-dark mb-2">
                                    <i class="fas fa-star me-2 text-success"></i>Strengths
                                </h5>
                                <ul class="list-group list-group-flush">
                                    ${getDimensionStrengths(dimension, normalizedScore).split('</li>').join('</li>').replace(/<li>/g, 
                                        '<li class="list-group-item border-0 px-0 py-1"><i class="fas fa-check-circle text-success me-2"></i>')}
                                </ul>
                            </div>
                            
                            <div class="mb-3">
                                <h5 class="h6 fw-bold text-dark mb-2">
                                    <i class="fas fa-exclamation-triangle me-2 text-warning"></i>Areas for Improvement
                                </h5>
                                <ul class="list-group list-group-flush">
                                    ${dimensionData.issues && dimensionData.issues.length > 0 && dimensionData.issues[0] !== "No issues detected" ? 
                                        dimensionData.issues.map(issue => 
                                            `<li class="list-group-item border-0 px-0 py-1">
                                                <i class="fas fa-exclamation-circle text-warning me-2"></i>${issue}
                                            </li>`).join('') : 
                                        '<li class="list-group-item border-0 px-0 py-1"><i class="fas fa-check-circle text-success me-2"></i>No issues identified</li>'}
                                </ul>
                            </div>
                            
                            <div class="mb-3">
                                <h5 class="h6 fw-bold text-dark mb-2">
                                    <i class="fas fa-tools me-2 text-primary"></i>Recommendations
                                </h5>
                                <ul class="list-group list-group-flush">
                                    ${getRecommendationsForDimension(dimension, normalizedScore).split('</li>').join('</li>').replace(/<li>/g, 
                                        '<li class="list-group-item border-0 px-0 py-1"><i class="fas fa-arrow-right text-primary me-2"></i>')}
                                </ul>
                            </div>
                            
                            <div class="mb-3">
                                <h5 class="h6 fw-bold text-dark mb-2">
                                    <i class="fas fa-industry me-2 text-secondary"></i>Industry Standards
                                </h5>
                                <ul class="list-group list-group-flush">
                                    ${getIndustryStandardsForDimension(dimension).split('</li>').join('</li>').replace(/<li>/g, 
                                        '<li class="list-group-item border-0 px-0 py-1"><i class="fas fa-certificate text-secondary me-2"></i>')}
                                </ul>
                            </div>
                            
                            <div>
                                <h5 class="h6 fw-bold text-dark mb-2">
                                    <i class="fas fa-rocket me-2 text-info"></i>Advanced Tactics
                                </h5>
                                <ul class="list-group list-group-flush">
                                    ${getAdvancedTacticsForDimension(dimension).split('</li>').join('</li>').replace(/<li>/g, 
                                        '<li class="list-group-item border-0 px-0 py-1"><i class="fas fa-lightbulb text-info me-2"></i>')}
                                </ul>
                            </div>
                        </div>
                    </div>
                `;
                
                dimensionsRow.appendChild(dimensionCard);
            });
        } else {
            // Original CASTLE format
            const dimensions = ['compliance', 'auditability', 'security', 'traceability', 'lineage', 'ethics'];
            
            dimensions.forEach((dimension, index) => {
                const dimensionData = data[dimension];
                if (!dimensionData) return;
                
                // Determine score class
                let scoreClass = '';
                if (dimensionData.score < 2.5) {
                    scoreClass = 'low';
                } else if (dimensionData.score < 3.5) {
                    scoreClass = 'medium';
                } else {
                    scoreClass = 'high';
                }
                
                // Create dimension card
                const dimensionCard = document.createElement('div');
                dimensionCard.className = 'castle-card';
                dimensionCard.innerHTML = `
                    <div class="castle-dimension-letter">${dimension.charAt(0).toUpperCase()}</div>
                    <div class="castle-content">
                        <div class="castle-header">
                            <h4>${dimension.charAt(0).toUpperCase() + dimension.slice(1)}</h4>
                            <div class="castle-score ${scoreClass}">${dimensionData.score}</div>
                        </div>
                        
                        <div class="progress castle-progress">
                            <div class="progress-bar bg-${scoreClass === 'low' ? 'danger' : (scoreClass === 'medium' ? 'warning' : 'success')}" 
                                 role="progressbar" 
                                 style="width: ${dimensionData.score * 20}%;" 
                                 aria-valuenow="${dimensionData.score}" 
                                 aria-valuemin="0" 
                                 aria-valuemax="5">
                            </div>
                        </div>
                        
                        <div class="castle-detail-section">
                            <h5>Description</h5>
                            <p>${getDimensionDescription(dimension)}</p>
                        </div>
                        
                        <div class="castle-detail-section">
                            <h5>Key Strengths</h5>
                            <ul class="castle-list">
                                ${dimensionData.strengths && dimensionData.strengths.length > 0 ? 
                                    dimensionData.strengths.map(strength => `<li>${strength}</li>`).join('') : 
                                    '<li>No specific strengths identified</li>'}
                            </ul>
                        </div>
                        
                        <div class="castle-detail-section">
                            <h5>Key Weaknesses</h5>
                            <ul class="castle-list">
                                ${dimensionData.weaknesses && dimensionData.weaknesses.length > 0 ? 
                                    dimensionData.weaknesses.map(weakness => `<li>${weakness}</li>`).join('') : 
                                    '<li>No specific weaknesses identified</li>'}
                            </ul>
                        </div>
                        
                        <div class="castle-detail-section">
                            <h5>Improvement Recommendations</h5>
                            <ul class="castle-list">
                                ${dimensionData.recommendations && dimensionData.recommendations.length > 0 ? 
                                    dimensionData.recommendations.map(rec => `<li>${rec}</li>`).join('') : 
                                    '<li>No specific recommendations</li>'}
                            </ul>
                        </div>
                    </div>
                `;
                
                dimensionsContainer.appendChild(dimensionCard);
            });
        }
    }
    
    // Function to get description for each dimension
    function getDimensionDescription(dimension) {
        const descriptions = {
            // CASTLE dimensions
            compliance: "Adherence to data governance policies, regulatory requirements, and established standards.",
            auditability: "Ability to trace and inspect the lineage, accuracy, and integrity of data.",
            security: "Protection of data against unauthorized access, corruption, and data breaches.",
            traceability: "Capability to track data throughout its lifecycle and monitor changes.",
            lineage: "Documentation of data's origin, transformations, and movement through systems.",
            ethics: "Consideration of fairness, transparency, and responsible use of data.",
            
            // ADW dimensions
            accuracy: "Precision and correctness of the data and its structure, ensuring it correctly represents the real-world entities.",
            completeness: "Degree to which the schema provides comprehensive coverage of the domain with necessary tables and fields.",
            efficiency: "Optimization of database design for performance, storage and query processing.",
            literacy: "Clarity and comprehensibility of schema design, naming conventions, and overall documentation.",
            structure: "Quality of relational design, including normalization, relationships, and constraints.",
            transparency: "Ability to understand the schema without specialized knowledge or hidden complexities."
        };
        
        return descriptions[dimension] || "No description available";
    }
    
    // Function to get strengths based on dimension and score
    function getDimensionStrengths(dimension, score) {
        // Common strengths for high scores
        if (score >= 90) {
            return `
                <li>Exceptional implementation of industry best practices</li>
                <li>Could serve as a reference model for other databases</li>
                <li>Exhibits thoughtful design decisions throughout</li>
                <li>Positioned well for future growth and changes</li>
            `;
        } else if (score >= 70) {
            return `
                <li>Consistently follows good design practices</li>
                <li>Built on solid database architecture principles</li>
                <li>Few critical issues that would impact performance</li>
            `;
        } else if (score >= 50) {
            return `
                <li>Has fundamental structure in place</li>
                <li>Shows understanding of basic database principles</li>
                <li>Provides a foundation that can be improved</li>
            `;
        }
        
        // Dimension-specific strengths for low scores
        const lowScoreStrengths = {
            completeness: `
                <li>Basic table structures are defined</li>
                <li>Core entities of the domain are represented</li>
            `,
            accuracy: `
                <li>Most columns use appropriate general data types</li>
                <li>Primary entities have correct identifier fields</li>
            `,
            structure: `
                <li>Foundational tables are established</li>
                <li>Some relationships between entities are defined</li>
            `,
            transparency: `
                <li>Table names generally reflect their purpose</li>
                <li>Schema follows a consistent naming pattern</li>
            `,
            literacy: `
                <li>Names are generally understandable</li>
                <li>Table structure is logical for the domain</li>
            `,
            efficiency: `
                <li>Database operations are functional</li>
                <li>Basic performance considerations are evident</li>
            `
        };
        
        return lowScoreStrengths[dimension] || `
            <li>Basic database structure is in place</li>
            <li>Framework exists for future improvements</li>
        `;
    }
    
    // Function to get recommendations for each dimension based on score
    function getRecommendationsForDimension(dimension, score) {
        // Low scores need more detailed recommendations
        if (score < 50) {
            const detailedRecommendations = {
                completeness: `
                    <li>Add primary keys to all tables missing them</li>
                    <li>Introduce tracking fields (created_at, updated_at) for data lifecycle management</li>
                    <li>Add missing domain entities that are referenced but not defined</li>
                    <li>Implement required constraints on mandatory fields</li>
                `,
                accuracy: `
                    <li>Revise data types to match the actual content they will store</li>
                    <li>Add appropriate constraints for valid value ranges</li>
                    <li>Implement check constraints for data validation</li>
                    <li>Consider using ENUM types for fields with fixed value sets</li>
                `,
                structure: `
                    <li>Normalize tables to reduce data redundancy</li>
                    <li>Establish appropriate foreign key relationships</li>
                    <li>Split tables with mixed concerns into focused entities</li>
                    <li>Review and resolve circular dependencies</li>
                `,
                transparency: `
                    <li>Rename cryptic table and column names to be more descriptive</li>
                    <li>Remove or document special prefixes and abbreviations</li>
                    <li>Add comments to explain non-obvious design decisions</li>
                    <li>Standardize naming conventions across the schema</li>
                `,
                literacy: `
                    <li>Replace technical jargon with business terminology where appropriate</li>
                    <li>Use full words instead of abbreviations in names</li>
                    <li>Add descriptive comments for complex relationships</li>
                    <li>Create complementary documentation explaining the domain model</li>
                `,
                efficiency: `
                    <li>Add indexes for columns frequently used in filters and joins</li>
                    <li>Review and optimize data types for storage efficiency</li>
                    <li>Consider using appropriate normalization to reduce redundancy</li>
                    <li>Add covering indexes for common queries</li>
                `
            };
            return detailedRecommendations[dimension] || `
                <li>Review and align with database design best practices</li>
                <li>Consider a comprehensive redesign with expert input</li>
                <li>Implement systematic improvements incrementally</li>
            `;
        } 
        // Medium scores need targeted improvements
        else if (score < 75) {
            const targetedRecommendations = {
                completeness: `
                    <li>Add audit fields to tables missing tracking information</li>
                    <li>Review for missing attributes in key entities</li>
                    <li>Consider domain completeness beyond technical structure</li>
                `,
                accuracy: `
                    <li>Refine data type precision for numeric values</li>
                    <li>Add constraints for data integrity where missing</li>
                    <li>Improve validation mechanisms for complex data types</li>
                `,
                structure: `
                    <li>Address partial normalization issues in specific tables</li>
                    <li>Enhance relationship definitions with proper constraints</li>
                    <li>Optimize table structure for the most common access patterns</li>
                `,
                transparency: `
                    <li>Improve naming consistency across related tables</li>
                    <li>Add comprehensive documentation on schema design</li>
                    <li>Make implicit relationships explicit through naming</li>
                `,
                literacy: `
                    <li>Replace remaining technical abbreviations with business terms</li>
                    <li>Enhance documentation with domain-specific explanations</li>
                    <li>Add context for specialized terminology</li>
                `,
                efficiency: `
                    <li>Optimize existing indexes for query performance</li>
                    <li>Review and consolidate redundant indexes</li>
                    <li>Consider partitioning for very large tables</li>
                `
            };
            return targetedRecommendations[dimension] || `
                <li>Focus on addressing specific weak points identified</li>
                <li>Introduce systematic review processes</li>
                <li>Apply best practices more consistently</li>
            `;
        }
        // High scores need refinement
        else {
            const refinementRecommendations = {
                completeness: `
                    <li>Consider adding optional but valuable business metadata</li>
                    <li>Prepare for future expansion with flexible schema elements</li>
                    <li>Document the completeness rationale for the domain</li>
                `,
                accuracy: `
                    <li>Review edge cases for data type handling</li>
                    <li>Consider specialized types for domain-specific data</li>
                    <li>Implement advanced validation for complex business rules</li>
                `,
                structure: `
                    <li>Fine-tune schema for emerging access patterns</li>
                    <li>Review for subtle denormalization opportunities</li>
                    <li>Consider specialized indexing strategies for complex queries</li>
                `,
                transparency: `
                    <li>Document design patterns and naming standards used</li>
                    <li>Create visual schema documentation for stakeholders</li>
                    <li>Add business context to technical documentation</li>
                `,
                literacy: `
                    <li>Review for domain terminology alignment with business users</li>
                    <li>Create glossaries linking technical and business terms</li>
                    <li>Enhance documentation with usage examples</li>
                `,
                efficiency: `
                    <li>Implement advanced indexing strategies for complex queries</li>
                    <li>Consider materialized views for reporting workloads</li>
                    <li>Optimize for specific traffic and usage patterns</li>
                `
            };
            return refinementRecommendations[dimension] || `
                <li>Focus on excellence through continuous refinement</li>
                <li>Document the reasoning behind design decisions</li>
                <li>Prepare for future scaling and evolution</li>
            `;
        }
    }
    
    // Function to get industry standards for each dimension
    function getIndustryStandardsForDimension(dimension) {
        const standards = {
            completeness: `
                <li>ISO/IEC 25012 - Data Quality Model</li>
                <li>DAMA DMBOK Data Completeness Framework</li>
                <li>ADW Data Completeness Specification v3.2</li>
            `,
            accuracy: `
                <li>IEEE 730 Data Accuracy Standards</li>
                <li>ISO 8000 Data Quality Series</li>
                <li>ADW Data Type Selection Guide</li>
            `,
            structure: `
                <li>ANSI Database Design Standards</li>
                <li>Codd's 12 Rules for Relational Databases</li>
                <li>Industry-standard Normalization Forms (1NF-5NF)</li>
            `,
            transparency: `
                <li>ISO/IEC 25024 Measurement of Data Quality</li>
                <li>DAMA Data Naming Standards</li>
                <li>ADW Transparency Framework</li>
            `,
            literacy: `
                <li>IEEE Software Documentation Standards</li>
                <li>ISO 9126 Documentation Quality Metrics</li>
                <li>ADW Schema Readability Guidelines</li>
            `,
            efficiency: `
                <li>TPC Performance Benchmarks</li>
                <li>ISO/IEC 25023 Performance Efficiency Measures</li>
                <li>ADW Data Access Optimization Framework</li>
            `
        };
        
        return standards[dimension] || `
            <li>ISO 9001 Quality Management Systems</li>
            <li>DAMA Data Management Body of Knowledge</li>
            <li>ADW Enterprise Data Standards</li>
        `;
    }
    
    // Function to get advanced tactics for each dimension
    function getAdvancedTacticsForDimension(dimension) {
        const tactics = {
            completeness: `
                <li>Implement automated schema completeness verification</li>
                <li>Develop domain-driven design approach to schema evolution</li>
                <li>Use AI-driven schema completion suggestions</li>
            `,
            accuracy: `
                <li>Deploy runtime type enforcement and validation</li>
                <li>Implement smart constraints with business logic</li>
                <li>Use domain-specific data types with custom validation</li>
            `,
            structure: `
                <li>Apply polyglot persistence for mixed workloads</li>
                <li>Implement temporal database patterns for historical data</li>
                <li>Use graph structures for complex relationships</li>
            `,
            transparency: `
                <li>Create interactive schema visualization tools</li>
                <li>Implement automated documentation generation</li>
                <li>Deploy schema changes with detailed change manifests</li>
            `,
            literacy: `
                <li>Build natural language interfaces to database documentation</li>
                <li>Implement contextual schema exploration tools</li>
                <li>Generate business-friendly schema narratives</li>
            `,
            efficiency: `
                <li>Implement predictive query optimization</li>
                <li>Use workload-aware indexing strategies</li>
                <li>Deploy query performance regression testing</li>
            `
        };
        
        return tactics[dimension] || `
            <li>Implement continuous schema evolution framework</li>
            <li>Deploy automated quality assessment pipelines</li>
            <li>Use machine learning for schema optimization</li>
        `;
    }
    
    // Function to get selected tables
    function getSelectedTables() {
        const checkboxes = document.querySelectorAll('.table-checkbox:checked');
        return Array.from(checkboxes).map(checkbox => checkbox.value);
    }
});