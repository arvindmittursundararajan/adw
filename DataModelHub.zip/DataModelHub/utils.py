"""
Utility functions for Pendulum.io
"""

import re
import logging
import json
import requests
from config import GEMINI_API_KEY, GEMINI_API_URL

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_gemini_response(prompt):
    """
    Get a response from the Google Gemini API.
    
    Args:
        prompt (str): The prompt to send to the API
    
    Returns:
        str: The text response from the API
    """
    # Use hardcoded API key and URL as per requirements
    api_key = GEMINI_API_KEY
    url = f"{GEMINI_API_URL}?key={api_key}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    data = {
        "contents": [
            {
                "parts": [
                    {
                        "text": prompt
                    }
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.4,
            "topP": 0.8,
            "topK": 40,
            "maxOutputTokens": 8192
        }
    }
    
    try:
        response = requests.post(url, headers=headers, json=data)
        
        if response.status_code != 200:
            logger.error(f"Error from Gemini API: {response.status_code}, {response.text}")
            return f"Error: API returned status code {response.status_code}"
        
        response_json = response.json()
        
        if "candidates" not in response_json or not response_json["candidates"]:
            logger.error(f"Unexpected API response format: {response_json}")
            return "Error: Unexpected API response format"
        
        text_response = response_json["candidates"][0]["content"]["parts"][0]["text"]
        return clean_text(text_response)
        
    except Exception as e:
        logger.error(f"Exception calling Gemini API: {str(e)}")
        return f"Error: {str(e)}"

def clean_text(text):
    """
    Clean and format text from Gemini API response.
    
    Args:
        text (str): The raw text from the API response
    
    Returns:
        str: The cleaned text
    """
    # Remove any extra whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    # Return the cleaned text
    return text.strip()