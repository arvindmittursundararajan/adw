// Pendulum.io - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Pendulum.io - Main JavaScript loaded');
    
    // Initialize Bootstrap tooltips - default placement on top
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        // Set default placement to top if not specified
        if (!tooltipTriggerEl.hasAttribute('data-bs-placement')) {
            tooltipTriggerEl.setAttribute('data-bs-placement', 'top');
        }
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize Bootstrap popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Function to show loading overlay
    window.showLoading = function(message = 'Processing...') {
        let overlay = document.createElement('div');
        overlay.className = 'loading-overlay';
        overlay.id = 'loadingOverlay';
        
        let spinnerContainer = document.createElement('div');
        spinnerContainer.className = 'spinner-container';
        
        let spinner = document.createElement('div');
        spinner.className = 'spinner-border text-primary';
        spinner.setAttribute('role', 'status');
        
        let spinnerSr = document.createElement('span');
        spinnerSr.className = 'visually-hidden';
        spinnerSr.textContent = 'Loading...';
        
        let spinnerText = document.createElement('div');
        spinnerText.className = 'spinner-text';
        spinnerText.textContent = message;
        
        spinner.appendChild(spinnerSr);
        spinnerContainer.appendChild(spinner);
        spinnerContainer.appendChild(spinnerText);
        overlay.appendChild(spinnerContainer);
        
        document.body.appendChild(overlay);
    };
    
    // Function to hide loading overlay
    window.hideLoading = function() {
        let overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.remove();
        }
    };
    
    // Common form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // Function to render markdown content
    window.renderMarkdown = function(markdownText, targetElement) {
        if (!markdownText || !targetElement) return;
        
        try {
            // Set marked options for security
            marked.setOptions({
                sanitize: true,
                breaks: true
            });
            
            const htmlContent = marked.parse(markdownText);
            targetElement.innerHTML = htmlContent;
            
            // Add Bootstrap classes to tables
            const tables = targetElement.querySelectorAll('table');
            tables.forEach(table => {
                table.classList.add('table', 'table-striped', 'table-bordered');
            });
            
            // Add Bootstrap classes to pre/code blocks
            const codeBlocks = targetElement.querySelectorAll('pre code');
            codeBlocks.forEach(block => {
                const pre = block.parentNode;
                pre.classList.add('bg-light', 'p-3', 'rounded');
            });
        } catch (e) {
            console.error('Error rendering markdown:', e);
            targetElement.textContent = markdownText;
        }
    };
});
