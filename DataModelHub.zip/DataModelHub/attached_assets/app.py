import os
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from utils import (
    get_available_databases, 
    get_database_tables, 
    analyze_tables, 
    generate_diagram,
    get_database_schema
)
from config import SQLITE_DB_PATH

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "pendulum-io-secret-key")

@app.route('/')
def index():
    """Render the main page with database selection."""
    databases = get_available_databases()
    return render_template('index.html', databases=databases)

@app.route('/get_tables', methods=['POST'])
def get_tables():
    """Get tables from the selected database."""
    database = request.form.get('database')
    if not database:
        return jsonify({"error": "No database selected"}), 400
    
    db_path = os.path.join(SQLITE_DB_PATH, database)
    if not os.path.exists(db_path):
        return jsonify({"error": "Database file not found"}), 404
    
    tables = get_database_tables(db_path)
    return jsonify({"tables": tables})

@app.route('/analyze', methods=['POST'])
def analyze():
    """Analyze selected tables."""
    database = request.form.get('database')
    tables = request.form.getlist('tables[]')
    analysis_type = request.form.get('analysis_type')
    
    if not database or not tables:
        return jsonify({"error": "Database or tables not specified"}), 400
    
    if not analysis_type:
        return jsonify({"error": "Analysis type not specified"}), 400
    
    db_path = os.path.join(SQLITE_DB_PATH, database)
    if not os.path.exists(db_path):
        return jsonify({"error": "Database file not found"}), 404
    
    # Store selected database and tables in session for visualization page
    session['selected_database'] = database
    session['selected_tables'] = tables
    
    # Perform analysis
    analysis_result = analyze_tables(db_path, tables, analysis_type)
    
    return jsonify({"result": analysis_result})

@app.route('/visualization')
def visualization():
    """Render the visualization page."""
    selected_database = session.get('selected_database')
    selected_tables = session.get('selected_tables', [])
    
    if not selected_database or not selected_tables:
        flash("Please select a database and tables first.")
        return redirect(url_for('index'))
    
    db_path = os.path.join(SQLITE_DB_PATH, selected_database)
    if not os.path.exists(db_path):
        flash("Selected database not found.")
        return redirect(url_for('index'))
    
    return render_template(
        'visualization.html', 
        database=selected_database, 
        tables=selected_tables
    )

@app.route('/mapping_sheet')
def mapping_sheet():
    """Render the mapping sheet page."""
    selected_database = session.get('selected_database')
    selected_tables = session.get('selected_tables', [])
    
    if not selected_database or not selected_tables:
        flash("Please select a database and tables first.")
        return redirect(url_for('index'))
    
    db_path = os.path.join(SQLITE_DB_PATH, selected_database)
    if not os.path.exists(db_path):
        flash("Selected database not found.")
        return redirect(url_for('index'))
    
    return render_template(
        'mapping_sheet.html', 
        database=selected_database, 
        tables=selected_tables
    )

@app.route('/generate_diagram', methods=['POST'])
def generate_diagram_endpoint():
    """Generate a diagram for the selected tables."""
    database = request.form.get('database')
    tables = request.form.getlist('tables[]')
    diagram_type = request.form.get('diagram_type')
    
    if not database or not tables:
        return jsonify({"error": "Database or tables not specified"}), 400
    
    if not diagram_type:
        return jsonify({"error": "Diagram type not specified"}), 400
    
    db_path = os.path.join(SQLITE_DB_PATH, database)
    if not os.path.exists(db_path):
        return jsonify({"error": "Database file not found"}), 404
    
    # Generate diagram
    diagram_code = generate_diagram(db_path, tables, diagram_type)
    
    return jsonify({"diagram_code": diagram_code})

@app.route('/generate_mapping_sheet', methods=['POST'])
def generate_mapping_sheet_endpoint():
    """Generate mapping sheet data for the selected tables."""
    database = request.form.get('database')
    tables = request.form.getlist('tables[]')
    
    if not database or not tables:
        return jsonify({"error": "Database or tables not specified"}), 400
    
    db_path = os.path.join(SQLITE_DB_PATH, database)
    if not os.path.exists(db_path):
        return jsonify({"error": "Database file not found"}), 404
    
    # Get schema information
    schema = get_database_schema(db_path, tables)
    
    # For debugging
    print(f"Processing mapping sheet for tables: {tables}")
    
    # Generate mapping sheet data
    # This implementation must match the custom generate_mapping_sheet function structure in utils.py
    # Directly implement the functionality here
    tables_data = {}
    
    # For each selected table in the schema
    for table_name in tables:
        if table_name in schema:
            # Create a table entry with empty columns
            tables_data[table_name] = {
                'table_name': table_name,
                'columns': []
            }
            
            # Add column information
            for column in schema[table_name]['columns']:
                column_data = {
                    'name': column['name'],  # Existing column name
                    'data_type': column['type'],  # Existing data type
                    'new_column_name': column['name'],  # Suggested new column name (same as current by default)
                    'new_data_type': column['type'],  # Suggested new data type (same as current by default)
                    'recommendations': [  # 3-4 lines of recommendations
                        f"Consider validating {column['name']} input for quality assurance.",
                        f"Add appropriate indices if this field is frequently queried.",
                        f"Document the business context and data constraints for this field.",
                        f"Review data access patterns to optimize performance."
                    ]
                }
                tables_data[table_name]['columns'].append(column_data)
    
    # Convert dictionary to list for the final result
    mapping_data = list(tables_data.values())
    
    return jsonify({"mapping_data": mapping_data})

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors."""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors."""
    return render_template('500.html'), 500
