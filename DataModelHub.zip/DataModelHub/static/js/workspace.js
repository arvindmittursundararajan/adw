document.addEventListener('DOMContentLoaded', function() {
    // Toggle file type specific options
    const databaseFileInput = document.getElementById('databaseFile');
    const schemaTextOption = document.querySelector('.schema-text-option');
    
    if (databaseFileInput) {
        databaseFileInput.addEventListener('change', function() {
            const fileName = this.value.toLowerCase();
            if (fileName.endsWith('.txt')) {
                schemaTextOption.style.display = 'block';
            } else {
                schemaTextOption.style.display = 'none';
            }
        });
    }
    
    // Database tables toggle
    const toggleButtons = document.querySelectorAll('.database-tables-toggle');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const dbName = this.getAttribute('data-db');
            const tablesContainer = document.getElementById(`tables-${dbName}`);
            
            if (tablesContainer.style.display === 'none') {
                // Show tables container
                tablesContainer.style.display = 'block';
                
                // Load tables if not already loaded
                if (tablesContainer.querySelector('.tables-list').innerHTML === '') {
                    loadTablesForDatabase(dbName);
                }
            } else {
                tablesContainer.style.display = 'none';
            }
        });
    });
    
    // Handle database selection
    const databaseCheckboxes = document.querySelectorAll('.database-select');
    const actionButtons = {
        analyze: document.getElementById('analyze-selected'),
        visualize: document.getElementById('visualize-selected'),
        mapping: document.getElementById('mapping-selected'),
        compliance: document.getElementById('compliance-selected'),
        querywiz: document.getElementById('querywiz-selected')
    };
    
    databaseCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateActionButtons();
            
            // If at least one database is selected, trigger domain analysis
            if (getSelectedDatabases().length > 0) {
                generateDomainAnalysis();
            } else {
                // Hide domain analysis content
                document.getElementById('domain-overview').style.display = 'none';
            }
        });
    });
    
    // Handle table selection
    document.addEventListener('change', function(e) {
        if (e.target && e.target.classList.contains('table-select')) {
            updateActionButtons();
        }
    });
    
    // Setup action buttons
    if (actionButtons.analyze) {
        actionButtons.analyze.addEventListener('click', function() {
            const selectedData = getSelectedDatabasesAndTables();
            if (Object.keys(selectedData.databases).length > 0) {
                // Redirect to dashboard with all selected databases
                const selectedDbs = Object.keys(selectedData.databases);
                const queryParams = new URLSearchParams();
                
                selectedDbs.forEach(db => {
                    queryParams.append('database', db);
                    
                    // Add tables for this database if any are selected
                    if (selectedData.tables[db] && selectedData.tables[db].length > 0) {
                        selectedData.tables[db].forEach(table => {
                            queryParams.append('tables', table);
                        });
                    }
                });
                
                window.location.href = `/dashboard?${queryParams.toString()}`;
            }
        });
    }
    
    if (actionButtons.visualize) {
        actionButtons.visualize.addEventListener('click', function() {
            const selectedData = getSelectedDatabasesAndTables();
            if (Object.keys(selectedData.databases).length > 0) {
                // Redirect to visualization with all selected databases
                const selectedDbs = Object.keys(selectedData.databases);
                const queryParams = new URLSearchParams();
                
                selectedDbs.forEach(db => {
                    queryParams.append('database', db);
                    
                    // Add tables for this database if any are selected
                    if (selectedData.tables[db] && selectedData.tables[db].length > 0) {
                        selectedData.tables[db].forEach(table => {
                            queryParams.append('tables', table);
                        });
                    }
                });
                
                window.location.href = `/visualization?${queryParams.toString()}`;
            }
        });
    }
    
    if (actionButtons.mapping) {
        actionButtons.mapping.addEventListener('click', function() {
            const selectedData = getSelectedDatabasesAndTables();
            if (Object.keys(selectedData.databases).length > 0) {
                // Redirect to mapping sheet with all selected databases
                const selectedDbs = Object.keys(selectedData.databases);
                const queryParams = new URLSearchParams();
                
                selectedDbs.forEach(db => {
                    queryParams.append('database', db);
                    
                    // Add tables for this database if any are selected
                    if (selectedData.tables[db] && selectedData.tables[db].length > 0) {
                        selectedData.tables[db].forEach(table => {
                            queryParams.append('tables', table);
                        });
                    }
                });
                
                window.location.href = `/mapping_sheet?${queryParams.toString()}`;
            }
        });
    }
    
    if (actionButtons.compliance) {
        actionButtons.compliance.addEventListener('click', function() {
            const selectedData = getSelectedDatabasesAndTables();
            if (Object.keys(selectedData.databases).length > 0) {
                // Redirect to compliance with all selected databases
                const selectedDbs = Object.keys(selectedData.databases);
                const queryParams = new URLSearchParams();
                
                selectedDbs.forEach(db => {
                    queryParams.append('database', db);
                    
                    // Add tables for this database if any are selected
                    if (selectedData.tables[db] && selectedData.tables[db].length > 0) {
                        selectedData.tables[db].forEach(table => {
                            queryParams.append('tables', table);
                        });
                    }
                });
                
                window.location.href = `/compliance?${queryParams.toString()}`;
            }
        });
    }
    
    if (actionButtons.querywiz) {
        actionButtons.querywiz.addEventListener('click', function() {
            const selectedData = getSelectedDatabasesAndTables();
            if (Object.keys(selectedData.databases).length > 0) {
                // Redirect to querywiz with first selected database
                const firstDb = Object.keys(selectedData.databases)[0];
                window.location.href = `/querywiz?database=${firstDb}`;
            }
        });
    }
});

// Load tables for a specific database
function loadTablesForDatabase(dbName) {
    const tablesContainer = document.getElementById(`tables-${dbName}`);
    const loadingElement = tablesContainer.querySelector('.tables-loading');
    const tablesListElement = tablesContainer.querySelector('.tables-list');
    
    // Show loading indicator
    loadingElement.style.display = 'block';
    
    // Fetch tables from the server
    const formData = new FormData();
    formData.append('database', dbName);
    
    fetch('/get_tables', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading indicator
        loadingElement.style.display = 'none';
        
        // Check if we got tables back
        if (data.tables && data.tables.length > 0) {
            // Create checkbox for each table
            const tablesHtml = data.tables.map(table => {
                return `
                <div class="table-item">
                    <input type="checkbox" class="table-select table-checkbox" 
                           id="table-${dbName}-${table}" 
                           data-db="${dbName}" 
                           data-table="${table}">
                    <label for="table-${dbName}-${table}">${table}</label>
                </div>`;
            }).join('');
            
            tablesListElement.innerHTML = tablesHtml;
        } else {
            tablesListElement.innerHTML = '<div class="text-muted">No tables found in this database.</div>';
        }
    })
    .catch(error => {
        loadingElement.style.display = 'none';
        tablesListElement.innerHTML = `<div class="text-danger">Error loading tables: ${error}</div>`;
    });
}

// Update action buttons based on selection
function updateActionButtons() {
    const selectedData = getSelectedDatabasesAndTables();
    const hasSelection = Object.keys(selectedData.databases).length > 0;
    
    // Enable/disable buttons based on selection
    const actionButtons = [
        document.getElementById('analyze-selected'),
        document.getElementById('visualize-selected'),
        document.getElementById('mapping-selected'),
        document.getElementById('compliance-selected'),
        document.getElementById('querywiz-selected')
    ];
    
    actionButtons.forEach(button => {
        if (button) {
            button.disabled = !hasSelection;
        }
    });
}

// Get selected databases
function getSelectedDatabases() {
    const checkboxes = document.querySelectorAll('.database-select:checked');
    return Array.from(checkboxes).map(checkbox => checkbox.getAttribute('data-name'));
}

// Get selected databases and tables
function getSelectedDatabasesAndTables() {
    const result = {
        databases: {},
        tables: {}
    };
    
    // First get all selected databases
    const selectedDatabases = getSelectedDatabases();
    
    selectedDatabases.forEach(db => {
        result.databases[db] = true;
        result.tables[db] = [];
    });
    
    // Then get all selected tables for each database
    selectedDatabases.forEach(db => {
        const tableCheckboxes = document.querySelectorAll(`.table-select[data-db="${db}"]:checked`);
        result.tables[db] = Array.from(tableCheckboxes).map(checkbox => checkbox.getAttribute('data-table'));
    });
    
    return result;
}

// Generate domain analysis for selected databases
function generateDomainAnalysis() {
    const selectedData = getSelectedDatabasesAndTables();
    const selectedDatabases = Object.keys(selectedData.databases);
    
    if (selectedDatabases.length === 0) return;
    
    // Show loading state
    document.getElementById('domain-overview').style.display = 'none';
    document.getElementById('domain-loading').style.display = 'block';
    
    // Prepare form data
    const formData = new FormData();
    
    // Add databases
    selectedDatabases.forEach(db => {
        formData.append('database[]', db);
    });
    
    // Add tables for each database
    const pendingTableLoads = [];
    
    selectedDatabases.forEach(db => {
        // Check if tables are loaded in the UI
        const tablesContainer = document.getElementById(`tables-${db}`);
        const tablesListElement = tablesContainer ? tablesContainer.querySelector('.tables-list') : null;
        const tablesLoaded = tablesListElement && tablesListElement.innerHTML !== '';
        
        if (tablesLoaded) {
            // If tables are loaded, use selected tables or all tables
            const tableCheckboxes = document.querySelectorAll(`.table-select[data-db="${db}"]:checked`);
            const selectedTables = Array.from(tableCheckboxes).map(checkbox => checkbox.getAttribute('data-table'));
            
            if (selectedTables.length > 0) {
                // Use selected tables
                selectedTables.forEach(table => {
                    formData.append(`tables_${db}[]`, table);
                });
            } else {
                // Use all tables
                const allTableCheckboxes = document.querySelectorAll(`.table-select[data-db="${db}"]`);
                const allTables = Array.from(allTableCheckboxes).map(checkbox => checkbox.getAttribute('data-table'));
                
                if (allTables.length > 0) {
                    allTables.forEach(table => {
                        formData.append(`tables_${db}[]`, table);
                    });
                } else {
                    // Fallback: let server get all tables
                    formData.append(`tables_${db}[]`, '*');
                }
            }
        } else {
            // If tables aren't loaded, let server get all tables
            formData.append(`tables_${db}[]`, '*');
        }
    });
    
    // Make request to server
    fetch('/analyze_domain', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading
        document.getElementById('domain-loading').style.display = 'none';
        document.getElementById('domain-overview').style.display = 'block';
        
        if (data.error) {
            // Show error
            document.getElementById('domain-summary').innerHTML = `<div class="text-danger">${data.error}</div>`;
            document.getElementById('visualize-domain').style.display = 'none';
        } else {
            // Show results - description in summary, diagram hidden for modal
            document.getElementById('domain-summary').innerHTML = data.description;
            
            // Store diagram in hidden element for modal
            const diagramContainer = document.createElement('div');
            diagramContainer.id = 'domain-diagram';
            diagramContainer.style.display = 'none';
            
            if (data.diagram_code) {
                // Create new container and render diagram
                document.body.appendChild(diagramContainer);
                
                // Use mermaid to render diagram
                try {
                    mermaid.render('mermaid-svg', data.diagram_code, (svgCode) => {
                        diagramContainer.innerHTML = svgCode;
                        document.getElementById('visualize-domain').style.display = 'inline-block';
                    });
                } catch (error) {
                    console.error('Error rendering mermaid diagram:', error);
                    diagramContainer.innerHTML = '<div class="text-danger">Error rendering diagram</div>';
                    document.getElementById('visualize-domain').style.display = 'none';
                }
            } else {
                diagramContainer.innerHTML = '<div class="text-muted">No diagram available</div>';
                document.getElementById('visualize-domain').style.display = 'none';
            }
        }
    })
    .catch(error => {
        // Hide loading and show error
        document.getElementById('domain-loading').style.display = 'none';
        document.getElementById('domain-overview').style.display = 'block';
        document.getElementById('domain-summary').innerHTML = `<div class="text-danger">Error: ${error}</div>`;
        document.getElementById('visualize-domain').style.display = 'none';
    });
}
