// ADW Workbench - Mapping Sheet JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Mapping Sheet JS loaded');
    
    const databaseSelect = document.getElementById('database');
    const tablesList = document.getElementById('tablesList');
    const generateMappingBtn = document.getElementById('generateMappingBtn');
    const mappingContainer = document.getElementById('mappingContainer');
    const emptyState = document.getElementById('emptyState');
    const exportCsvBtn = document.getElementById('exportCsvBtn');
    
    // Load tables when a database is selected
    if (databaseSelect) {
        databaseSelect.addEventListener('change', function() {
            const database = this.value;
            if (database) {
                loadTables(database);
            } else {
                tablesList.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-muted">Select a database to show tables</p>
                    </div>
                `;
            }
        });
        
        // Load tables for the pre-selected database (if any)
        if (databaseSelect.value) {
            loadTables(databaseSelect.value);
        }
    }
    
    // Handle generate mapping sheet button click
    if (generateMappingBtn) {
        generateMappingBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const database = databaseSelect.value;
            const selectedTables = getSelectedTables();
            
            if (!database) {
                alert('Please select a database');
                return;
            }
            
            if (selectedTables.length === 0) {
                alert('Please select at least one table');
                return;
            }
            
            generateMappingSheet();
        });
    }
    
    // Handle export CSV button click
    if (exportCsvBtn) {
        exportCsvBtn.addEventListener('click', function() {
            // Get all the table data
            const tables = document.querySelectorAll('.table-mapping');
            if (tables.length === 0) {
                alert('No mapping data to export. Please generate a mapping sheet first.');
                return;
            }
            
            console.log('Export CSV button clicked, found', tables.length, 'tables');
            let csvContent = 'Database,Table Business Name,Table Technical Name,Table Description,Entity Type,Classification,Column Business Name,Column Technical Name,Data Type,Description,Domain Values,Business Rules,Sample Values\n';
            
            const database = databaseSelect.value;
            
            tables.forEach(table => {
                const tableName = table.querySelector('.table-header').textContent.trim();
                console.log('Processing table:', tableName);
                
                // Get table metadata
                const metaItems = table.querySelectorAll('.meta-item');
                let businessName = '';
                let description = '';
                let entityType = '';
                let classification = '';
                
                metaItems.forEach(item => {
                    const label = item.querySelector('.meta-label').textContent.trim();
                    const value = item.textContent.replace(label, '').trim();
                    
                    if (label === 'Business Name:') {
                        businessName = value;
                    } else if (label === 'Description:') {
                        description = value;
                    } else if (label === 'Entity Type:') {
                        entityType = value;
                    } else if (label === 'Classification:') {
                        classification = value;
                    }
                });
                
                // Get column data
                const columns = table.querySelectorAll('tbody tr');
                console.log('Found', columns.length, 'columns');
                
                if (columns.length === 0) {
                    // If no columns, still add the table row
                    csvContent += `"${database}","${businessName}","${tableName}","${description}","${entityType}","${classification}","","","","","","",""\n`;
                } else {
                    columns.forEach(column => {
                        const cells = column.querySelectorAll('td');
                        const colBusinessName = cells[0].textContent.trim();
                        const colTechnicalName = cells[1].textContent.trim();
                        const dataType = cells[2].textContent.trim();
                        const colDescription = cells[3].textContent.trim();
                        const domainValues = cells[4].textContent.trim();
                        const businessRules = cells[5].textContent.trim();
                        const sampleValues = cells[6].textContent.trim();
                        
                        // Escape quotes in text fields
                        const escapedDesc = colDescription.replace(/"/g, '""');
                        const escapedDomainValues = domainValues.replace(/"/g, '""');
                        const escapedRules = businessRules.replace(/"/g, '""');
                        const escapedSampleValues = sampleValues.replace(/"/g, '""');
                        
                        csvContent += `"${database}","${businessName}","${tableName}","${description}","${entityType}","${classification}","${colBusinessName}","${colTechnicalName}","${dataType}","${escapedDesc}","${escapedDomainValues}","${escapedRules}","${escapedSampleValues}"\n`;
                    });
                }
            });
            
            console.log('CSV Content prepared, length:', csvContent.length);
            
            try {
                // Create and trigger download
                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                console.log('Blob created', blob.size, 'bytes');
                
                const url = URL.createObjectURL(blob);
                console.log('URL created:', url);
                
                // Use a direct click approach with timeout to ensure browser processes it
                setTimeout(() => {
                    try {
                        const link = document.createElement('a');
                        link.setAttribute('href', url);
                        link.setAttribute('download', `${database}_mapping_sheet.csv`);
                        document.body.appendChild(link);
                        console.log('Clicking download link');
                        link.click();
                        
                        // Clean up
                        setTimeout(() => {
                            document.body.removeChild(link);
                            URL.revokeObjectURL(url);
                            console.log('Download process completed');
                        }, 100);
                    } catch (innerError) {
                        console.error('Error in download process:', innerError);
                        alert('Error creating download. Please try again.');
                    }
                }, 100);
            } catch (error) {
                console.error('Error creating CSV file:', error);
                alert('Failed to generate CSV file. Please try again.');
            }
        });
    }
    
    // Function to print the mapping sheet
    function printMappingSheet() {
        window.print();
    }
    
    // Function to load tables for a database
    function loadTables(database) {
        tablesList.innerHTML = `
            <div class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted mt-2">Loading tables...</p>
            </div>
        `;
        
        const formData = new FormData();
        formData.append('database', database);
        
        fetch('/get_tables', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                tablesList.innerHTML = `
                    <div class="alert alert-danger" role="alert">
                        ${data.error}
                    </div>
                `;
                return;
            }
            
            renderTablesList(data.tables);
        })
        .catch(error => {
            console.error('Error loading tables:', error);
            
            tablesList.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    Failed to load tables. Please try again.
                </div>
            `;
        });
    }
    
    // Function to render the tables list
    function renderTablesList(tables) {
        if (!tables || tables.length === 0) {
            tablesList.innerHTML = `
                <div class="text-center py-3">
                    <p class="text-muted">No tables found in this database</p>
                </div>
            `;
            return;
        }
        
        let tablesHtml = '';
        
        tables.forEach(table => {
            tablesHtml += `
                <div class="form-check">
                    <input class="form-check-input table-checkbox" type="checkbox" value="${table}" id="table-${table}">
                    <label class="form-check-label" for="table-${table}">
                        ${table}
                    </label>
                </div>
            `;
        });
        
        tablesHtml += `
            <div class="mt-3">
                <button type="button" id="selectAllTables" class="btn btn-sm btn-outline-primary me-2">Select All</button>
                <button type="button" id="deselectAllTables" class="btn btn-sm btn-outline-secondary">Deselect All</button>
            </div>
        `;
        
        tablesList.innerHTML = tablesHtml;
        
        // Add event listeners for select/deselect all buttons
        document.getElementById('selectAllTables').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.table-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
        });
        
        document.getElementById('deselectAllTables').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.table-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = false;
            });
        });
    }
    
    // Function to generate mapping sheet
    function generateMappingSheet() {
        const database = databaseSelect.value;
        const selectedTables = getSelectedTables();
        
        if (!database || selectedTables.length === 0) {
            return;
        }
        
        // Show loading state
        mappingContainer.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Generating mapping sheet...</p>
            </div>
        `;
        
        mappingContainer.style.display = 'block';
        emptyState.style.display = 'none';
        
        // Enable export button when we start generating
        exportCsvBtn.disabled = false;
        
        const formData = new FormData();
        formData.append('database', database);
        selectedTables.forEach(table => {
            formData.append('tables[]', table);
        });
        
        fetch('/generate_mapping_sheet', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                mappingContainer.innerHTML = `
                    <div class="alert alert-danger">
                        ${data.error || 'An error occurred while generating the mapping sheet.'}
                    </div>
                `;
                return;
            }
            
            // Render mapping content in the container
            mappingContainer.innerHTML = '';
            
            if (data.mapping_data && data.mapping_data.tables && data.mapping_data.tables.length > 0) {
                // Show overall design assessment if available
                if (data.mapping_data.design_assessment) {
                    const assessment = data.mapping_data.design_assessment;
                    let assessmentHtml = `
                        <div class="card mb-4 border-danger">
                            <div class="card-header bg-danger text-white">
                                <h5 class="mb-0">Schema Design Assessment</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <span class="me-3">Overall Quality:</span>
                                    <span class="badge bg-${assessment.overall_quality === 'Good' ? 'success' : (assessment.overall_quality === 'Needs Review' ? 'warning' : 'danger')} px-3 py-2">${assessment.overall_quality}</span>
                                </div>
                    `;
                    
                    if (assessment.recommendations && assessment.recommendations.length > 0) {
                        assessmentHtml += `
                            <h6 class="mb-2">Improvement Recommendations:</h6>
                            <ul class="list-group">
                                ${assessment.recommendations.map(rec => `<li class="list-group-item border-danger text-danger"><i class="bi bi-exclamation-triangle me-2"></i>${rec}</li>`).join('')}
                            </ul>
                        `;
                    }
                    
                    assessmentHtml += `</div></div>`;
                    mappingContainer.innerHTML = assessmentHtml;
                }
                
                renderMappingSheet(data.mapping_data);
            } else {
                mappingContainer.innerHTML = `
                    <div class="alert alert-info">
                        No mapping data available for the selected tables.
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error generating mapping sheet:', error);
            mappingContainer.innerHTML = `
                <div class="alert alert-danger">
                    Failed to generate mapping sheet. Please try again.
                </div>
            `;
        });
    }
    
    // Function to render mapping sheet
    function renderMappingSheet(data) {
        if (!data || !data.tables || data.tables.length === 0) {
            mappingContainer.innerHTML = '<div class="alert alert-info">No mapping data available for the selected tables.</div>';
            return;
        }
        
        let html = '';
        
        data.tables.forEach(table => {
            html += `
                <div class="table-mapping mb-5">
                    <div class="table-header mb-3">
                        ${table.technical_name}
                    </div>
                    <div class="table-meta mb-3">
                        <div class="meta-item">
                            <span class="meta-label">Business Name:</span>
                            ${table.business_name || 'Not specified'}
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Entity Type:</span>
                            ${table.entity_type || 'Not specified'}
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Classification:</span>
                            ${table.classification || 'Not specified'}
                        </div>
                        <div class="meta-item" style="width: 100%;">
                            <span class="meta-label">Description:</span>
                            ${table.description || 'No description available'}
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered column-table mapping-table">
                            <thead>
                                <tr>
                                    <th>Business Name</th>
                                    <th>Technical Name</th>
                                    <th>Data Type</th>
                                    <th>Description</th>
                                    <th>Domain Values</th>
                                    <th>Business Rules</th>
                                    <th>Sample Values</th>
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            if (table.columns && table.columns.length > 0) {
                table.columns.forEach(column => {
                    // Check if there's design feedback to display
                    let designFeedbackHTML = '';
                    if (column.design_feedback && column.design_feedback.length > 0) {
                        designFeedbackHTML = `
                            <div class="mt-2 design-feedback">
                                <span class="badge bg-warning text-dark mb-1">Design Feedback</span>
                                <ul class="list-unstyled small mb-0">
                                    ${column.design_feedback.map(feedback => 
                                        `<li><i class="bi bi-info-circle text-warning me-1"></i>${feedback}</li>`
                                    ).join('')}
                                </ul>
                            </div>
                        `;
                    }
                    
                    // Check if there's a suggested alternative name
                    let suggestedNameHTML = '';
                    if (column.suggested_name) {
                        suggestedNameHTML = `
                            <div class="mt-1 suggested-name">
                                <span class="badge bg-success text-white">Suggested:</span>
                                <span class="text-success fw-bold">${column.suggested_name}</span>
                            </div>
                        `;
                    }
                    
                    html += `
                        <tr>
                            <td>${column.business_name || ''}</td>
                            <td>
                                ${column.technical_name || ''}
                                ${suggestedNameHTML}
                                ${designFeedbackHTML}
                            </td>
                            <td>${column.data_type || ''}</td>
                            <td>${column.description || ''}</td>
                            <td>${column.domain_values || ''}</td>
                            <td>${column.business_rules || ''}</td>
                            <td>${Array.isArray(column.sample_values) ? column.sample_values.join(", ") : (column.sample_values || '')}</td>
                        </tr>
                    `;
                });
            } else {
                html += `
                    <tr>
                        <td colspan="7" class="text-center">No column data available</td>
                    </tr>
                `;
            }
            
            html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        });
        
        mappingContainer.innerHTML = html;
    }
    
    // Function to get selected tables
    function getSelectedTables() {
        const checkboxes = document.querySelectorAll('.table-checkbox:checked');
        return Array.from(checkboxes).map(checkbox => checkbox.value);
    }
});
