"""
Pendulum.io - Data Modeling and Schema Analysis Tool
Main entry point for the application
"""

import os
import logging
from app import app
from database import initialize_app_db

# Configure logging
logging.basicConfig(level=logging.DEBUG, 
                   format='%(asctime)s - %(levelname)s - %(name)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize the application database
initialize_app_db()

if __name__ == '__main__':
    # Get port from environment or use default
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)