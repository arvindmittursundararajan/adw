import os
from config import GEMINI_API_KEY, GEMINI_URL
from utils import get_gemini_response

def test_api_connection():
    """Test connection to Gemini API with a simple prompt."""
    print("Testing Gemini API connection...")
    print(f"API Key set: {'Yes' if GEMINI_API_KEY else 'No'}")
    print(f"Using URL: {GEMINI_URL.replace(GEMINI_API_KEY, 'API_KEY_HIDDEN')}")
    
    # Simple test prompt
    test_prompt = "Hello, please respond with a short greeting."
    
    # Get response
    response = get_gemini_response(test_prompt)
    
    print("Response:")
    print(response)
    
    return response

if __name__ == "__main__":
    test_api_connection()