"""
Configuration settings for ADW Workbench
"""

import os

# Application settings
APP_NAME = "ADW Workbench"
APP_DESCRIPTION = "Data Modeling and Schema Analysis Tool"
APP_VERSION = "1.0.0"

# API Keys - Hardcoded as requested
GEMINI_API_KEY = "AIzaSyDp0VY6I3jWDTpKn93VKSu2U5rwrLAlnVs"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# File upload settings
UPLOAD_FOLDER = 'databases'
ALLOWED_EXTENSIONS = {'db', 'sqlite', 'sqlite3', 'csv', 'txt'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB

# Database settings
DB_DIRECTORY = 'databases'
APP_DB_PATH = os.path.join(DB_DIRECTORY, 'adw_workbench.db')

# Analysis settings
ANALYSIS_TYPES = {
    'basic': 'Basic Analysis',
    'domain': 'Business Domain Analysis',
    'performance': 'Performance Analysis',
    'data_quality': 'Data Quality Analysis',
    'security': 'Security Analysis'
}

# Diagram types
DIAGRAM_TYPES = {
    'erd': 'Entity-Relationship Diagram',
    'logical': 'Logical Data Model',
    'physical': 'Physical Data Model'
}

# Domain options for workspaces
DOMAIN_OPTIONS = [
    'Business',
    'Finance',
    'Healthcare',
    'Education',
    'Retail',
    'Technology',
    'Manufacturing',
    'Other'
]

# UI Colors - Per requested Airbnb style
UI_COLORS = {
    "primary": "#D6002A",  # Red
    "text": "#000000",     # Black
    "background": "#ffffff", # White
    "light_gray": "#f8f9fa"  # Light gray - minimal usage
}