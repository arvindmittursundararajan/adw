"""
Analysis functionality for ADW Workbench database schema analysis.
"""

import json
import logging
import re
import random
from datetime import datetime

# Import prompts but we'll use direct implementations instead of API calls
from analysis_prompts import (ANALYSIS_PROMPT, COMPLIANCE_PROMPT,
                             DIAGRAM_PROMPT, DOMAIN_ANALYSIS_PROMPT, 
                             MAPPING_SHEET_PROMPT, QUERY_PROMPT, 
                             QUERY_HINTS_PROMPT)
from utils import clean_text, get_gemini_response

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

def format_schema_info(schema_info):
    """Format schema information as a string for use in prompts."""
    formatted_text = ""
    
    for table_name, table_data in schema_info.items():
        formatted_text += f"Table: {table_name}\n"
        
        # Add columns
        formatted_text += "Columns:\n"
        for column in table_data.get('columns', []):
            nullable = "NOT NULL" if column.get('not_null') else "NULL"
            pk = "PRIMARY KEY" if column.get('pk') else ""
            formatted_text += f"  - {column.get('name')} ({column.get('type')}) {nullable} {pk}\n"
        
        # Add foreign keys
        if table_data.get('foreign_keys'):
            formatted_text += "Foreign Keys:\n"
            for fk in table_data.get('foreign_keys', []):
                formatted_text += f"  - {fk.get('column')} -> {fk.get('ref_table')}.{fk.get('ref_column')}\n"
        
        # Add indexes
        if table_data.get('indexes'):
            formatted_text += "Indexes:\n"
            for idx in table_data.get('indexes', []):
                formatted_text += f"  - {idx.get('name')}: {', '.join(idx.get('columns', []))}\n"
        
        formatted_text += "\n"
    
    return formatted_text

def analyze_schema(database, tables, schema_info, analysis_type):
    """
    Analyze the database schema using Gemini API.
    
    Args:
        database (str): Name of the database
        tables (list): List of table names to analyze
        schema_info (dict): Schema information for the tables
        analysis_type (str): Type of analysis to perform
    
    Returns:
        str: Analysis results as markdown text
    """
    # Format the schema information
    formatted_schema = format_schema_info(schema_info)
    
    # Prepare the prompt
    prompt = ANALYSIS_PROMPT.format(
        database=database,
        tables=", ".join(tables),
        schema_info=formatted_schema,
        analysis_type=analysis_type
    )
    
    try:
        # Send prompt to Gemini API
        response = get_gemini_response(prompt)
        
        # Clean and format the response
        return clean_text(response)
    except Exception as e:
        logger.error(f"Schema analysis error: {str(e)}")
        return f"Error analyzing schema: {str(e)}"

def generate_diagram(database, tables, schema_info, diagram_type):
    """
    Generate a diagram for the database schema.
    
    Args:
        database (str): Name of the database
        tables (list): List of table names to include in the diagram
        schema_info (dict): Schema information for the tables
        diagram_type (str): Type of diagram to generate
    
    Returns:
        str: Mermaid.js diagram code
    """
    try:
        # Create directly without API call
        logger.debug(f"Generating {diagram_type} diagram for {len(tables)} tables")
        
        # ER Diagram (conceptual, logical, physical, erd)
        if diagram_type in ['conceptual', 'logical', 'physical', 'erd']:
            # Create a proper ER diagram with Mermaid
            if diagram_type == 'conceptual':
                # Conceptual focuses on entities and relationships without attributes
                diagram_code = "erDiagram\n"
                
                # Add tables without details but with empty brackets for entity definition
                for table_name in tables:
                    if table_name in schema_info:
                        diagram_code += f"    {table_name} {{}}\n"
                
                # Add relationships
                for table_name in tables:
                    if table_name in schema_info and 'foreign_keys' in schema_info[table_name]:
                        for fk in schema_info[table_name].get('foreign_keys', []):
                            from_table = table_name
                            to_table = fk.get('table')  # Changed from 'referenced_table' to 'table'
                            if to_table and to_table in tables:
                                # Use proper cardinality notation for conceptual diagram with simplified syntax
                                diagram_code += f"    {from_table} ||--o| {to_table} : relates\n"
            
            elif diagram_type == 'logical':
                # Logical includes key attributes
                diagram_code = "erDiagram\n"
                
                # Add tables with key attributes
                for table_name in tables:
                    if table_name in schema_info:
                        diagram_code += f"    {table_name} {{\n"
                        
                        # Add primary key and foreign key columns
                        if 'columns' in schema_info[table_name]:
                            for col in schema_info[table_name].get('columns', []):
                                col_name = col.get('name', '')
                                col_type = col.get('type', 'TEXT')
                                
                                # Only include keys in logical model
                                if col.get('pk') or any(fk.get('column') == col_name for fk in schema_info[table_name].get('foreign_keys', [])):
                                    # Use simplified marker notation to avoid Mermaid syntax errors
                                    if col.get('pk'):
                                        diagram_code += f"        {col_type} {col_name} PK\n"
                                    else:
                                        diagram_code += f"        {col_type} {col_name} FK\n"
                        
                        diagram_code += "    }\n"
                
                # Add relationships
                for table_name in tables:
                    if table_name in schema_info and 'foreign_keys' in schema_info[table_name]:
                        for fk in schema_info[table_name].get('foreign_keys', []):
                            from_table = table_name
                            to_table = fk.get('table')  # Changed from 'referenced_table' to 'table'
                            if to_table and to_table in tables:
                                # Use proper cardinality notation for logical diagram
                                from_col = fk.get('from', '')
                                to_col = fk.get('to', '')
                                # Remove quotes to avoid Mermaid syntax errors
                                diagram_code += f"    {from_table} ||--o| {to_table} : relates\n"
            
            else:  # physical or erd
                # Physical includes all columns and details
                diagram_code = "erDiagram\n"
                
                # Add tables with all columns
                for table_name in tables:
                    if table_name in schema_info:
                        diagram_code += f"    {table_name} {{\n"
                        
                        # Add all columns with simplified notation to avoid syntax errors
                        if 'columns' in schema_info[table_name]:
                            for col in schema_info[table_name].get('columns', []):
                                col_name = col.get('name', '')
                                col_type = col.get('type', 'TEXT')
                                
                                # Build a simple marker string without brackets to avoid syntax errors
                                markers = []
                                if col.get('pk'):
                                    markers.append("PK")
                                
                                # Check if it's a foreign key
                                is_fk = False
                                for fk in schema_info[table_name].get('foreign_keys', []):
                                    if fk.get('column') == col_name:
                                        is_fk = True
                                        break
                                
                                if is_fk:
                                    markers.append("FK")
                                
                                if col.get('not_null'):
                                    markers.append("NN")
                                
                                # Append markers at the end of the line without brackets
                                if markers:
                                    diagram_code += f"        {col_type} {col_name} {' '.join(markers)}\n"
                                else:
                                    diagram_code += f"        {col_type} {col_name}\n"
                        
                        diagram_code += "    }\n"
                
                # Add relationships
                for table_name in tables:
                    if table_name in schema_info and 'foreign_keys' in schema_info[table_name]:
                        for fk in schema_info[table_name].get('foreign_keys', []):
                            from_table = table_name
                            from_col = fk.get('from', '')
                            to_table = fk.get('table', '')
                            to_col = fk.get('to', '')
                            
                            if to_table and to_table in tables:
                                # Use simple relationship notation without quotes to avoid syntax errors
                                diagram_code += f"    {from_table} ||--o| {to_table} : relates\n"
        
        # Dependency diagram
        elif diagram_type == 'dependency':
            diagram_code = "flowchart TD\n"
            
            # Create nodes for tables
            for table_name in tables:
                diagram_code += f"    {table_name}[{table_name}]\n"
            
            # Add styling for all nodes to ensure white background
            diagram_code += "    classDef default fill:#ffffff,stroke:#D6002A,color:black,stroke-width:2px\n"
            
            # Create edges for dependencies
            for table_name in tables:
                if table_name in schema_info and 'foreign_keys' in schema_info[table_name]:
                    for fk in schema_info[table_name].get('foreign_keys', []):
                        to_table = fk.get('table', '')  # Changed from 'referenced_table' to 'table'
                        if to_table and to_table in tables:
                            diagram_code += f"    {table_name} -->|depends on| {to_table}\n"
        
        # Hierarchical diagram
        elif diagram_type == 'hierarchical':
            # Using flowchart instead of classDiagram to fix syntax errors
            diagram_code = "flowchart TD\n"
            
            # Create nodes for tables
            for table_name in tables:
                if table_name in schema_info:
                    diagram_code += f"    {table_name}[{table_name}]\n"
            
            # Add styling for all nodes to ensure white background
            diagram_code += "    classDef default fill:#ffffff,stroke:#D6002A,color:black,stroke-width:2px\n"
            
            # Create hierarchical relationships (tables with FK to another table)
            for table_name in tables:
                if table_name in schema_info and 'foreign_keys' in schema_info[table_name]:
                    for fk in schema_info[table_name].get('foreign_keys', []):
                        parent_table = fk.get('table', '')
                        if parent_table and parent_table in tables:
                            # Show inheritance relationships as arrows pointing upward
                            diagram_code += f"    {table_name} -->|inherits from| {parent_table}\n"
        
        else:
            # Default to a simple flowchart
            diagram_code = "graph TD\n"
            
            # Add tables
            for table_name in tables:
                diagram_code += f"    {table_name}[{table_name}]\n"
            
            # Add styling for all nodes to ensure white background
            diagram_code += "    classDef default fill:#ffffff,stroke:#D6002A,color:black,stroke-width:2px\n"
            
            # Add relationships
            for table_name in tables:
                if table_name in schema_info and 'foreign_keys' in schema_info[table_name]:
                    for fk in schema_info[table_name].get('foreign_keys', []):
                        to_table = fk.get('table', '')  # Changed from 'referenced_table' to 'table'
                        if to_table and to_table in tables:
                            from_col = fk.get('from', '')
                            to_col = fk.get('to', '')
                            diagram_code += f"    {table_name} -->|{from_col} -> {to_col}| {to_table}\n"
        
        logger.debug(f"Generated diagram code: {diagram_code[:200]}...")
        return diagram_code
    
    except Exception as e:
        logger.error(f"Diagram generation error: {str(e)}")
        # Return a simple error diagram instead of None
        error_message = str(e).replace('"', "'")
        if diagram_type in ['conceptual', 'logical', 'physical', 'erd']:
            return f"""erDiagram
    Error {{
        String message
        String details
    }}
    
    Note {{
        String help
    }}
    
    Error -- Note : "Try Again"
    
    %% Error details: {error_message}
"""
        else:
            return f"""graph TD
    A[Error Generating Diagram] --> B[Please try again]
    B --> C[Or select fewer tables]
    C --> D[Error: {error_message}]
    
    style A fill:#D6002A,stroke:#D6002A,color:white
    style B fill:#ffffff,stroke:#D6002A,color:black
    style C fill:#ffffff,stroke:#D6002A,color:black
    style D fill:#f8f8f8,stroke:#D6002A,color:#D6002A
"""

def generate_mapping_sheet(database, tables, schema_info):
    """
    Generate a mapping sheet for the database tables with design feedback.
    
    Args:
        database (str): Name of the database
        tables (list): List of table names
        schema_info (dict): Schema information for the tables
    
    Returns:
        dict: Mapping data for tables including design recommendations
    """
    try:
        # Create a direct mapping data structure with overall assessment
        mapping_data = {
            'database': database,
            'tables': [],
            'design_assessment': {
                'overall_quality': 'Needs Review',
                'recommendations': [
                    'Review naming conventions for consistency',
                    'Ensure all tables have primary keys',
                    'Add metadata columns (created_at, updated_at) for tracking changes',
                    'Consider adding indexes for frequently queried columns',
                    'Standardize data types across similar columns'
                ]
            }
        }
        
        # Add detailed table information from schema
        for table_name in tables:
            if table_name in schema_info:
                # Generate business-friendly name from technical name
                business_name = table_name.replace('_', ' ').title()
                
                # Get the number of columns for classification
                cols_count = len(schema_info[table_name].get('columns', []))
                classification = "Reference Data" if cols_count < 5 else "Business Data"
                
                # Determine entity type based on foreign keys
                has_foreign_keys = len(schema_info[table_name].get('foreign_keys', [])) > 0
                entity_type = "Associative Entity" if has_foreign_keys else "Primary Entity"
                
                # Create description based on table name
                description = f"Table containing {table_name.replace('_', ' ')} data"
                
                table_data = {
                    'technical_name': table_name,
                    'business_name': business_name,
                    'entity_type': entity_type,
                    'classification': classification,
                    'description': description,
                    'columns': []
                }
                
                # Add columns with detailed information
                if 'columns' in schema_info[table_name]:
                    for col in schema_info[table_name]['columns']:
                        col_name = col.get('name', '')
                        col_type = col.get('type', '')
                        
                        # Format business name nicely
                        business_name = col_name.replace('_', ' ').title()
                        
                        # Create appropriate description based on column name and type
                        if 'id' in col_name.lower():
                            description = f"Unique identifier for {table_name.replace('_', ' ')}"
                        elif 'date' in col_name.lower() or 'time' in col_name.lower():
                            if "create" in col_name.lower():
                                date_action = "created"
                            elif "update" in col_name.lower():
                                date_action = "updated"
                            else:
                                date_action = "processed"
                            description = f"Date/time when {table_name.replace('_', ' ')} was {date_action}"
                        elif 'name' in col_name.lower():
                            description = f"Name of the {table_name.replace('_', ' ')}"
                        elif 'code' in col_name.lower():
                            description = f"Code representing the {table_name.replace('_', ' ')}"
                        elif 'desc' in col_name.lower() or 'description' in col_name.lower():
                            description = f"Detailed description of the {table_name.replace('_', ' ')}"
                        else:
                            description = f"{business_name} of the {table_name.replace('_', ' ')}"
                        
                        # Determine domain values based on column type and name
                        domain_values = ""
                        if col_type.upper() == "BOOLEAN" or "flag" in col_name.lower():
                            domain_values = "True, False"
                        elif "status" in col_name.lower():
                            domain_values = "Active, Inactive, Pending, Completed"
                        elif "type" in col_name.lower():
                            domain_values = "Type A, Type B, Type C"
                        elif "priority" in col_name.lower():
                            domain_values = "High, Medium, Low"
                        
                        # Generate business rules based on constraints
                        business_rules = []
                        if col.get('pk'):
                            business_rules.append("Must be unique")
                        if col.get('not_null'):
                            business_rules.append("Required field")
                        if "email" in col_name.lower():
                            business_rules.append("Must be a valid email format")
                        if "phone" in col_name.lower():
                            business_rules.append("Must be a valid phone number format")
                        
                        # Generate sample values based on column type
                        sample_values = []
                        if "INTEGER" in col_type.upper():
                            sample_values = [str(random.randint(1, 1000)), str(random.randint(1, 1000))]
                        elif "REAL" in col_type.upper() or "FLOAT" in col_type.upper():
                            sample_values = [str(round(random.uniform(1.0, 100.0), 2)), str(round(random.uniform(1.0, 100.0), 2))]
                        elif "TEXT" in col_type.upper():
                            if "name" in col_name.lower():
                                sample_values = ["Sample Name", "Example Name"]
                            elif "description" in col_name.lower():
                                sample_values = ["Sample description text.", "Example description of item."]
                            elif "email" in col_name.lower():
                                sample_values = ["user@example.com", "sample@test.org"]
                            else:
                                sample_values = ["Sample data", "Example text"]
                        elif "DATE" in col_type.upper() or "TIME" in col_type.upper():
                            current_date = datetime.now().strftime("%Y-%m-%d")
                            sample_values = [current_date, "2023-01-15"]
                            
                        # Generate design feedback for column
                        design_feedback = []
                        suggested_name = None
                        
                        # Check naming conventions
                        if not col_name.islower() and '_' not in col_name:
                            design_feedback.append("Use snake_case for column names (lowercase with underscores)")
                            suggested_name = col_name.lower().replace(' ', '_')
                        
                        # Check data type appropriateness
                        if 'id' in col_name.lower() and not col_type.upper().startswith('INT'):
                            design_feedback.append(f"Consider using INTEGER for ID columns instead of {col_type}")
                        elif ('date' in col_name.lower() or 'time' in col_name.lower()) and not any(t in col_type.upper() for t in ['DATE', 'TIME', 'TIMESTAMP']):
                            design_feedback.append(f"Consider using DATE, TIME or TIMESTAMP instead of {col_type}")
                        elif ('price' in col_name.lower() or 'amount' in col_name.lower() or 'cost' in col_name.lower()) and not any(t in col_type.upper() for t in ['NUMERIC', 'DECIMAL', 'REAL', 'FLOAT']):
                            design_feedback.append(f"Consider using NUMERIC or REAL for currency values instead of {col_type}")
                        
                        # Check for redundancy in name
                        if table_name.lower() in col_name.lower() and col_name.lower() != f"{table_name.lower()}_id":
                            design_feedback.append(f"Column name may be redundant with table name ('{col_name}' in '{table_name}' table)")
                            suggested_parts = col_name.split('_')
                            suggested_name = '_'.join([p for p in suggested_parts if p.lower() != table_name.lower()])
                        
                        # Check for abbreviations
                        if any(len(part) <= 2 for part in col_name.split('_') if part not in ['id', 'to', 'by', 'on']):
                            design_feedback.append("Avoid abbreviations in column names for better readability")
                        
                        # Check for missing constraints
                        if ('email' in col_name.lower() and not col.get('not_null')) or ('name' in col_name.lower() and not col.get('not_null')):
                            design_feedback.append("Consider adding NOT NULL constraint for important data")
                        
                        column_data = {
                            'technical_name': col_name,
                            'business_name': business_name,
                            'data_type': col_type,
                            'description': description,
                            'domain_values': domain_values,
                            'business_rules': ", ".join(business_rules) if business_rules else "None",
                            'sample_values': sample_values,
                            'design_feedback': design_feedback,
                            'suggested_name': suggested_name
                        }
                        table_data['columns'].append(column_data)
                
                mapping_data['tables'].append(table_data)
                
        logger.debug(f"Generated mapping sheet data: {json.dumps(mapping_data)[:200]}...")
        return mapping_data
    except Exception as e:
        logger.error(f"Mapping sheet generation error: {str(e)}")
        # Return a minimal valid structure
        return {
            'database': database,
            'tables': []
        }

def generate_compliance_assessment(database, tables, schema_info):
    """
    Generate a CASTLE compliance assessment for the database.
    
    CASTLE Framework:
    - Completeness: Evaluates presence of required fields and metadata
    - Accuracy: Evaluates appropriate data types and constraints
    - Structure: Evaluates schema organization and relationships
    - Transparency: Evaluates naming conventions and documentation
    - Literacy: Evaluates descriptive names and readability
    - Efficiency: Evaluates database design efficiency and performance
    
    Args:
        database (str): Name of the database
        tables (list): List of table names
        schema_info (dict): Schema information for the tables
    
    Returns:
        dict: CASTLE assessment data with detailed feedback for each dimension
    """
    try:
        # Calculate CASTLE scores based on schema analysis
        
        # Completeness assessment - check if key fields and metadata are present
        completeness_score = 0
        completeness_issues = []
        
        # Structure assessment - evaluate schema organization
        structure_score = 0
        structure_issues = []
        
        # Transparency assessment - check naming conventions and documentation
        transparency_score = 0
        transparency_issues = []
        
        # Literacy assessment - evaluate descriptive names and readability
        literacy_score = 0
        literacy_issues = []
        
        # Efficiency assessment - evaluate database design efficiency
        efficiency_score = 0
        efficiency_issues = []
        
        # Accuracy assessment - evaluate data type appropriateness
        accuracy_score = 0
        accuracy_issues = []
        
        total_tables = len(tables)
        if total_tables == 0:
            return {
                "database": database,
                "tables": tables,
                "overall_score": 0,
                "dimensions": {
                    "completeness": {"score": 0, "issues": ["No tables selected for assessment"]},
                    "accuracy": {"score": 0, "issues": ["No tables selected for assessment"]},
                    "structure": {"score": 0, "issues": ["No tables selected for assessment"]},
                    "transparency": {"score": 0, "issues": ["No tables selected for assessment"]},
                    "literacy": {"score": 0, "issues": ["No tables selected for assessment"]},
                    "efficiency": {"score": 0, "issues": ["No tables selected for assessment"]}
                },
                "readability_scores": {
                    "flesch_reading_ease": 0,
                    "automated_readability_index": 0,
                    "coleman_liau_index": 0
                },
                "recommendations": ["Select tables to assess"]
            }
            
        # Analyze each table for CASTLE dimensions
        for table_name in tables:
            if table_name in schema_info:
                table_info = schema_info[table_name]
                columns = table_info.get('columns', [])
                fks = table_info.get('foreign_keys', [])
                indexes = table_info.get('indexes', [])
                
                # Completeness checks
                if columns:
                    # More columns typically indicates better completeness
                    col_score = min(100, len(columns) * 10)  # Max out at 10 columns
                    completeness_score += col_score
                    
                    # Check for primary key
                    pk_found = any(col.get('pk') for col in columns)
                    if not pk_found:
                        completeness_issues.append(f"Table '{table_name}' lacks a primary key")
                    else:
                        completeness_score += 10
                        
                    # Check for metadata fields (created_at, updated_at, etc.)
                    metadata_fields = ['created', 'updated', 'timestamp', 'date']
                    has_metadata = any(any(meta in col.get('name', '').lower() for meta in metadata_fields) for col in columns)
                    if not has_metadata:
                        completeness_issues.append(f"Table '{table_name}' lacks metadata fields (created_at, updated_at)")
                    else:
                        completeness_score += 10
                else:
                    completeness_issues.append(f"Table '{table_name}' has no columns defined")
                
                # Structure checks
                has_relationships = len(fks) > 0
                if has_relationships:
                    structure_score += 15
                else:
                    structure_issues.append(f"Table '{table_name}' does not relate to other tables")
                    
                has_indexes = len(indexes) > 0
                if has_indexes:
                    structure_score += 15
                else:
                    structure_issues.append(f"Table '{table_name}' lacks indexes for performance")
                    
                # Check column naming patterns consistency
                column_names = [col.get('name', '').lower() for col in columns]
                snake_case = all('_' in name for name in column_names if len(name.split()) > 1)
                if snake_case:
                    structure_score += 10
                else:
                    structure_issues.append(f"Table '{table_name}' has inconsistent column naming patterns")
                    
                # Transparency checks
                clear_names = 0
                for col in columns:
                    col_name = col.get('name', '').lower()
                    if len(col_name) > 2 and not col_name.startswith(('x_', 'z_', 'tmp')):
                        clear_names += 1
                
                transparency_score += (clear_names / max(1, len(columns))) * 40
                
                if table_name.lower().startswith(('tbl_', 'dt_')):
                    transparency_issues.append(f"Table '{table_name}' uses prefixes that reduce transparency")
                else:
                    transparency_score += 10
                    
                # Literacy checks
                good_column_names = 0
                for col in columns:
                    col_name = col.get('name', '').lower()
                    words = col_name.replace('_', ' ').split()
                    if all(len(word) > 1 for word in words):
                        good_column_names += 1
                
                literacy_score += (good_column_names / max(1, len(columns))) * 50
                
                # Efficiency checks
                appropriate_types = 0
                for col in columns:
                    col_type = col.get('type', '').upper()
                    col_name = col.get('name', '').lower()
                    
                    # Check if type matches typical naming conventions
                    if ('id' in col_name and 'INTEGER' in col_type) or \
                       ('date' in col_name and ('DATE' in col_type or 'TIME' in col_type)) or \
                       ('price' in col_name and ('REAL' in col_type or 'FLOAT' in col_type or 'NUMERIC' in col_type)) or \
                       ('name' in col_name and 'TEXT' in col_type) or \
                       ('description' in col_name and 'TEXT' in col_type) or \
                       ('flag' in col_name and ('BOOLEAN' in col_type or 'INTEGER' in col_type)):
                        appropriate_types += 1
                
                efficiency_score += (appropriate_types / max(1, len(columns))) * 50
                
                # Check for proper use of indexes on join fields
                join_columns = set()
                for fk in fks:
                    col = fk.get('column')
                    if col:
                        join_columns.add(col)
                
                indexed_columns = set()
                for idx in indexes:
                    for col in idx.get('columns', []):
                        indexed_columns.add(col)
                
                join_columns_indexed = len(join_columns.intersection(indexed_columns))
                if join_columns and join_columns_indexed / len(join_columns) >= 0.7:
                    efficiency_score += 20
                elif join_columns:
                    efficiency_issues.append(f"Table '{table_name}' has join columns without indexes")
                
                # Accuracy checks
                # Check data types for common fields
                for col in columns:
                    col_name = col.get('name', '').lower()
                    col_type = col.get('type', '').upper()
                    
                    if 'id' in col_name and 'INTEGER' not in col_type:
                        accuracy_issues.append(f"Column '{col_name}' in '{table_name}' should be INTEGER")
                    elif ('date' in col_name or 'time' in col_name) and not any(t in col_type for t in ['DATE', 'TIME', 'TIMESTAMP']):
                        accuracy_issues.append(f"Column '{col_name}' in '{table_name}' should be a date/time type")
                    elif 'price' in col_name and not any(t in col_type for t in ['REAL', 'NUMERIC', 'DECIMAL', 'FLOAT']):
                        accuracy_issues.append(f"Column '{col_name}' in '{table_name}' should be a decimal type")
                    elif 'email' in col_name and 'TEXT' not in col_type:
                        accuracy_issues.append(f"Column '{col_name}' in '{table_name}' should be TEXT")
                    else:
                        accuracy_score += 5
                
        # Normalize scores by number of tables
        completeness_score = min(100, completeness_score / max(1, total_tables))
        structure_score = min(100, structure_score / max(1, total_tables))
        transparency_score = min(100, transparency_score / max(1, total_tables))
        literacy_score = min(100, literacy_score / max(1, total_tables))
        efficiency_score = min(100, efficiency_score / max(1, total_tables))
        accuracy_score = min(100, accuracy_score / max(1, total_tables))
        
        # Calculate overall score (average of dimensions)
        overall_score = (completeness_score + structure_score + transparency_score + 
                       literacy_score + efficiency_score + accuracy_score) / 6
        
        # Generate recommendations based on issues
        recommendations = []
        
        if completeness_issues:
            recommendations.append("Add primary keys to all tables lacking them")
            recommendations.append("Include metadata fields (created_at, updated_at) for tracking")
            
        if structure_issues:
            recommendations.append("Establish relationships between related tables")
            recommendations.append("Add indexes to frequently queried columns")
            recommendations.append("Standardize naming conventions (use snake_case)")
            
        if transparency_issues:
            recommendations.append("Use clear, descriptive table and column names")
            recommendations.append("Avoid prefixes like 'tbl_' and 'dt_'")
            
        if literacy_issues:
            recommendations.append("Make column names more descriptive and readable")
            recommendations.append("Use full words instead of abbreviations where possible")
            
        if efficiency_issues:
            recommendations.append("Add indexes to columns used in joins")
            recommendations.append("Use appropriate data types to minimize storage")
            
        if accuracy_issues:
            recommendations.append("Ensure data types match the content they store")
            recommendations.append("Use constraints to enforce data quality")
        
        # Limit to top 5 recommendations
        if len(recommendations) > 5:
            recommendations = recommendations[:5]
            
        # Readability scores - calculate based on table and column names
        all_names = []
        for table_name in tables:
            if table_name in schema_info:
                all_names.append(table_name)
                for col in schema_info[table_name].get('columns', []):
                    col_name = col.get('name', '')
                    all_names.append(col_name)
        
        # Calculate readability metrics as example scores
        # In reality, these would be calculated using proper linguistic algorithms
        avg_word_length = sum(len(word) for name in all_names for word in name.replace('_', ' ').split()) / max(1, sum(len(name.replace('_', ' ').split()) for name in all_names))
        
        flesch_reading_ease = max(0, min(100, 206.835 - (1.015 * avg_word_length) - (84.6 * 1.5)))
        automated_readability_index = max(1, min(14, 4.71 * avg_word_length + 0.5 * 1.5 - 21.43))
        coleman_liau_index = max(1, min(12, 5.89 * avg_word_length / 10 - 15.8 / 10 + 3.11))
        
        # Create the full compliance assessment object
        compliance_data = {
            "database": database,
            "tables": tables,
            "overall_score": round(overall_score),
            "dimensions": {
                "completeness": {
                    "score": round(completeness_score),
                    "issues": completeness_issues[:3] if completeness_issues else ["No issues detected"]
                },
                "accuracy": {
                    "score": round(accuracy_score),
                    "issues": accuracy_issues[:3] if accuracy_issues else ["No issues detected"]
                },
                "structure": {
                    "score": round(structure_score),
                    "issues": structure_issues[:3] if structure_issues else ["No issues detected"]
                },
                "transparency": {
                    "score": round(transparency_score),
                    "issues": transparency_issues[:3] if transparency_issues else ["No issues detected"]
                },
                "literacy": {
                    "score": round(literacy_score),
                    "issues": literacy_issues[:3] if literacy_issues else ["No issues detected"]
                },
                "efficiency": {
                    "score": round(efficiency_score),
                    "issues": efficiency_issues[:3] if efficiency_issues else ["No issues detected"]
                }
            },
            "readability_scores": {
                "flesch_reading_ease": round(flesch_reading_ease, 1),
                "automated_readability_index": round(automated_readability_index, 1),
                "coleman_liau_index": round(coleman_liau_index, 1)
            },
            "recommendations": recommendations if recommendations else ["Schema appears to follow good practices"]
        }
        
        # Store the compliance assessment in the database for historical tracking
        from database import save_compliance_assessment
        save_compliance_assessment(database, tables, compliance_data)
        
        logger.debug(f"Generated compliance assessment: {json.dumps(compliance_data)[:200]}...")
        return compliance_data
    except Exception as e:
        logger.error(f"Compliance assessment error: {str(e)}")
        # Return a basic valid structure instead of None
        return {
            "database": database,
            "tables": tables,
            "overall_score": 50,
            "dimensions": {
                "completeness": {
                    "score": 50, 
                    "issues": ["Error generating assessment: " + str(e)]
                },
                "accuracy": {
                    "score": 50,
                    "issues": ["Error generating assessment: " + str(e)]
                },
                "structure": {
                    "score": 50,
                    "issues": ["Error generating assessment: " + str(e)]
                },
                "transparency": {
                    "score": 50,
                    "issues": ["Error generating assessment: " + str(e)]
                },
                "literacy": {
                    "score": 50,
                    "issues": ["Error generating assessment: " + str(e)]
                },
                "efficiency": {
                    "score": 50,
                    "issues": ["Error generating assessment: " + str(e)]
                }
            },
            "readability_scores": {
                "flesch_reading_ease": 50,
                "automated_readability_index": 10,
                "coleman_liau_index": 10
            },
            "recommendations": ["Fix application errors to generate a complete assessment"]
        }

def generate_query(database, prompt, schema_info):
    """
    Generate a SQL query based on a natural language prompt.
    
    Args:
        database (str): Name of the database
        prompt (str): Natural language prompt describing the query
        schema_info (dict): Schema information for the database
    
    Returns:
        str: SQL query
    """
    # Format the schema information
    formatted_schema = format_schema_info(schema_info)
    
    # Prepare the prompt
    query_prompt = QUERY_PROMPT.format(
        database=database,
        prompt=prompt,
        schema_info=formatted_schema
    )
    
    try:
        # Send prompt to Gemini API
        response = get_gemini_response(query_prompt)
        
        # Clean and extract SQL query
        sql_query = clean_text(response)
        
        # Extract the code between SQL markers if they exist
        if "```sql" in sql_query and "```" in sql_query.split("```sql", 1)[1]:
            sql_query = sql_query.split("```sql", 1)[1].split("```", 1)[0].strip()
        elif "```" in sql_query:
            # If there's just a generic code block
            sql_query = sql_query.split("```", 1)[1].split("```", 1)[0].strip()
        
        return sql_query
    except Exception as e:
        logger.error(f"Query generation error: {str(e)}")
        return None

def analyze_domain(databases, tables_by_db, schema_info_by_db):
    """
    Generate a domain analysis for multiple databases using Gemini API.
    
    Args:
        databases (list): List of database names
        tables_by_db (dict): Dictionary mapping database names to lists of table names
        schema_info_by_db (dict): Dictionary mapping database names to schema information
    
    Returns:
        dict: Domain analysis with description and diagram
    """
    # Format combined database schema information
    formatted_schema = ""
    for db in databases:
        if db in schema_info_by_db:
            formatted_schema += f"Database: {db}\n\n"
            formatted_schema += format_schema_info(schema_info_by_db[db])
            formatted_schema += "\n"
    
    # Prepare the prompt
    prompt = DOMAIN_ANALYSIS_PROMPT.format(
        databases=", ".join(databases),
        tables=", ".join([table for db_tables in tables_by_db.values() for table in db_tables]),
        schema_info=formatted_schema
    )
    
    try:
        # Send prompt to Gemini API
        response = get_gemini_response(prompt)
        
        # Clean and parse the response
        clean_response = clean_text(response)
        
        # Extract text and diagram
        description = ""
        diagram_code = ""
        
        # Extract mermaid diagram if it exists
        if "```mermaid" in clean_response and "```" in clean_response.split("```mermaid", 1)[1]:
            # Split content before diagram
            description = clean_response.split("```mermaid", 1)[0].strip()
            # Extract diagram code
            diagram_code = clean_response.split("```mermaid", 1)[1].split("```", 1)[0].strip()
            diagram_code = "graph TD\n" + diagram_code if not diagram_code.startswith(("graph", "flowchart")) else diagram_code
        elif "```" in clean_response:
            # Get text before first code block as description
            description = clean_response.split("```", 1)[0].strip()
            # Get content of first code block as diagram
            diagram_code = clean_response.split("```", 1)[1].split("```", 1)[0].strip()
            # Ensure diagram has proper syntax
            diagram_code = "graph TD\n" + diagram_code if not diagram_code.startswith(("graph", "flowchart")) else diagram_code
        else:
            # If no diagram, use all text as description
            description = clean_response
            diagram_code = "graph TD\nA[No diagram available]"
        
        return {
            "description": description,
            "diagram_code": diagram_code
        }
    except Exception as e:
        logger.error(f"Domain analysis error: {str(e)}")
        return {
            "description": f"Error analyzing domain: {str(e)}",
            "diagram_code": "graph TD\nA[Error] -->|{str(e)}| B[Could not generate diagram]"
        }

def generate_query_hints(database, schema_info):
    """
    Generate sample query suggestions based on database schema.
    
    Args:
        database (str): Name of the database
        schema_info (dict): Schema information for the database
    
    Returns:
        list: List of sample query suggestions
    """
    # Format the schema information
    formatted_schema = format_schema_info(schema_info)
    
    # Prepare the prompt using the template
    hints_prompt = QUERY_HINTS_PROMPT.format(
        database=database,
        schema_info=formatted_schema
    )
    
    try:
        # Send prompt to Gemini API
        response = get_gemini_response(hints_prompt)
        
        # Clean and extract JSON
        hints_text = clean_text(response)
        
        # Extract the JSON if it's wrapped in code blocks
        if "```json" in hints_text and "```" in hints_text.split("```json", 1)[1]:
            hints_text = hints_text.split("```json", 1)[1].split("```", 1)[0].strip()
        elif "```" in hints_text:
            # If there's just a generic code block
            hints_text = hints_text.split("```", 1)[1].split("```", 1)[0].strip()
        
        # Parse the JSON
        hints = json.loads(hints_text)
        
        # Ensure we always return a list
        if not isinstance(hints, list):
            hints = list(hints.values()) if isinstance(hints, dict) else [hints]
        
        # Return at most 5 hints
        return hints[:5]
    except Exception as e:
        logger.error(f"Query hints generation error: {str(e)}")
        return ["Show all records from main table", 
                "Count total number of records", 
                "Find the most recent entries", 
                "Summarize data by category", 
                "Find related records between tables"]