"""
Database utility functions for ADW Workbench
"""

import os
import sqlite3
import csv
import json
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants
from config import DB_DIRECTORY, APP_DB_PATH

def get_db_path(database_name):
    """Get the path to a database file."""
    # First check if this is a registered database
    try:
        conn = sqlite3.connect(APP_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT path FROM databases WHERE name = ?", (database_name,))
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return result[0]
    except Exception as e:
        logger.error(f"Error checking registered database: {str(e)}")
    
    # If not registered or error occurred, check if it's a file in the DB directory
    default_path = os.path.join(DB_DIRECTORY, database_name)
    if os.path.exists(default_path):
        return default_path
    
    return None

def get_connection(database):
    """Get a connection to a SQLite database."""
    db_path = get_db_path(database)
    
    if not db_path:
        raise ValueError(f"Database '{database}' not found")
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        logger.error(f"Error connecting to database '{database}': {str(e)}")
        raise

def get_databases(workspace_id=None):
    """Get a list of all available databases."""
    try:
        # Initialize the application database if it doesn't exist
        initialize_app_db()
        
        conn = sqlite3.connect(APP_DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        if workspace_id:
            cursor.execute("""
                SELECT d.id, d.name, d.path, d.created_at, w.name as workspace_name
                FROM databases d
                JOIN workspaces w ON d.workspace_id = w.id
                WHERE d.workspace_id = ?
                ORDER BY d.name
            """, (workspace_id,))
        else:
            cursor.execute("""
                SELECT d.id, d.name, d.path, d.created_at, w.name as workspace_name
                FROM databases d
                JOIN workspaces w ON d.workspace_id = w.id
                ORDER BY d.name
            """)
        
        databases = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return databases
    except Exception as e:
        logger.error(f"Error getting databases: {str(e)}")
        return []

def get_tables_from_db(database):
    """Get a list of all tables in a SQLite database."""
    try:
        conn = get_connection(database)
        cursor = conn.cursor()
        
        # Exclude SQLite system tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        tables = [row['name'] for row in cursor.fetchall()]
        conn.close()
        
        return tables
    except Exception as e:
        logger.error(f"Error getting tables for '{database}': {str(e)}")
        raise

def get_schema_info(database, tables):
    """Get detailed schema information for the specified tables."""
    schema_info = {}
    
    try:
        conn = get_connection(database)
        cursor = conn.cursor()
        
        for table in tables:
            table_info = {
                'columns': [],
                'foreign_keys': [],
                'indexes': []
            }
            
            # Get column information
            cursor.execute(f"PRAGMA table_info({table})")
            for col in cursor.fetchall():
                column_info = {
                    'name': col['name'],
                    'type': col['type'],
                    'notnull': col['notnull'],
                    'default': col['dflt_value'],
                    'pk': col['pk']
                }
                table_info['columns'].append(column_info)
            
            # Get foreign keys
            cursor.execute(f"PRAGMA foreign_key_list({table})")
            for fk in cursor.fetchall():
                fk_info = {
                    'id': fk['id'],
                    'seq': fk['seq'],
                    'table': fk['table'],
                    'from': fk['from'],
                    'to': fk['to'],
                    'on_update': fk['on_update'],
                    'on_delete': fk['on_delete'],
                    'match': fk['match']
                }
                table_info['foreign_keys'].append(fk_info)
            
            # Get indexes
            cursor.execute(f"PRAGMA index_list({table})")
            for idx in cursor.fetchall():
                idx_name = idx['name']
                cursor.execute(f"PRAGMA index_info({idx_name})")
                columns = [col['name'] for col in cursor.fetchall()]
                
                idx_info = {
                    'name': idx_name,
                    'unique': idx['unique'],
                    'columns': columns
                }
                table_info['indexes'].append(idx_info)
            
            schema_info[table] = table_info
        
        conn.close()
        return schema_info
    except Exception as e:
        logger.error(f"Error getting schema info for '{database}': {str(e)}")
        raise

def execute_query(database, query):
    """Execute a SQL query on the specified database."""
    try:
        conn = get_connection(database)
        cursor = conn.cursor()
        
        cursor.execute(query)
        
        if query.strip().upper().startswith(('SELECT', 'PRAGMA', 'EXPLAIN')):
            # For SELECT queries, return results
            rows = cursor.fetchall()
            
            # Get column names
            headers = [description[0] for description in cursor.description]
            
            # Convert rows to list of lists
            data_rows = []
            for row in rows:
                data_row = []
                for column in headers:
                    data_row.append(row[column])
                data_rows.append(data_row)
            
            result = {
                'headers': headers,
                'rows': data_rows,
                'row_count': len(rows)
            }
        else:
            # For other queries, return affected rows
            result = {
                'affected_rows': cursor.rowcount,
                'message': f"Query executed successfully. Rows affected: {cursor.rowcount}"
            }
            
            # Commit changes for non-SELECT queries
            conn.commit()
        
        conn.close()
        return result
    except Exception as e:
        logger.error(f"Error executing query on '{database}': {str(e)}")
        raise

def initialize_app_db():
    """Initialize the application database if it doesn't exist."""
    if not os.path.exists(DB_DIRECTORY):
        os.makedirs(DB_DIRECTORY)
    
    try:
        conn = sqlite3.connect(APP_DB_PATH)
        cursor = conn.cursor()
        
        # Create workspaces table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workspaces (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                domain TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create databases table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS databases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workspace_id INTEGER,
                name TEXT NOT NULL,
                path TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
            )
        """)
        
        # Create compliance_assessments table to store historical assessments
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS compliance_assessments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                database_name TEXT NOT NULL,
                tables_assessed TEXT NOT NULL,
                overall_score REAL NOT NULL,
                compliance_score INTEGER,
                auditability_score INTEGER,
                security_score INTEGER,
                traceability_score INTEGER,
                lineage_score INTEGER,
                ethics_score INTEGER,
                flesch_kincaid_score REAL,
                gunning_fog_score REAL,
                assessment_data TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error initializing app database: {str(e)}")
        raise

def upload_database(workspace_id, db_name, db_path):
    """Register an uploaded database in the application database."""
    try:
        conn = sqlite3.connect(APP_DB_PATH)
        cursor = conn.cursor()
        
        # Check if database already exists
        cursor.execute("SELECT id FROM databases WHERE name = ? AND workspace_id = ?", 
                      (db_name, workspace_id))
        existing = cursor.fetchone()
        
        if existing:
            # Update existing record
            cursor.execute("""
                UPDATE databases 
                SET path = ?, created_at = CURRENT_TIMESTAMP 
                WHERE name = ? AND workspace_id = ?
            """, (db_path, db_name, workspace_id))
        else:
            # Insert new record
            cursor.execute("""
                INSERT INTO databases (workspace_id, name, path)
                VALUES (?, ?, ?)
            """, (workspace_id, db_name, db_path))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Error uploading database: {str(e)}")
        return False

def create_workspace(name, description, domain):
    """Create a new workspace."""
    try:
        conn = sqlite3.connect(APP_DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO workspaces (name, description, domain)
            VALUES (?, ?, ?)
        """, (name, description, domain))
        
        workspace_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        return workspace_id
    except Exception as e:
        logger.error(f"Error creating workspace: {str(e)}")
        raise

def get_workspaces():
    """Get a list of all workspaces."""
    try:
        # Initialize the application database if it doesn't exist
        initialize_app_db()
        
        conn = sqlite3.connect(APP_DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT w.*, COUNT(d.id) as database_count
            FROM workspaces w
            LEFT JOIN databases d ON w.id = d.workspace_id
            GROUP BY w.id
            ORDER BY w.name
        """)
        
        workspaces = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return workspaces
    except Exception as e:
        logger.error(f"Error getting workspaces: {str(e)}")
        return []

def get_workspace_details(workspace_id):
    """Get details for a specific workspace."""
    try:
        conn = sqlite3.connect(APP_DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT w.*, COUNT(d.id) as database_count
            FROM workspaces w
            LEFT JOIN databases d ON w.id = d.workspace_id
            WHERE w.id = ?
            GROUP BY w.id
        """, (workspace_id,))
        
        workspace = cursor.fetchone()
        conn.close()
        
        if workspace:
            return dict(workspace)
        else:
            return None
    except Exception as e:
        logger.error(f"Error getting workspace details: {str(e)}")
        return None

def delete_workspace(workspace_id):
    """Delete a workspace and all its databases."""
    try:
        conn = sqlite3.connect(APP_DB_PATH)
        cursor = conn.cursor()
        
        # Get the databases associated with this workspace
        cursor.execute("SELECT name, path FROM databases WHERE workspace_id = ?", (workspace_id,))
        databases = cursor.fetchall()
        
        # Delete the workspace
        cursor.execute("DELETE FROM workspaces WHERE id = ?", (workspace_id,))
        
        # Delete the associated databases
        cursor.execute("DELETE FROM databases WHERE workspace_id = ?", (workspace_id,))
        
        conn.commit()
        conn.close()
        
        # Note: We're not deleting the actual database files
        # This could be implemented if desired
        
        return True
    except Exception as e:
        logger.error(f"Error deleting workspace: {str(e)}")
        return False

def save_compliance_assessment(database_name, tables, assessment_data):
    """
    Store a compliance assessment in the database for historical tracking.
    
    Args:
        database_name (str): Name of the database
        tables (list): List of tables included in the assessment
        assessment_data (dict): The assessment data returned from the API
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Initialize the application database if it doesn't exist
        initialize_app_db()
        
        # Convert tables list to string
        tables_str = ','.join(tables)
        
        # Convert assessment data to JSON string
        assessment_json = json.dumps(assessment_data)
        
        # Extract individual scores
        overall_score = assessment_data.get('overall_score', 0)
        compliance_score = assessment_data.get('compliance', {}).get('score', 0)
        auditability_score = assessment_data.get('auditability', {}).get('score', 0)
        security_score = assessment_data.get('security', {}).get('score', 0)
        traceability_score = assessment_data.get('traceability', {}).get('score', 0)
        lineage_score = assessment_data.get('lineage', {}).get('score', 0)
        ethics_score = assessment_data.get('ethics', {}).get('score', 0)
        
        # Extract readability scores if available
        flesch_kincaid_score = None
        gunning_fog_score = None
        if 'readability_scores' in assessment_data:
            flesch_kincaid_score = assessment_data['readability_scores'].get('flesch_kincaid')
            gunning_fog_score = assessment_data['readability_scores'].get('gunning_fog')
        
        # Connect to the application database
        conn = sqlite3.connect(APP_DB_PATH)
        cursor = conn.cursor()
        
        # Insert the assessment data
        cursor.execute("""
            INSERT INTO compliance_assessments (
                database_name, tables_assessed, overall_score, 
                compliance_score, auditability_score, security_score,
                traceability_score, lineage_score, ethics_score,
                flesch_kincaid_score, gunning_fog_score, assessment_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            database_name, tables_str, overall_score,
            compliance_score, auditability_score, security_score,
            traceability_score, lineage_score, ethics_score,
            flesch_kincaid_score, gunning_fog_score, assessment_json
        ))
        
        conn.commit()
        conn.close()
        
        return True
    except Exception as e:
        logger.error(f"Error saving compliance assessment: {str(e)}")
        return False

def get_compliance_history(database_name, limit=10):
    """
    Get historical compliance assessments for a database.
    
    Args:
        database_name (str): Name of the database
        limit (int): Maximum number of records to return
        
    Returns:
        list: List of compliance assessment records
    """
    try:
        # Initialize the application database if it doesn't exist
        initialize_app_db()
        
        # Connect to the application database
        conn = sqlite3.connect(APP_DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get the assessment records
        cursor.execute("""
            SELECT id, database_name, tables_assessed, overall_score,
                   compliance_score, auditability_score, security_score,
                   traceability_score, lineage_score, ethics_score,
                   flesch_kincaid_score, gunning_fog_score, created_at
            FROM compliance_assessments
            WHERE database_name = ?
            ORDER BY created_at DESC
            LIMIT ?
        """, (database_name, limit))
        
        # Convert rows to dictionaries
        assessments = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return assessments
    except Exception as e:
        logger.error(f"Error getting compliance history: {str(e)}")
        return []

def upload_csv_schema(workspace_id, db_name, csv_file):
    """
    Process a CSV file with schema information and create a SQLite database.
    
    Expected CSV format:
    table_name,column_name,data_type,not_null,primary_key,foreign_key,references
    
    Example:
    users,id,INTEGER,1,1,0,
    users,username,TEXT,1,0,0,
    users,email,TEXT,1,0,0,
    posts,id,INTEGER,1,1,0,
    posts,user_id,INTEGER,1,0,1,users.id
    """
    try:
        # Create a new SQLite database
        db_path = os.path.join(DB_DIRECTORY, f"{db_name}.db")
        csv_conn = sqlite3.connect(db_path)
        csv_cursor = csv_conn.cursor()
        
        # Process the CSV file
        csv_data = csv_file.read().decode('utf-8').splitlines()
        csv_reader = csv.reader(csv_data)
        
        # Skip header if it exists
        header = next(csv_reader, None)
        if header and header[0].lower() == 'table_name':
            pass  # Skip the header
        else:
            # If it wasn't a header, go back to the beginning
            csv_reader = csv.reader(csv_data)
        
        # Track tables and foreign keys to create
        tables = {}
        foreign_keys = []
        
        # Parse the CSV data
        for row in csv_reader:
            if len(row) < 7:
                continue  # Invalid row
            
            table_name, column_name, data_type, not_null, primary_key, foreign_key, references = row
            
            # Add table if it doesn't exist
            if table_name not in tables:
                tables[table_name] = []
            
            # Add column definition
            column_def = f"{column_name} {data_type}"
            if primary_key == '1':
                column_def += " PRIMARY KEY"
            if not_null == '1':
                column_def += " NOT NULL"
            
            tables[table_name].append(column_def)
            
            # Track foreign key if specified
            if foreign_key == '1' and references:
                ref_parts = references.split('.')
                if len(ref_parts) == 2:
                    ref_table, ref_column = ref_parts
                    foreign_keys.append({
                        'table': table_name,
                        'column': column_name,
                        'ref_table': ref_table,
                        'ref_column': ref_column
                    })
        
        # Create the tables
        for table_name, columns in tables.items():
            create_statement = f"CREATE TABLE {table_name} (\n"
            create_statement += ",\n".join(columns)
            
            # Add foreign key constraints
            fk_constraints = []
            for fk in foreign_keys:
                if fk['table'] == table_name:
                    constraint = f"FOREIGN KEY ({fk['column']}) REFERENCES {fk['ref_table']}({fk['ref_column']})"
                    fk_constraints.append(constraint)
            
            if fk_constraints:
                create_statement += ",\n" + ",\n".join(fk_constraints)
            
            create_statement += "\n)"
            
            csv_cursor.execute(create_statement)
        
        csv_conn.commit()
        csv_conn.close()
        
        # Register the database with the cleaned filename
        db_filename = f"{db_name}.db"
        upload_database(workspace_id, db_filename, db_path)
        
        logger.info(f"Successfully created and registered database {db_filename} from CSV schema")
        return True
    except Exception as e:
        logger.error(f"Error processing CSV schema: {str(e)}")
        return False