document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const databaseSelect = document.getElementById('database');
    const tablesList = document.getElementById('tablesList');
    const selectAllTablesBtn = document.getElementById('selectAllTables');
    const deselectAllTablesBtn = document.getElementById('deselectAllTables');
    const analysisTypeCards = document.querySelectorAll('.analysis-type-card');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const analysisResult = document.getElementById('analysisResult');
    const copyResultsBtn = document.getElementById('copyResultsBtn');
    
    // Track selected analysis types
    const selectedAnalysisTypes = new Set(['general']);
    
    // Load tables when a database is selected
    if (databaseSelect) {
        databaseSelect.addEventListener('change', function() {
            const database = this.value;
            if (database) {
                loadTables(database);
            } else {
                tablesList.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-muted">Select a database to show tables</p>
                    </div>
                `;
                selectAllTablesBtn.style.display = 'none';
                deselectAllTablesBtn.style.display = 'none';
            }
        });
        
        // Load tables for the pre-selected database (if any)
        if (databaseSelect.value) {
            loadTables(databaseSelect.value);
        }
    }
    
    // Analysis type selection (with multi-select support)
    analysisTypeCards.forEach(card => {
        card.addEventListener('click', function() {
            const analysisType = this.getAttribute('data-type');
            
            if (this.classList.contains('active')) {
                // If already selected and not the only one selected, remove it
                if (selectedAnalysisTypes.size > 1) {
                    selectedAnalysisTypes.delete(analysisType);
                    this.classList.remove('active');
                }
            } else {
                // Add to selection
                selectedAnalysisTypes.add(analysisType);
                this.classList.add('active');
            }
        });
    });
    
    // Select/deselect all tables
    if (selectAllTablesBtn) {
        selectAllTablesBtn.addEventListener('click', function() {
            document.querySelectorAll('#tablesList input[type="checkbox"]').forEach(checkbox => {
                checkbox.checked = true;
            });
        });
    }
    
    if (deselectAllTablesBtn) {
        deselectAllTablesBtn.addEventListener('click', function() {
            document.querySelectorAll('#tablesList input[type="checkbox"]').forEach(checkbox => {
                checkbox.checked = false;
            });
        });
    }
    
    // Run analysis button
    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', function() {
            const database = databaseSelect.value;
            const selectedTables = Array.from(document.querySelectorAll('#tablesList input[type="checkbox"]:checked')).map(checkbox => checkbox.value);
            
            if (!database) {
                alert('Please select a database');
                return;
            }
            
            if (selectedTables.length === 0) {
                alert('Please select at least one table');
                return;
            }
            
            // Get comma-separated list of selected analysis types
            const analysisTypes = Array.from(selectedAnalysisTypes).join(',');
            
            runAnalysis(database, selectedTables, analysisTypes);
        });
    }
    
    // Copy results button
    if (copyResultsBtn) {
        copyResultsBtn.addEventListener('click', function() {
            const resultText = analysisResult.innerText;
            navigator.clipboard.writeText(resultText).then(() => {
                const originalText = this.innerHTML;
                this.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" class="me-1" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="23 3 12 14 9 11"></polyline></svg> Copied!';
                setTimeout(() => {
                    this.innerHTML = originalText;
                }, 2000);
            });
        });
    }
    
    // Load tables for a database
    function loadTables(database) {
        tablesList.innerHTML = `
            <div class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted mt-2">Loading tables...</p>
            </div>
        `;
        
        // Prepare form data
        const formData = new FormData();
        formData.append('database', database);
        
        // Fetch tables
        fetch('/get_tables', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.tables && data.tables.length > 0) {
                // Render tables with checkboxes
                const tablesHtml = data.tables.map(table => {
                    return `
                        <div class="table-check-label">
                            <input type="checkbox" class="table-checkbox" id="table-${table}" name="tables[]" value="${table}">
                            <label for="table-${table}" class="mb-0">${table}</label>
                        </div>
                    `;
                }).join('');
                
                tablesList.innerHTML = tablesHtml;
                selectAllTablesBtn.style.display = 'inline-block';
                deselectAllTablesBtn.style.display = 'inline-block';
            } else {
                tablesList.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-muted">No tables found in this database</p>
                    </div>
                `;
                selectAllTablesBtn.style.display = 'none';
                deselectAllTablesBtn.style.display = 'none';
            }
        })
        .catch(error => {
            tablesList.innerHTML = `
                <div class="text-center py-3">
                    <p class="text-danger">Error loading tables: ${error}</p>
                </div>
            `;
            selectAllTablesBtn.style.display = 'none';
            deselectAllTablesBtn.style.display = 'none';
        });
    }
    
    // Run analysis
    function runAnalysis(database, tables, analysisTypes) {
        // Show loading state
        analysisResult.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Analyzing schema...</p>
            </div>
        `;
        
        // Prepare form data
        const formData = new FormData();
        formData.append('database', database);
        tables.forEach(table => {
            formData.append('tables[]', table);
        });
        formData.append('analysis_type', analysisTypes);
        
        // Send request
        fetch('/analyze', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                analysisResult.innerHTML = `
                    <div class="alert alert-danger">
                        <h4 class="alert-heading">Analysis Error</h4>
                        <p>${data.error}</p>
                    </div>
                `;
                copyResultsBtn.style.display = 'none';
            } else if (data.result) {
                // Format the analysis result as HTML
                analysisResult.innerHTML = `<div class="markdown-content">${marked.parse(data.result)}</div>`;
                copyResultsBtn.style.display = 'inline-block';
                
                // Syntax highlight code blocks if hljs is available
                if (typeof hljs !== 'undefined') {
                    document.querySelectorAll('pre code').forEach((block) => {
                        hljs.highlightElement(block);
                    });
                }
            } else {
                analysisResult.innerHTML = `
                    <div class="alert alert-warning">
                        <h4 class="alert-heading">Empty Response</h4>
                        <p>The analysis did not return any results.</p>
                    </div>
                `;
                copyResultsBtn.style.display = 'none';
            }
        })
        .catch(error => {
            analysisResult.innerHTML = `
                <div class="alert alert-danger">
                    <h4 class="alert-heading">Request Error</h4>
                    <p>Failed to run analysis: ${error}</p>
                </div>
            `;
            copyResultsBtn.style.display = 'none';
        });
    }
});
