// ADW Workbench - Visualization JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Visualization JS loaded');
    
    // DOM elements
    const databaseSelect = document.getElementById('database');
    const tablesList = document.getElementById('tablesList');
    const diagramTabsContainer = document.getElementById('diagramTabs');
    const diagramContainer = document.getElementById('diagramContainer');
    const emptyState = document.getElementById('emptyState');
    const generateDiagramBtn = document.getElementById('generateDiagramBtn');
    const exportPngBtn = document.getElementById('exportPngBtn');
    const exportSvgBtn = document.getElementById('exportSvgBtn');
    const selectedDiagramType = document.getElementById('selectedDiagramType');
    
    // Load tables when a database is selected
    if (databaseSelect) {
        databaseSelect.addEventListener('change', function() {
            const database = this.value;
            if (database) {
                loadTables(database);
            } else {
                tablesList.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-muted">Select a database to show tables</p>
                    </div>
                `;
            }
        });
        
        // Load tables for the pre-selected database (if any)
        if (databaseSelect.value) {
            loadTables(databaseSelect.value);
        }
    }
    
    // Initialize diagram tabs
    if (diagramTabsContainer) {
        // Click event for diagram type tabs
        diagramTabsContainer.addEventListener('click', function(e) {
            if (e.target.classList.contains('diagram-tab')) {
                // Remove active class from all tabs
                document.querySelectorAll('.diagram-tab').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Add active class to clicked tab
                e.target.classList.add('active');
                
                // Update selected diagram type
                const diagramType = e.target.getAttribute('data-type');
                if (selectedDiagramType) {
                    selectedDiagramType.value = diagramType;
                    
                    // Show alert to regenerate diagram with more detailed information
                    if (diagramContainer.innerHTML.trim() !== '') {
                        // Create informative alert element instead of using alert()
                        const alertDiv = document.createElement('div');
                        alertDiv.className = 'alert alert-warning alert-dismissible fade show mb-3';
                        alertDiv.innerHTML = `
                            <strong>Diagram type changed!</strong> Please click "Generate Diagram" to see the ${diagramType} diagram.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <div class="mt-2">
                                <ul>
                                    <li><strong>Conceptual:</strong> Shows only entities and relationships</li>
                                    <li><strong>Logical:</strong> Shows entities with key attributes</li>
                                    <li><strong>Physical:</strong> Shows detailed schema with all attributes</li>
                                    <li><strong>Dependency:</strong> Shows table dependencies</li>
                                    <li><strong>Hierarchical:</strong> Shows hierarchical relationships</li>
                                </ul>
                            </div>
                        `;
                        
                        // Remove any existing alert before adding the new one
                        const existingAlert = document.querySelector('.alert');
                        if (existingAlert) {
                            existingAlert.remove();
                        }
                        
                        // Insert the alert before the diagram container
                        diagramContainer.parentNode.insertBefore(alertDiv, diagramContainer);
                    }
                }
            }
        });
    }
    
    // Generate diagram button click
    if (generateDiagramBtn) {
        generateDiagramBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const database = databaseSelect.value;
            const selectedTables = getSelectedTables();
            const diagramType = selectedDiagramType ? selectedDiagramType.value : 'physical';
            
            if (!database) {
                alert('Please select a database');
                return;
            }
            
            if (selectedTables.length === 0) {
                alert('Please select at least one table');
                return;
            }
            
            // Show loading
            diagramContainer.innerHTML = `
                <div class="text-center p-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3">Generating diagram...</p>
                </div>
            `;
            emptyState.style.display = 'none';
            
            // Send request to generate the diagram
            loadDiagram(diagramType);
        });
    }
    
    // Export diagram buttons
    if (exportPngBtn) {
        exportPngBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const diagramType = selectedDiagramType ? selectedDiagramType.value : 'physical';
            exportDiagram(diagramType, 'png');
        });
    }
    
    if (exportSvgBtn) {
        exportSvgBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const diagramType = selectedDiagramType ? selectedDiagramType.value : 'physical';
            exportDiagram(diagramType, 'svg');
        });
    }
    
    /**
     * Load tables from the selected database
     */
    function loadTables(database) {
        // Show loading indicator
        tablesList.innerHTML = `
            <div class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted mt-2">Loading tables...</p>
            </div>
        `;
        
        // Create form data for POST request
        const formData = new FormData();
        formData.append('database', database);
        
        // Use POST request as expected by the backend
        fetch('/get_tables', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.tables && data.tables.length > 0) {
                    renderTablesList(data.tables);
                } else {
                    tablesList.innerHTML = `
                        <div class="text-center py-3">
                            <p class="text-muted">No tables found in this database</p>
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('Error loading tables:', error);
                tablesList.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-danger">Error loading tables: ${error.toString()}</p>
                    </div>
                `;
            });
    }
    
    /**
     * Render the tables list with checkboxes
     */
    function renderTablesList(tables) {
        const tableCheckboxes = tables.map(table => `
            <div class="form-check mb-2">
                <input class="form-check-input table-checkbox" type="checkbox" value="${table}" id="check_${table}">
                <label class="form-check-label" for="check_${table}">
                    ${table}
                </label>
            </div>
        `).join('');
        
        tablesList.innerHTML = `
            <div class="mb-2">
                <button class="btn btn-sm btn-outline-secondary select-all-btn">Select All</button>
                <button class="btn btn-sm btn-outline-secondary deselect-all-btn">Deselect All</button>
            </div>
            <div class="table-checkboxes">
                ${tableCheckboxes}
            </div>
        `;
        
        // Add event listeners for select/deselect all buttons
        document.querySelector('.select-all-btn').addEventListener('click', function() {
            document.querySelectorAll('.table-checkbox').forEach(checkbox => {
                checkbox.checked = true;
            });
        });
        
        document.querySelector('.deselect-all-btn').addEventListener('click', function() {
            document.querySelectorAll('.table-checkbox').forEach(checkbox => {
                checkbox.checked = false;
            });
        });
    }
    
    /**
     * Load the diagram for the selected tables and diagram type
     */
    function loadDiagram(diagramType) {
        const database = databaseSelect.value;
        const selectedTables = getSelectedTables();
        
        // Create form data to match the server's expected format
        const formData = new FormData();
        formData.append('database', database);
        formData.append('diagram_type', diagramType);
        selectedTables.forEach(table => {
            formData.append('tables[]', table);
        });
        
        fetch('/generate_diagram', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.diagram_code) {
                // Initialize mermaid configuration before rendering
                mermaid.initialize({ 
                    startOnLoad: false, 
                    securityLevel: 'loose',
                    theme: 'default',
                    htmlLabels: true,
                    // Use flowchart TD for all diagrams to ensure better compatibility
                    // as recommended in mermaid documentation for complex diagrams
                    flowchart: {
                        useMaxWidth: false,
                        htmlLabels: true,
                        curve: 'basis',  // Smoother line curve
                        diagramPadding: 25,
                        nodeSpacing: 60,
                        rankSpacing: 80,
                        padding: 15
                    },
                    er: {
                        useMaxWidth: false,
                        entityPadding: 20,
                        fontSize: 14,
                        fill: '#ffffff',         // White background for entities
                        stroke: '#D6002A',       // Red border for entities
                        diagramPadding: 25,
                        layoutDirection: 'TB',
                        entityLabelBackground: '#ffffff'
                    },
                    themeVariables: {
                        // Core colors
                        primaryColor: '#D6002A',           // Red for borders
                        primaryTextColor: '#333333',       // Dark text for better readability
                        primaryBorderColor: '#D6002A',     // Red borders
                        lineColor: '#D6002A',              // Red lines
                        
                        // Elements styling
                        edgeLabelBackground: '#ffffff',    // White background for edge labels
                        nodeBorder: '#D6002A',             // Red node borders
                        clusterBkg: '#ffffff',             // White cluster background
                        clusterBorder: '#D6002A',          // Red cluster border
                        titleColor: '#333333',             // Dark title for better readability
                        
                        // Backgrounds
                        tertiaryColor: '#ffffff',          // White background
                        background: '#ffffff',             // White background
                        
                        // Font settings
                        fontSize: '14px',                  // Consistent font size
                        fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                        
                        // ER diagram specific styling
                        entityBorder: '#D6002A',           // Red border for entities
                        entityBackground: '#ffffff',       // White background for entities
                        relationColor: '#D6002A',          // Red color for relations
                        relationLabelBackground: '#ffffff' // White background for relation labels
                    }
                });
                
                try {
                    // Sanitize the diagram code to escape problematic characters
                    let sanitizedCode = data.diagram_code;
                    // Fix common syntax errors that might occur
                    sanitizedCode = sanitizedCode.replace(/\\\{/g, '{');
                    sanitizedCode = sanitizedCode.replace(/\\\}/g, '}');
                    
                    // Clear the container
                    diagramContainer.innerHTML = `<div class="mermaid bg-white p-3 rounded border" style="background-color: white;">${sanitizedCode}</div>`;
                    
                    // Show the diagram container
                    diagramContainer.style.display = 'block';
                    emptyState.style.display = 'none';
                    
                    // Render the diagram
                    mermaid.init(undefined, '.mermaid');
                    
                    // Add a small delay to ensure rendering is complete
                    setTimeout(() => {
                        // Add white background to SVG if it exists
                        const svg = document.querySelector('.mermaid svg');
                        if (svg) {
                            // Ensure SVG has white background
                            svg.style.backgroundColor = 'white';
                            
                            // Add a white background rect as the first element if not present
                            const existingRect = svg.querySelector('rect:first-child[width="100%"][height="100%"]');
                            if (!existingRect) {
                                const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
                                rect.setAttribute("width", "100%");
                                rect.setAttribute("height", "100%");
                                rect.setAttribute("fill", "white");
                                rect.setAttribute("stroke", "none");
                                if (svg.firstChild) {
                                    svg.insertBefore(rect, svg.firstChild);
                                } else {
                                    svg.appendChild(rect);
                                }
                            }
                            
                            // Make sure all text is black
                            const textElements = svg.querySelectorAll('text');
                            textElements.forEach(text => {
                                text.style.fill = '#000000';
                            });
                            
                            // Make sure all paths (lines) are red
                            const pathElements = svg.querySelectorAll('path');
                            pathElements.forEach(path => {
                                if (path.getAttribute('stroke') && path.getAttribute('stroke') !== 'none') {
                                    path.setAttribute('stroke', '#D6002A');
                                }
                            });
                            
                            // Style rectangles (entity boxes) with white fill and red border
                            const rectElements = svg.querySelectorAll('rect:not([width="100%"][height="100%"])');
                            rectElements.forEach(rect => {
                                rect.setAttribute('fill', '#ffffff');
                                rect.setAttribute('stroke', '#D6002A');
                                rect.setAttribute('stroke-width', '2');
                            });
                            
                            // Style polygon elements (often used in diagrams)
                            const polygonElements = svg.querySelectorAll('polygon');
                            polygonElements.forEach(polygon => {
                                polygon.setAttribute('fill', '#ffffff');
                                polygon.setAttribute('stroke', '#D6002A');
                                polygon.setAttribute('stroke-width', '2');
                            });
                            
                            // Set line colors for relationship lines
                            const lineElements = svg.querySelectorAll('line');
                            lineElements.forEach(line => {
                                line.setAttribute('stroke', '#D6002A');
                                line.setAttribute('stroke-width', '2');
                            });
                        }
                    }, 100);
                } catch (error) {
                    console.error('Error rendering diagram:', error);
                    diagramContainer.innerHTML = `
                        <div class="alert alert-danger">
                            <h5>Error rendering diagram</h5>
                            <p>Please try a different diagram type or select fewer tables.</p>
                            <pre class="mt-3">${error.message}</pre>
                        </div>
                    `;
                }
                
                // Enable export buttons
                exportPngBtn.disabled = false;
                exportSvgBtn.disabled = false;
            } else {
                diagramContainer.innerHTML = `
                    <div class="text-center py-4">
                        <div class="alert alert-danger">
                            <h5>Error generating diagram</h5>
                            <p>${data.error || 'Unknown error'}</p>
                        </div>
                    </div>
                `;
                exportPngBtn.disabled = true;
                exportSvgBtn.disabled = true;
            }
        })
        .catch(error => {
            console.error('Error generating diagram:', error);
            diagramContainer.innerHTML = `
                <div class="text-center py-4">
                    <div class="alert alert-danger">
                        <h5>Error generating diagram</h5>
                        <p>${error.message}</p>
                    </div>
                </div>
            `;
            exportPngBtn.disabled = true;
            exportSvgBtn.disabled = true;
        });
    }
    
    /**
     * Export the diagram as PNG or SVG
     */
    function exportDiagram(diagramType, format) {
        // Get the SVG element
        const svg = document.querySelector('.mermaid svg');
        if (!svg) {
            alert('No diagram found to export');
            return;
        }
        
        if (format === 'svg') {
            // Export as SVG
            const svgData = new XMLSerializer().serializeToString(svg);
            const svgBlob = new Blob([svgData], {type: 'image/svg+xml;charset=utf-8'});
            const svgUrl = URL.createObjectURL(svgBlob);
            
            // Create download link
            const downloadLink = document.createElement('a');
            downloadLink.href = svgUrl;
            downloadLink.download = `diagram_${diagramType}.svg`;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            
            // Clean up
            URL.revokeObjectURL(svgUrl);
        } else {
            // Export as PNG
            // Create a canvas element
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            
            // Create a new image
            const img = new Image();
            img.onload = function() {
                // Set canvas dimensions
                canvas.width = img.width;
                canvas.height = img.height;
                
                // Draw white background
                ctx.fillStyle = 'white';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                // Draw the image
                ctx.drawImage(img, 0, 0);
                
                // Convert to PNG and download
                const pngUrl = canvas.toDataURL('image/png');
                
                // Create download link
                const downloadLink = document.createElement('a');
                downloadLink.href = pngUrl;
                downloadLink.download = `diagram_${diagramType}.png`;
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            };
            
            // Set the source of the image
            const svgData = new XMLSerializer().serializeToString(svg);
            const svgBlob = new Blob([svgData], {type: 'image/svg+xml;charset=utf-8'});
            const svgUrl = URL.createObjectURL(svgBlob);
            img.src = svgUrl;
        }
    }
    
    /**
     * Get the list of selected tables
     */
    function getSelectedTables() {
        const selectedTables = [];
        document.querySelectorAll('.table-checkbox:checked').forEach(checkbox => {
            selectedTables.push(checkbox.value);
        });
        return selectedTables;
    }
});
