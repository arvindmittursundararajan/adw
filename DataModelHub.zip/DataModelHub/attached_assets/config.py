import os

# Gemini API configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key={GEMINI_API_KEY}"

# Application configuration
SQLITE_DB_PATH = "databases"  # Directory to store/look for SQLite databases
DEBUG = True

# Colors
COLOR_PRIMARY = "#6a040f"
COLOR_SECONDARY = "#370617"
