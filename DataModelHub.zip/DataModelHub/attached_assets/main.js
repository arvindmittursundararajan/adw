document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const databaseSelect = document.getElementById('database-select');
    const loadTablesBtn = document.getElementById('load-tables-btn');
    const tablesContainer = document.getElementById('tables-container');
    const tablesList = document.getElementById('tables-list');
    const analyzeBtn = document.getElementById('analyze-btn');
    const generateSampleBtn = document.getElementById('generate-sample-btn');
    const analysisOptions = document.getElementById('analysis-options');
    const analysisType = document.getElementById('analysis-type');
    const submitAnalysisBtn = document.getElementById('submit-analysis-btn');
    const loadingIndicator = document.getElementById('loading');
    const resultsContent = document.getElementById('results-content');

    // Event listeners
    loadTablesBtn.addEventListener('click', loadTables);
    analyzeBtn.addEventListener('click', showAnalysisOptions);
    submitAnalysisBtn.addEventListener('click', runAnalysis);
    generateSampleBtn.addEventListener('click', generateSampleData);

    // Load tables from the selected database
    function loadTables() {
        const selectedDatabase = databaseSelect.value;
        
        if (!selectedDatabase) {
            alert('Please select a database first.');
            return;
        }
        
        // Create form data
        const formData = new FormData();
        formData.append('database', selectedDatabase);
        
        // Show loading indicator
        tablesList.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p>Loading tables...</p></div>';
        tablesContainer.style.display = 'block';
        
        // Send request to get tables
        fetch('/get_tables', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                tablesList.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                return;
            }
            
            if (data.tables && data.tables.length > 0) {
                renderTablesList(data.tables);
            } else {
                tablesList.innerHTML = '<div class="alert alert-warning">No tables found in this database.</div>';
            }
        })
        .catch(error => {
            tablesList.innerHTML = `<div class="alert alert-danger">Error: ${error}</div>`;
        });
    }

    // Render the list of tables with checkboxes
    function renderTablesList(tables) {
        let html = '<div class="table-checkbox-container">';
        
        tables.forEach(table => {
            html += `
                <div class="form-check">
                    <input class="form-check-input table-checkbox" type="checkbox" value="${table}" id="table-${table}">
                    <label class="form-check-label" for="table-${table}">
                        ${table}
                    </label>
                </div>
            `;
        });
        
        html += '</div>';
        html += '<div class="mt-2">';
        html += '<button id="select-all-btn" class="btn btn-sm btn-outline-primary me-2">Select All</button>';
        html += '<button id="deselect-all-btn" class="btn btn-sm btn-outline-secondary">Deselect All</button>';
        html += '</div>';
        
        tablesList.innerHTML = html;
        
        // Add event listeners for select/deselect all buttons
        document.getElementById('select-all-btn').addEventListener('click', () => {
            document.querySelectorAll('.table-checkbox').forEach(checkbox => {
                checkbox.checked = true;
            });
        });
        
        document.getElementById('deselect-all-btn').addEventListener('click', () => {
            document.querySelectorAll('.table-checkbox').forEach(checkbox => {
                checkbox.checked = false;
            });
        });
    }

    // Show analysis options when Analyze Schema button is clicked
    function showAnalysisOptions() {
        const selectedTables = getSelectedTables();
        
        if (selectedTables.length === 0) {
            alert('Please select at least one table to analyze.');
            return;
        }
        
        analysisOptions.style.display = 'block';
        resultsContent.innerHTML = '<p class="text-muted">Select an analysis type and click "Run Analysis" to see results.</p>';
    }

    // Run the selected analysis on the selected tables
    function runAnalysis() {
        const selectedDatabase = databaseSelect.value;
        const selectedTables = getSelectedTables();
        const selectedAnalysisType = analysisType.value;
        
        if (!selectedDatabase || selectedTables.length === 0 || !selectedAnalysisType) {
            alert('Please select a database, at least one table, and an analysis type.');
            return;
        }
        
        // Create form data
        const formData = new FormData();
        formData.append('database', selectedDatabase);
        selectedTables.forEach(table => {
            formData.append('tables[]', table);
        });
        formData.append('analysis_type', selectedAnalysisType);
        
        // Show loading indicator
        loadingIndicator.style.display = 'flex';
        resultsContent.innerHTML = '';
        
        // Send request to analyze tables
        fetch('/analyze', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Hide loading indicator
            loadingIndicator.style.display = 'none';
            
            if (data.error) {
                resultsContent.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                return;
            }
            
            // Render analysis results with markdown
            const markdownContent = data.result || 'No analysis results returned.';
            resultsContent.innerHTML = marked.parse(markdownContent);
        })
        .catch(error => {
            loadingIndicator.style.display = 'none';
            resultsContent.innerHTML = `<div class="alert alert-danger">Error: ${error}</div>`;
        });
    }

    // Generate sample data for the selected tables
    function generateSampleData() {
        const selectedTables = getSelectedTables();
        
        if (selectedTables.length === 0) {
            alert('Please select at least one table to generate sample data for.');
            return;
        }
        
        alert('This feature is not yet implemented. It will generate sample data based on the table schema.');
    }

    // Helper function to get selected tables
    function getSelectedTables() {
        const selectedTables = [];
        document.querySelectorAll('.table-checkbox:checked').forEach(checkbox => {
            selectedTables.push(checkbox.value);
        });
        return selectedTables;
    }
});
