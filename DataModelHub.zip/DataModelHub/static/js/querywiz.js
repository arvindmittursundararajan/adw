// Pendulum.io - QueryWiz JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('QueryWiz JS loaded');
    
    // DOM elements
    const databaseSelect = document.getElementById('database');
    const queryInput = document.getElementById('queryInput');
    const generateBtn = document.getElementById('generateBtn');
    // executeBtn removed - no longer needed
    const clearBtn = document.getElementById('clearBtn');
    const exportBtn = document.getElementById('exportBtn');
    const queryForm = document.getElementById('queryForm');
    const resultsContainer = document.getElementById('resultsContainer');
    const queryHints = document.getElementById('queryHints');
    const queryHistory = document.getElementById('queryHistory');
    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    
    // Load query history from localStorage
    let history = JSON.parse(localStorage.getItem('queryHistory') || '[]');
    renderQueryHistory();
    
    // Database selection change
    if (databaseSelect) {
        databaseSelect.addEventListener('change', function() {
            if (this.value) {
                // Load query hints when database is selected
                loadQueryHints(this.value);
            } else {
                // Clear query hints when no database is selected
                if (queryHints) {
                    queryHints.innerHTML = '';
                }
            }
        });
        
        // Load hints for pre-selected database (if any)
        if (databaseSelect.value) {
            loadQueryHints(databaseSelect.value);
        }
    }
    
    // Generate query button click
    if (generateBtn) {
        generateBtn.addEventListener('click', function(e) {
            e.preventDefault();
            generateQuery();
        });
    }
    
    // Execute query button removed
    
    // Clear query button click
    if (clearBtn) {
        clearBtn.addEventListener('click', function(e) {
            e.preventDefault();
            clearQuery();
        });
    }
    
    // Export results button click
    if (exportBtn) {
        exportBtn.addEventListener('click', function(e) {
            e.preventDefault();
            exportToCsv();
        });
    }
    
    // Clear history button click
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', function(e) {
            e.preventDefault();
            clearHistory();
        });
    }
    
    // Function to load query hints
    function loadQueryHints(database) {
        if (!queryHints) return;
        
        queryHints.innerHTML = `
            <div class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted mt-2">Generating query suggestions...</p>
            </div>
        `;
        
        const formData = new FormData();
        formData.append('database', database);
        
        fetch('/generate_query_hints', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                queryHints.innerHTML = `
                    <div class="alert alert-danger" role="alert">
                        ${data.error}
                    </div>
                `;
                return;
            }
            
            if (!data.hints || data.hints.length === 0) {
                queryHints.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-muted">No query suggestions available</p>
                    </div>
                `;
                return;
            }
            
            let hintsHtml = '<div class="list-group">';
            
            data.hints.forEach(hint => {
                hintsHtml += `
                    <button type="button" class="list-group-item list-group-item-action query-hint">
                        ${escapeHtml(hint)}
                    </button>
                `;
            });
            
            hintsHtml += '</div>';
            queryHints.innerHTML = hintsHtml;
            
            // Add click event to query hints
            document.querySelectorAll('.query-hint').forEach(hint => {
                hint.addEventListener('click', function() {
                    queryInput.value = this.textContent.trim();
                    
                    // Scroll to query input
                    queryInput.scrollIntoView({ behavior: 'smooth' });
                    
                    // Auto-focus
                    queryInput.focus();
                });
            });
        })
        .catch(error => {
            console.error('Error loading query hints:', error);
            
            queryHints.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    Failed to load query suggestions. Please try again.
                </div>
            `;
        });
    }
    
    // Function to generate SQL query from natural language
    function generateQuery() {
        const database = databaseSelect.value;
        const prompt = queryInput.value.trim();
        
        if (!database) {
            alert('Please select a database');
            return;
        }
        
        if (!prompt) {
            alert('Please enter a query prompt');
            return;
        }
        
        // Show loading state
        generateBtn.disabled = true;
        generateBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
        
        const formData = new FormData();
        formData.append('database', database);
        formData.append('prompt', prompt);
        
        fetch('/generate_query', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Reset button state
            generateBtn.disabled = false;
            generateBtn.innerHTML = '<i class="fas fa-magic me-1"></i> Generate SQL';
            
            if (data.error) {
                alert(data.error);
                return;
            }
            
            // Update SQL editor with generated query
            const sqlEditor = document.getElementById('sqlEditor');
            if (sqlEditor) {
                sqlEditor.value = data.query;
                
                // Enable export button since we have generated a query
                exportBtn.disabled = false;
            }
            
            // Add to history
            addToHistory(data.query);
        })
        .catch(error => {
            console.error('Error generating query:', error);
            
            // Reset button state
            generateBtn.disabled = false;
            generateBtn.innerHTML = '<i class="fas fa-magic me-1"></i> Generate SQL';
            
            alert('Failed to generate query. Please try again.');
        });
    }
    
    // Execute SQL query functionality has been removed
    // This stub remains for backward compatibility
    function executeQuery() {
        console.log('Execute SQL functionality has been disabled');
        return;
    }
    
    // Function to display query results
    function displayResults(data) {
        if (!data || !data.headers || !data.rows) {
            resultsContainer.innerHTML = `
                <div class="alert alert-warning" role="alert">
                    Query executed successfully but returned no results.
                </div>
            `;
            return;
        }
        
        const headers = data.headers;
        const rows = data.rows;
        
        if (rows.length === 0) {
            resultsContainer.innerHTML = `
                <div class="alert alert-warning" role="alert">
                    Query executed successfully but returned no rows.
                </div>
            `;
            return;
        }
        
        // Build table for results
        let tableHtml = `
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
        `;
        
        // Add headers
        headers.forEach(header => {
            tableHtml += `<th>${escapeHtml(header)}</th>`;
        });
        
        tableHtml += `
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        // Add rows
        rows.forEach(row => {
            tableHtml += '<tr>';
            
            row.forEach(cell => {
                tableHtml += `<td>${escapeHtml(cell !== null ? cell : '')}</td>`;
            });
            
            tableHtml += '</tr>';
        });
        
        tableHtml += `
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <p><strong>${rows.length}</strong> rows returned</p>
            </div>
        `;
        
        resultsContainer.innerHTML = tableHtml;
    }
    
    // Function to export results to CSV
    function exportToCsv() {
        const database = databaseSelect.value;
        const sqlEditor = document.getElementById('sqlEditor');
        const query = sqlEditor ? sqlEditor.value.trim() : '';
        
        if (!database) {
            alert('Please select a database');
            return;
        }
        
        if (!query) {
            alert('Please enter a SQL query');
            return;
        }
        
        // Show loading state
        exportBtn.disabled = true;
        exportBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Exporting...';
        
        // Prepare export data directly (no execution)
        // The backend will handle executing the query and generating the CSV
        const exportData = {
            database: database,
            filename: `${database}_query_export.csv`,
            query: query
        };
        
        // Send export request
        fetch('/export_csv', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(exportData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Export failed');
            }
            return response.blob();
        })
        .then(blob => {
            // Create download link
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = exportData.filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
            
            // Reset button state
            exportBtn.disabled = false;
            exportBtn.innerHTML = '<i class="fas fa-download me-1"></i> Export CSV';
        })
        .catch(error => {
            console.error('Error exporting CSV:', error);
            
            // Reset button state
            exportBtn.disabled = false;
            exportBtn.innerHTML = '<i class="fas fa-download me-1"></i> Export CSV';
            
            alert('Failed to export CSV. Please try again.');
        });
    }
    
    // Function to clear the query input
    function clearQuery() {
        const sqlEditor = document.getElementById('sqlEditor');
        if (sqlEditor) {
            sqlEditor.value = '';
        }
        
        resultsContainer.style.display = 'none';
        resultsContainer.innerHTML = '';
        
        // Disable export button
        exportBtn.disabled = true;
    }
    
    // Function to add query to history
    function addToHistory(query) {
        // Add to beginning of history (most recent first)
        history.unshift({
            query: query,
            timestamp: new Date().toISOString()
        });
        
        // Limit history to 10 items
        if (history.length > 10) {
            history = history.slice(0, 10);
        }
        
        // Save to localStorage
        localStorage.setItem('queryHistory', JSON.stringify(history));
        
        // Update history display
        renderQueryHistory();
    }
    
    // Function to render query history
    function renderQueryHistory() {
        if (!queryHistory) return;
        
        if (!history || history.length === 0) {
            queryHistory.innerHTML = `
                <div class="text-center py-3">
                    <p class="text-muted">No query history</p>
                </div>
            `;
            return;
        }
        
        let historyHtml = '';
        
        history.forEach((item, index) => {
            const date = new Date(item.timestamp);
            const formattedDate = date.toLocaleString();
            
            historyHtml += `
                <div class="card mb-2">
                    <div class="card-header py-2">
                        <small class="text-muted">${formattedDate}</small>
                    </div>
                    <div class="card-body p-2">
                        <pre class="mb-0"><code>${escapeHtml(item.query)}</code></pre>
                    </div>
                    <div class="card-footer p-2">
                        <button type="button" class="btn btn-sm btn-outline-primary history-use" data-index="${index}">
                            <i class="fas fa-arrow-up me-1"></i> Use
                        </button>
                    </div>
                </div>
            `;
        });
        
        queryHistory.innerHTML = historyHtml;
        
        // Add click event to "Use" buttons
        document.querySelectorAll('.history-use').forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                const item = history[index];
                
                if (item) {
                    const sqlEditor = document.getElementById('sqlEditor');
                    if (sqlEditor) {
                        sqlEditor.value = item.query;
                    }
                }
            });
        });
    }
    
    // Function to clear history
    function clearHistory() {
        if (confirm('Are you sure you want to clear your query history?')) {
            history = [];
            localStorage.removeItem('queryHistory');
            renderQueryHistory();
        }
    }
    
    // Helper function to escape HTML
    function escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});