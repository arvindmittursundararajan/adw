# Analysis prompts for different types of database analysis

DATA_MODEL_DESIGN_PROMPT = """
Analyze the following database tables for data model design issues and propose improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Purpose and goals of the data model
- Identification of key entities and relationships
- Cardinality of relationships (one-to-one, one-to-many, many-to-many)
- Handling of hierarchical data structures (e.g., parent-child relationships)

Provide a detailed analysis with specific examples from the schema.
"""

NORMALIZATION_PROMPT = """
Analyze the normalization level of the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Data normalization levels (1NF, 2NF, 3NF, etc.)
- Primary keys for each table
- Foreign key relationships between tables
- Many-to-many relationships and their resolution (e.g., junction tables)
- Referential integrity checks
- Validation rules for data entry

Provide a detailed analysis with specific examples from the schema.
"""

DATA_TYPES_PROMPT = """
Analyze the data types in the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Data types and their appropriateness for each column
- Column constraints (e.g., NOT NULL, UNIQUE)
- Use of surrogate keys versus natural keys
- Consistency in naming conventions for tables and columns

Provide a detailed analysis with specific examples from the schema.
"""

PERFORMANCE_PROMPT = """
Analyze the performance of the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Indexing for performance optimization
- Use of denormalization for performance optimization (if applicable)
- Optimization of join conditions between tables
- Performance testing under expected workloads
- Performance impact of large-scale queries on the model

Provide a detailed analysis with specific examples from the schema.
"""

DATA_QUALITY_PROMPT = """
Analyze the data quality aspects of the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Data quality checks (e.g., missing values, outliers)
- Handling of null values across tables
- Duplication of data across tables (redundancy)
- Presence of derived or calculated fields
- Handling of historical data (e.g., temporal tables)
- Data lineage and provenance tracking

Provide a detailed analysis with specific examples from the schema.
"""

SCALABILITY_PROMPT = """
Analyze the scalability of the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Storage efficiency and scalability considerations
- Partitioning strategies for large datasets
- Scalability to accommodate future growth in data volume or complexity
- Flexibility to adapt to changing business requirements

Provide a detailed analysis with specific examples from the schema.
"""

SECURITY_PROMPT = """
Analyze the security compliance of the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Security measures (e.g., access controls, encryption)
- Compliance with industry standards or regulations (e.g., GDPR, HIPAA)
- Audit trails for tracking changes to data
- Versioning strategies for schema changes

Provide a detailed analysis with specific examples from the schema.
"""

DOCUMENTATION_PROMPT = """
Analyze the documentation needs for the following database tables and suggest improvements:
Tables: {tables}
Schema: {schema}

Consider:
- Documentation of the schema and its relationships
- Use of views to simplify complex queries
- Support for analytics and reporting tools (e.g., BI dashboards)
- Integration with external systems or APIs
- Handling of unstructured or semi-structured data (e.g., JSON, XML)
- Use of triggers or stored procedures for automated tasks

Provide a detailed analysis with specific examples from the schema.
"""

DATA_DICTIONARY_PROMPT = """
Generate a comprehensive data dictionary for the following database tables:
Tables: {tables}
Schema: {schema}

For each table and column, provide:
1. Table name and description
2. Column name
3. Data type
4. Description/purpose
5. Constraints (PK, FK, NOT NULL, etc.)
6. Default values (if any)
7. Relationships with other tables
8. Any special notes about usage

Format the output as markdown for readability.
"""

# Visualization prompts
CONCEPTUAL_DIAGRAM_PROMPT = """
You are a database modeling expert. Generate a flowchart diagram in mermaid.js syntax for this database.

Database tables: {tables}
Schema details: {schema}

YOU MUST FOLLOW THESE EXACT FORMATTING REQUIREMENTS:
1. ONLY return the mermaid.js code with NO explanations, comments, or markdown formatting
2. Start the diagram with exactly "flowchart TD" on its own line
3. Each entity should be a node with descriptive text in square brackets: A[Entity Name]
4. Use arrows to show relationships: --> for direct flow, --- for associations
5. Do not use curly braces {{}} except within node definitions
6. Keep the diagram simple and focused on main entities and their relationships

EXAMPLE OUTPUT (follow this exact format):
flowchart TD
    Users[Users] --> Posts[Posts]
    Posts --> Comments[Comments]
    Users --> Comments
"""

LOGICAL_DIAGRAM_PROMPT = """
You are a database modeling expert. Generate an ER diagram in mermaid.js syntax for this database.

Database tables: {tables}
Schema details: {schema}

YOU MUST FOLLOW THESE EXACT FORMATTING REQUIREMENTS:
1. ONLY return the mermaid.js code with NO explanations, comments, or markdown formatting
2. Start with exactly "erDiagram" on its own line
3. Define each entity with UPPERCASE names
4. Define attributes inside curly braces with type and key information
5. Define relationships with the exact syntax: ENTITY1 ||--o{{ ENTITY2 : relationship_label
6. Use cardinality notation: ||--|| (one-to-one), ||--o{{ (one-to-many), }}o--o{{ (many-to-many)

EXAMPLE OUTPUT (follow this exact format):
erDiagram
    USERS {
        int id PK
        string username
        string email
    }
    POSTS {
        int id PK
        int user_id FK
        string title
        string content
    }
    USERS ||--o{ POSTS : creates
"""

PHYSICAL_DIAGRAM_PROMPT = """
You are a database modeling expert. Generate a class diagram in mermaid.js syntax for this database.

Database tables: {tables}
Schema details: {schema}

YOU MUST FOLLOW THESE EXACT FORMATTING REQUIREMENTS:
1. ONLY return the mermaid.js code with NO explanations, comments, or markdown formatting
2. Start with exactly "classDiagram" on its own line
3. First declare each class with: class table_name
4. Then define each class with attributes using the format:
   class table_name {{
       +data_type column_name
       +data_type column_name
   }}
5. Include ALL columns with their EXACT SQL data types from the schema (INTEGER, TEXT, VARCHAR, etc.)
6. Mark primary keys with PK and foreign keys with FK after the column name
7. Show relationships between classes using the syntax: Class1 "1" -- "many" Class2 
8. Use proper cardinality notation: "1" for one, "many" or "*" for many

EXAMPLE OUTPUT (follow this exact format):
classDiagram
    class Users
    class Posts
    class Users {
        +INTEGER id PK
        +VARCHAR username
        +VARCHAR email
    }
    class Posts {
        +INTEGER id PK
        +INTEGER user_id FK
        +VARCHAR title
        +TEXT content
    }
    Users "1" -- "many" Posts
"""